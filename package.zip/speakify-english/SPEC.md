# Speakify English - Complete Specification

## 1. Concept & Vision

**Speakify English** is a premium, mobile-first English learning platform designed for Arabic speakers who want to master English through an interactive, gamified experience. The platform combines modern AI-powered features with proven learning methodologies to create an engaging journey from beginner to fluent speaker. The experience should feel premium, fun, and rewarding - similar to Duolingo's gamification with Memrise's visual appeal and modern AI chat interfaces.

**Core Philosophy**: Learning English should feel like playing a game, not studying a textbook. Every interaction should be rewarding, every mistake should be a learning opportunity, and every achievement should be celebrated.

## 2. Design Language

### Aesthetic Direction
Modern, premium learning app aesthetic inspired by Duolingo, Memrise, and Notion. Clean, spacious layouts with playful yet professional feel. Gradient-rich backgrounds with subtle depth. Card-based UI with smooth rounded corners (16px-24px). Floating elements and glass-morphism effects for depth.

### Color Palette
```
Primary Blue:      #3B82F6 (main brand)
Primary Purple:    #8B5CF6 (secondary brand)
Accent Pink:       #EC4899 (achievements, celebrations)
Success Green:     #10B981 (correct answers, streaks)
Warning Orange:    #F59E0B (streaks at risk)
Error Red:         #EF4444 (incorrect answers)

Light Mode:
- Background:      #F8FAFC (soft white)
Surface:           #FFFFFF (cards)
Text Primary:      #1E293B (dark slate)
Text Secondary:    #64748B (muted)
Border:            #E2E8F0 (subtle borders)

Dark Mode:
- Background:      #0F172A (deep navy)
Surface:           #1E293B (elevated cards)
Text Primary:      #F1F5F9 (bright white)
Text Secondary:    #94A3B8 (muted)
Border:            #334155 (subtle borders)

Gradients:
- Hero Gradient:   linear-gradient(135deg, #667eea 0%, #764ba2 100%)
- Card Gradient:   linear-gradient(180deg, #3B82F6 0%, #8B5CF6 100%)
- Success Glow:    radial-gradient(circle, #10B98133 0%, transparent 70%)
```

### Typography
```
Primary Font:      Inter (Google Fonts) - clean, modern, excellent readability
Arabic Font:      Noto Sans Arabic (for Arabic translations)
Fallbacks:         system-ui, -apple-system, sans-serif

Size Scale:
- Hero Title:      3rem (48px, mobile: 2rem)
- Section Title:   1.75rem (28px)
- Card Title:      1.25rem (20px)
- Body:           1rem (16px)
- Small:          0.875rem (14px)
- Caption:        0.75rem (12px)

Weight Scale:
- Light:          300
- Regular:        400
- Medium:         500
- Semibold:       600
- Bold:           700
```

### Spatial System
```
Base Unit:         4px
Spacing Scale:     4, 8, 12, 16, 24, 32, 48, 64, 96px
Border Radius:     8px (buttons), 16px (cards), 24px (modals), 9999px (pills)
```

### Motion Philosophy
```
Micro-interactions: 150-300ms, ease-out
Page Transitions:   300-500ms, ease-in-out
Celebrations:       Spring physics, slight overshoot
Loading States:    Pulse, shimmer effects

Animation Types:
- Entrance:        Fade + scale from 0.95, staggered 50-100ms
- Exit:            Fade + scale to 0.95
- Hover:           Scale 1.02-1.05, shadow lift
- Click:           Scale 0.95-0.98, spring back
- Success:         Confetti burst, checkmark animation
- Error:           Shake, red glow
```

### Visual Assets
```
Icons:             Lucide React (consistent stroke width 2px)
Illustrations:     Custom SVG illustrations for empty states
Audio:            Text-to-Speech for pronunciation (Web Speech API)
Images:            Decorative gradient blobs, subtle patterns
```

## 3. Layout & Structure

### Page Structure

#### Home / Dashboard
```
┌─────────────────────────────────────────────────┐
│  [Logo]              [Search]    [Profile] [⚙️]  │  ← Top Bar (sticky)
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │  HERO: "Learn English Smartly"          │   │  ← Animated gradient hero
│  │  Subtitle + CTA buttons                  │   │
│  │  [Start Learning]  [Browse Categories]  │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  📊 Progress Card                               │  ← XP, Streak, Level
│  ┌─────────────────────────────────────────┐   │
│  │ Streak: 🔥 7  |  XP: 1,250  |  Lvl: 5   │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  📚 Continue Learning                           │  ← Last visited category
│  ┌─────────────────────────────────────────┐   │
│  │ [Restaurant English]    Progress: 60%  │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  🎯 Daily Challenge                             │  ← Today's special lesson
│  ┌─────────────────────────────────────────┐   │
│  │ "Practice 5 minutes of Speaking"        │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  📖 Browse Categories                          │  ← 17 category cards
│  ┌──────────┐ ┌──────────┐ ┌──────────┐      │
│  │ Daily    │ │ Restaurant│ │ Travel   │      │
│  └──────────┘ └──────────┘ └──────────┘      │
│                                                 │
├─────────────────────────────────────────────────┤
│  [🏠] [📚] [🎤] [👂] [💬] [🔢] [👤]            │  ← Bottom Nav (mobile)
└─────────────────────────────────────────────────┘
```

#### Vocabulary Section
```
┌─────────────────────────────────────────────────┐
│  🔙 Vocabulary Learning          [🔍] [🌙]      │
├─────────────────────────────────────────────────┤
│  Category: [Daily Conversations ▼]              │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │         FLASHCARD AREA                   │   │  ← Swipeable cards
│  │  ┌─────────────────────────────────────┐ │   │
│  │  │                                     │ │   │
│  │  │         Hello                       │ │   │
│  │  │         مرحباً                      │ │   │
│  │  │                                     │ │   │
│  │  │  🔊 [🔇]        ⭐                  │ │   │
│  │  │                                     │ │   │
│  │  └─────────────────────────────────────┘ │   │
│  │                                         │   │
│  │  Example: "Hello, how are you?"        │   │
│  │  الترجمة: "مرحباً، كيف حالك؟"           │   │
│  │                                         │   │
│  │  [← Swipe Left]           [Swipe Right →]│   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │  Know   │ │  Skip    │ │  Don't   │       │
│  │   ✓     │ │   ⏭     │ │    ✗    │       │
│  └──────────┘ └──────────┘ └──────────┘       │
│                                                 │
│  Progress: ████████░░░░░░░░░ 45/100            │
└─────────────────────────────────────────────────┘
```

#### Speaking Practice
```
┌─────────────────────────────────────────────────┐
│  🔙 Speaking Practice             [Settings]   │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │        🎤 SPEAK NOW                       │   │  ← Voice recognition
│  │                                         │   │
│  │  "Say: Hello, how are you?"             │   │
│  │                                         │   │
│  │           ┌───────────┐                │   │
│  │           │           │                │   │
│  │           │   🔊      │                │   │
│  │           │           │                │   │
│  │           │  Tap to   │                │   │
│  │           │   Speak   │                │   │
│  │           │           │                │   │
│  │           └───────────┘                │   │
│  │                                         │   │
│  │  Score: ⭐⭐⭐⭐⭐                          │   │
│  │                                         │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  💡 Tips for better pronunciation              │
│                                                 │
└─────────────────────────────────────────────────┘
```

#### Grammar Section
```
┌─────────────────────────────────────────────────┐
│  🔙 Grammar                        [Progress]  │
├─────────────────────────────────────────────────┤
│                                                 │
│  ✨ Level: Beginner                             │
│                                                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ Present  │ │ Past     │ │ Future   │       │
│  │  Tense    │ │  Tense   │ │  Tense   │       │
│  │  ✓✓✓     │ │  ○○○     │ │  ○○○     │       │
│  └──────────┘ └──────────┘ └──────────┘       │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │     📖 Lesson: Present Simple            │   │
│  │                                         │   │
│  │  Rule:                                 │   │
│  │  "We use Present Simple for habits..." │   │
│  │                                         │   │
│  │  📝 Examples:                          │   │
│  │  I play (أنا ألعب)                     │   │
│  │  He plays (هو يلعب)                    │   │
│  │                                         │   │
│  │  [Take Quiz]                           │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
└─────────────────────────────────────────────────┘
```

#### Listening Practice
```
┌─────────────────────────────────────────────────┐
│  🔙 Listening Practice           [Settings]    │
├─────────────────────────────────────────────────┤
│                                                 │
│  [▶] [⏸] ════════════════════ 1:30 / 3:00      │  ← Audio player
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │        👂 Native Speaker Audio          │   │
│  │                                         │   │
│  │  Speed: [0.75x] [1x] [1.25x]           │   │
│  │                                         │   │
│  │  "Hello and welcome to today's..."     │   │
│  │                                         │   │
│  │  الترجمة: "مرحباً وأهلاً بكم في..."    │   │
│  │                                         │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  [📝 Take Quiz]                                │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Responsive Strategy
```
Mobile (<768px):
- Single column layout
- Bottom navigation bar
- Full-width cards
- Large touch targets (min 44px)

Tablet (768px-1024px):
- 2-column grid for categories
- Side navigation optional
- Larger cards

Desktop (>1024px):
- 3-4 column grid
- Side navigation bar
- Multi-panel layouts
- Hover states
```

## 4. Features & Interactions

### Core Features

#### 1. Vocabulary Learning
- **Swipeable Flashcards**: Touch-friendly swipe gestures (left=skip, right=know)
- **Spaced Repetition**: SM-2 algorithm for optimal retention
- **Pronunciation**: Text-to-Speech with audio playback button
- **Progress Tracking**: Visual progress bar per category
- **Search**: Real-time search across all 6000+ words
- **Filters**: By category, difficulty, favorites

#### 2. Flashcards System
- **Swipe Animations**: Spring physics with velocity detection
- **Card Flip**: 3D flip animation to reveal translation
- **Audio**: Automatic pronunciation on card flip
- **Difficulty Badge**: Color-coded (Green=Easy, Orange=Medium, Red=Hard)
- **Favorite Toggle**: Heart/star icon with pulse animation
- **Streak Indicator**: Fire icon when on a learning streak

#### 3. Speaking Practice
- **Voice Recognition**: Web Speech API integration
- **Pronunciation Scoring**: Real-time feedback (0-100%)
- **Waveform Visualization**: Audio visualization during recording
- **Replay Option**: Listen to own recording
- **AI Conversation**: Predefined conversation flows with AI persona
- **Microphone Access**: Browser permission handling with clear UI

#### 4. Grammar Section
- **Level Progression**: Beginner → Intermediate → Advanced
- **Interactive Lessons**: Rich text with embedded examples
- **Quizzes**: Multiple choice, fill-in-blank, sentence ordering
- **Arabic Translation**: Full Arabic support for all explanations
- **Progress Tracking**: Completion percentage per topic

#### 5. Listening Practice
- **Audio Player**: Custom player with playback controls
- **Speed Control**: 0.75x, 1x, 1.25x, 1.5x
- **Subtitles**: Toggle Arabic/English/none
- **Repeat Mode**: Loop specific section
- **Slow Mode**: Slower playback for difficult parts
- **Quiz Mode**: Comprehension questions after audio

#### 6. Real-Life Conversations
- **Conversation Scripts**: 10 complete conversation templates
- **Role Play**: User can play either role
- **Translations**: Line-by-line Arabic translation
- **Audio Playback**: Native speaker pronunciation
- **Practice Mode**: Record and compare

#### 7. Numbers Learning
- **Interactive Number Grid**: 1-1000 with audio
- **Money Practice**: Currency formatting (USD, EUR, GBP)
- **Date Practice**: Multiple date formats
- **Time Practice**: Analog and digital clock
- **Phone Numbers**: Random phone number generation
- **Counting Exercises**: Progressive counting challenges

### Gamification Features

#### XP System
- **Earn XP**: 10 XP per correct answer, 50 XP per lesson complete
- **Bonus XP**: Streak multipliers (2x on 7-day streak)
- **Level Up**: Every 1000 XP, visual celebration
- **Leaderboard**: Weekly/monthly/all-time rankings

#### Streak System
- **Daily Login**: Earn streak by completing at least 1 lesson
- **Streak Freeze**: Protect streak once per week
- **Streak Milestones**: 7, 30, 100, 365 days
- **Visual Fire**: Animated fire icon intensity based on streak

#### Achievements & Badges
- **Category Master**: Complete all words in a category
- **Conversation Star**: Complete 10 conversations
- **Perfect Week**: 7 days of perfect scores
- **Night Owl**: Study after 10 PM
- **Early Bird**: Study before 7 AM
- **XP Hunter**: Earn 1000 XP in a day

#### Daily Challenges
- **Random Lesson**: Complete a random lesson
- **Speaking Challenge**: Practice 2 minutes of speaking
- **Listening Challenge**: Complete 3 listening exercises
- **Quiz Battle**: Challenge a friend

### Interaction Details

#### Card Swipe
- **Trigger**: >50px horizontal swipe
- **Animation**: Spring physics, ease-out
- **States**: Know (green glow + checkmark), Skip (gray), Don't Know (red glow)
- **Haptic**: Vibration feedback on mobile (if supported)

#### Pronunciation Button
- **Idle**: Speaker icon, blue
- **Playing**: Animated sound waves, purple
- **Error**: Red icon with retry button
- **Autoplay Option**: Toggle in settings

#### Voice Recording
- **Permission Flow**: Clear explanation → Allow/Deny → Ongoing indicator
- **Recording State**: Pulsing red indicator, waveform visualization
- **Processing State**: Spinner with "Analyzing..." text
- **Result State**: Score badge (0-100), encouraging message

### Edge Cases & Error States

#### No Microphone Access
- **Message**: "Microphone access is required for speaking practice"
- **Action**: "Open Settings" button linking to browser settings
- **Fallback**: Text input option to type instead of speak

#### Network Offline
- **Indicator**: Subtle offline icon in header
- **Data**: Show cached lessons, disable new downloads
- **Sync**: Queue progress, sync when online

#### Empty States
- **No Favorites**: "You haven't saved any words yet" + illustration
- **No Progress**: "Start your learning journey!" + CTA
- **Search No Results**: "No words found for '[query]'" + suggestions

## 5. Component Inventory

### Navigation Components

#### TopBar
- **States**: Default, Scrolled (shadow), Search open
- **Elements**: Logo, Search trigger, Profile avatar, Settings gear
- **Mobile**: Logo + hamburger menu

#### BottomNav (Mobile)
- **States**: Default, Active (highlighted), Notification badge
- **Items**: Home, Vocabulary, Speaking, Listening, Conversations, Numbers, Profile
- **Animation**: Active indicator slides with spring physics

#### SideNav (Desktop)
- **States**: Expanded, Collapsed (icon only)
- **Items**: Same as BottomNav + Settings
- **Hover**: Tooltip for collapsed state

### Card Components

#### WordCard
- **Default**: English word, Arabic translation, audio button, favorite button
- **Hover**: Subtle lift shadow
- **Flipped**: Shows example sentence
- **Loading**: Shimmer skeleton
- **Difficulty Indicators**: Border color based on level

#### CategoryCard
- **Default**: Icon, title, word count, progress bar
- **Hover**: Scale up, shadow lift
- **Active**: Glowing border
- **Locked**: Grayscale, lock icon
- **Completed**: Checkmark badge, green tint

#### FlashCard
- **Default**: Front side with word
- **Flipped**: 3D rotation showing translation
- **Swiped Right**: Green overlay, checkmark
- **Swiped Left**: Red overlay, X mark
- **Animating**: Spring physics movement

### Interactive Components

#### AudioButton
- **Idle**: Blue speaker icon
- **Loading**: Spinner
- **Playing**: Animated waves, filled icon
- **Error**: Red icon with retry

#### MicButton
- **Idle**: Blue mic icon
- **Requesting**: Pulsing outline
- **Recording**: Red pulsing, waveform
- **Processing**: Spinner
- **Complete**: Score badge

#### ProgressBar
- **Default**: Gray track, blue fill
- **Animated**: Smooth fill animation
- **Milestones**: Dots at 25%, 50%, 75%, 100%
- **Celebration**: Confetti at 100%

#### StreakCounter
- **Default**: Fire icon with number
- **At Risk**: Orange glow, warning pulse
- **Milestone**: Enhanced animation at 7, 30, 100
- **Broken**: Red, reset animation

### Form Components

#### SearchInput
- **Default**: Search icon, placeholder text
- **Focused**: Blue border, expanded width
- **With Results**: Dropdown suggestions
- **Loading**: Inline spinner

#### QuizOption
- **Default**: Outlined card
- **Hover**: Border highlight
- **Selected**: Filled blue, checkmark
- **Correct**: Green background, checkmark
- **Incorrect**: Red background, X mark

## 6. Technical Approach

### Architecture
```
src/
├── components/
│   ├── ui/           # Reusable UI components
│   ├── layout/       # Navigation, layout wrappers
│   ├── vocabulary/   # Vocabulary-specific components
│   ├── speaking/     # Speaking practice components
│   ├── grammar/      # Grammar lesson components
│   ├── listening/    # Listening practice components
│   └── gamification/ # XP, streaks, badges
├── data/
│   ├── vocabulary.ts    # 6000+ words database
│   ├── conversations.ts # Real-life conversation scripts
│   ├── grammar.ts       # Grammar lessons
│   └── categories.ts    # Category definitions
├── hooks/
│   ├── useSpeechRecognition.ts
│   ├── useTextToSpeech.ts
│   ├── useLocalStorage.ts
│   └── useSpacedRepetition.ts
├── pages/
│   ├── Home.tsx
│   ├── Vocabulary.tsx
│   ├── Speaking.tsx
│   ├── Grammar.tsx
│   ├── Listening.tsx
│   ├── Conversations.tsx
│   ├── Numbers.tsx
│   └── Profile.tsx
├── context/
│   ├── ProgressContext.tsx
│   └── ThemeContext.tsx
├── lib/
│   ├── storage.ts    # LocalStorage utilities
│   ├── audio.ts      # Text-to-speech utilities
│   └── gamification.ts # XP, streak calculations
└── types/
    └── index.ts      # TypeScript interfaces
```

### State Management
- **React Context**: Theme, User Progress, Audio State
- **LocalStorage**: Persisted user data, progress, settings
- **Component State**: UI interactions, form inputs

### Data Structure

#### Word Interface
```typescript
interface Word {
  id: string;
  english: string;
  arabic: string;
  pronunciation: string; // phonetic spelling
  example: string;
  exampleArabic: string;
  audioUrl?: string; // TTS generated
  category: CategoryId;
  difficulty: 1 | 2 | 3;
  wordType: 'vocabulary' | 'verb' | 'adjective' | 'phrase' | 'idiom';
  frequency: number; // for spaced repetition
  nextReview: Date;
  lastReviewed: Date;
}
```

#### Progress Interface
```typescript
interface UserProgress {
  xp: number;
  level: number;
  streak: number;
  lastActiveDate: string;
  completedWords: string[];
  favoriteWords: string[];
  categoryProgress: Record<string, number>;
  dailyChallenges: DailyChallenge[];
  achievements: string[];
  totalWordsLearned: number;
  totalMinutesSpent: number;
}
```

#### Category Interface
```typescript
interface Category {
  id: string;
  name: string;
  nameArabic: string;
  icon: string; // Lucide icon name
  color: string; // Gradient start color
  wordCount: number;
  difficulty: 1 | 2 | 3;
  description: string;
  descriptionArabic: string;
}
```

### Technology Stack
- **Framework**: React 18 + TypeScript
- **Styling**: Tailwind CSS v3
- **Animations**: Framer Motion
- **Icons**: Lucide React
- **Routing**: React Router v6
- **Storage**: LocalStorage (IndexedDB for offline)
- **Audio**: Web Speech API (SpeechSynthesis + SpeechRecognition)
- **State**: React Context + useReducer

### API Integration
- **Speech Synthesis**: Browser's native Text-to-Speech API
- **Speech Recognition**: Browser's native Speech Recognition API
- **No Backend**: All data stored locally for MVP

### Performance Targets
- **First Contentful Paint**: <1.5s
- **Time to Interactive**: <3s
- **Largest Contentful Paint**: <2.5s
- **Cumulative Layout Shift**: <0.1

### Accessibility
- **WCAG 2.1 AA Compliance**
- **Keyboard Navigation**: Full support
- **Screen Reader**: ARIA labels, semantic HTML
- **Color Contrast**: Minimum 4.5:1 ratio
- **Touch Targets**: Minimum 44x44px

## 7. Content Data

### 17 Learning Categories
1. **Daily Conversations** - 400 words
2. **Restaurant English** - 350 words
3. **Travel and Airports** - 400 words
4. **Hotels and Booking** - 300 words
5. **Shopping and Supermarket** - 350 words
6. **Cars and Transportation** - 300 words
7. **School and Education** - 400 words
8. **Business English** - 450 words
9. **Technology** - 400 words
10. **Food and Drinks** - 350 words
11. **Family and Friends** - 400 words
12. **Jobs and Work** - 350 words
13. **Numbers and Counting** - 500 words
14. **Time and Dates** - 350 words
15. **Weather** - 300 words
16. **Emergency Phrases** - 300 words
17. **Common Verbs** - 400 words
18. **Common Adjectives** - 400 words
19. **Idioms and Expressions** - 450 words

**Total**: 6,250+ words and phrases

## 8. Real-Life Conversations

### 10 Conversation Templates
1. **Ordering Food** - Restaurant ordering flow
2. **Airport Check-in** - Boarding pass, luggage
3. **Hotel Reservation** - Booking, check-in, complaints
4. **Driving Situations** - Rental car, traffic stop
5. **Asking for Directions** - Street navigation
6. **Shopping** - In-store, checkout, returns
7. **School Conversations** - Teachers, classmates
8. **Talking with Friends** - Casual social
9. **Work Meetings** - Professional presentations
10. **Emergency Situations** - Police, hospital, lost

Each conversation includes:
- 8-12 exchange lines
- Audio for each line
- Arabic translation
- Key vocabulary highlighted
- Cultural notes
