import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { ProgressProvider } from './context/ProgressContext';
import { Navbar, BottomNav } from './components/layout/Navigation';
import { Home } from './pages/Home';
import { Vocabulary } from './pages/Vocabulary';
import { Speaking } from './pages/Speaking';
import { Listening } from './pages/Listening';
import { Conversations } from './pages/Conversations';
import { Grammar } from './pages/Grammar';
import { Numbers } from './pages/Numbers';
import { Profile } from './pages/Profile';
import './App.css';

function App() {
  return (
    <ThemeProvider>
      <ProgressProvider>
        <BrowserRouter>
          <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300">
            <Navbar />
            <main className="pt-16 md:pt-16">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/vocabulary" element={<Vocabulary />} />
                <Route path="/vocabulary/:categoryId" element={<Vocabulary />} />
                <Route path="/speaking" element={<Speaking />} />
                <Route path="/listening" element={<Listening />} />
                <Route path="/conversations" element={<Conversations />} />
                <Route path="/conversations/:id" element={<Conversations />} />
                <Route path="/grammar" element={<Grammar />} />
                <Route path="/numbers" element={<Numbers />} />
                <Route path="/profile" element={<Profile />} />
              </Routes>
            </main>
            <BottomNav />
          </div>
        </BrowserRouter>
      </ProgressProvider>
    </ThemeProvider>
  );
}

export default App;
