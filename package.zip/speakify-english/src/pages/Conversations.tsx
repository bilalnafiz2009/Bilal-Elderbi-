import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  ChevronLeft, ChevronRight, MessageCircle, Volume2,
  RefreshCw, CheckCircle, User
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { conversations, speakingPractice } from '../data/vocabulary';
import { useTextToSpeech } from '../hooks';
import type { Conversation } from '../types';

export function Conversations() {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [isRolePlaying, setIsRolePlaying] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'person1' | 'person2' | null>(null);
  const [completedLines, setCompletedLines] = useState<number[]>([]);

  const { isDark } = useTheme();
  const { addXP } = useProgress();
  const { speak } = useTextToSpeech();

  const currentLine = selectedConversation?.lines[currentLineIndex];

  // Auto-play current line
  useEffect(() => {
    if (selectedConversation && currentLine && !isRolePlaying) {
      setTimeout(() => {
        speak(currentLine.english, 'en-US');
      }, 500);
    }
  }, [currentLineIndex, selectedConversation, currentLine, speak, isRolePlaying]);

  const handleNextLine = () => {
    if (selectedConversation && currentLineIndex < selectedConversation.lines.length - 1) {
      if (!completedLines.includes(currentLineIndex)) {
        setCompletedLines(prev => [...prev, currentLineIndex]);
        addXP(10);
      }
      setCurrentLineIndex(prev => prev + 1);
    } else if (currentLineIndex === selectedConversation.lines.length - 1) {
      // Exercise completed
      if (!completedLines.includes(currentLineIndex)) {
        setCompletedLines(prev => [...prev, currentLineIndex]);
        addXP(10);
      }
      addXP(30);
    }
  };

  const handlePreviousLine = () => {
    if (currentLineIndex > 0) {
      setCurrentLineIndex(prev => prev - 1);
    }
  };

  const handleLineClick = (index: number) => {
    setCurrentLineIndex(index);
    if (selectedConversation) {
      speak(selectedConversation.lines[index].english, 'en-US');
    }
  };

  const handleStartRolePlay = () => {
    setIsRolePlaying(true);
    setCurrentLineIndex(0);
    setCompletedLines([]);
  };

  const handleStopRolePlay = () => {
    setIsRolePlaying(false);
    setSelectedRole(null);
    setCurrentLineIndex(0);
  };

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-6 pt-6 pb-4 ${
        isDark ? 'bg-slate-800' : 'bg-white'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Real Conversations
            </h1>
            <p className="text-gray-500 dark:text-gray-400">
              Learn everyday English
            </p>
          </div>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Conversation Selection */}
        {!selectedConversation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {conversations.map((conversation, index) => (
                <motion.button
                  key={conversation.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setSelectedConversation(conversation);
                    setCurrentLineIndex(0);
                    setCompletedLines([]);
                  }}
                  className={`p-5 rounded-2xl text-left border ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 hover:border-green-500'
                      : 'bg-white border-gray-100 hover:border-green-400'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-2xl flex-shrink-0">
                      {conversation.id === 'restaurant-ordering' && '🍽️'}
                      {conversation.id === 'airport-checkin' && '✈️'}
                      {conversation.id === 'hotel-booking' && '🏨'}
                      {conversation.id === 'directions' && '🗺️'}
                      {conversation.id === 'work-meeting' && '💼'}
                    </div>
                    <div className="flex-1">
                      <div className="font-bold text-gray-900 dark:text-white mb-1">
                        {conversation.title}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                        {conversation.titleArabic}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <MessageCircle className="w-3 h-3" />
                        <span>{conversation.lines.length} exchanges</span>
                      </div>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Speaking Practice Shortcuts */}
            <div className="mt-8">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                Quick Practice
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {speakingPractice.slice(0, 8).map((item) => (
                  <motion.button
                    key={item.id}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => speak(item.targetPhrase, 'en-US')}
                    className={`p-4 rounded-xl border ${
                      isDark
                        ? 'bg-slate-800 border-slate-700'
                        : 'bg-white border-gray-100'
                    }`}
                  >
                    <Volume2 className="w-5 h-5 text-blue-500 mb-2" />
                    <div className="text-xs text-gray-900 dark:text-white line-clamp-2">
                      {item.targetPhrase}
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Conversation View */}
        {selectedConversation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {/* Back Button */}
            <button
              onClick={() => {
                setSelectedConversation(null);
                setIsRolePlaying(false);
                setSelectedRole(null);
                setCurrentLineIndex(0);
                setCompletedLines([]);
              }}
              className={`mb-4 flex items-center gap-2 text-sm ${
                isDark ? 'text-gray-400 hover:text-gray-200' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              ← Back to conversations
            </button>

            {/* Title */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                  {selectedConversation.title}
                </h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {selectedConversation.titleArabic}
                </p>
              </div>
              {!isRolePlaying ? (
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleStartRolePlay}
                  className="px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold text-sm flex items-center gap-2"
                >
                  <User className="w-4 h-4" />
                  Role Play
                </motion.button>
              ) : (
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleStopRolePlay}
                  className="px-4 py-2 bg-red-500 text-white rounded-xl font-semibold text-sm"
                >
                  Stop
                </motion.button>
              )}
            </div>

            {/* Progress */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2 text-sm">
                <span className="text-gray-500 dark:text-gray-400">
                  Line {currentLineIndex + 1} of {selectedConversation.lines.length}
                </span>
                <span className="text-gray-500 dark:text-gray-400">
                  {completedLines.length} / {selectedConversation.lines.length} completed
                </span>
              </div>
              <div className="h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(currentLineIndex / selectedConversation.lines.length) * 100}%` }}
                  className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                />
              </div>
            </div>

            {/* Role Selection */}
            {isRolePlaying && !selectedRole && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-6 rounded-2xl mb-6 ${
                  isDark ? 'bg-slate-800' : 'bg-white'
                }`}
              >
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 text-center">
                  Choose Your Role
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedRole('person1')}
                    className="p-6 rounded-xl bg-blue-500/20 border-2 border-blue-500 text-center"
                  >
                    <div className="text-3xl mb-2">👤</div>
                    <div className="font-bold text-blue-500">Person 1</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {selectedConversation.lines.filter(l => l.speaker === 'person1').length} lines
                    </div>
                  </motion.button>
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedRole('person2')}
                    className="p-6 rounded-xl bg-purple-500/20 border-2 border-purple-500 text-center"
                  >
                    <div className="text-3xl mb-2">👤</div>
                    <div className="font-bold text-purple-500">Person 2</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {selectedConversation.lines.filter(l => l.speaker === 'person2').length} lines
                    </div>
                  </motion.button>
                </div>
              </motion.div>
            )}

            {/* Main Content */}
            {(!isRolePlaying || selectedRole) && (
              <div className={`p-6 rounded-3xl ${
                isDark ? 'bg-slate-800' : 'bg-white'
              } shadow-xl mb-6`}>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentLineIndex}
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    className={`p-5 rounded-2xl mb-4 ${
                      currentLine?.speaker === 'person1'
                        ? 'bg-blue-500/10 border-l-4 border-blue-500'
                        : 'bg-purple-500/10 border-l-4 border-purple-500'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                        currentLine?.speaker === 'person1'
                          ? 'bg-blue-500/20 text-blue-500'
                          : 'bg-purple-500/20 text-purple-500'
                      }`}>
                        {currentLine?.speaker === 'person1' ? 'You' : selectedRole ? 'AI Partner' : 'Person 2'}
                      </span>
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => currentLine && speak(currentLine.english, 'en-US')}
                        className="p-2 rounded-full bg-blue-500/20 text-blue-500"
                      >
                        <Volume2 className="w-4 h-4" />
                      </motion.button>
                    </div>
                    <div className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      {currentLine?.english}
                    </div>
                    <div className="text-gray-600 dark:text-gray-300">
                      {currentLine?.arabic}
                    </div>
                  </motion.div>
                </AnimatePresence>

                {/* Navigation */}
                <div className="flex items-center justify-between">
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={handlePreviousLine}
                    disabled={currentLineIndex === 0}
                    className={`p-3 rounded-xl ${
                      currentLineIndex === 0
                        ? 'opacity-30 cursor-not-allowed'
                        : ''
                    } ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </motion.button>

                  {/* Dots */}
                  <div className="flex gap-1">
                    {selectedConversation.lines.map((_, index) => (
                      <motion.button
                        key={index}
                        whileTap={{ scale: 1.2 }}
                        onClick={() => handleLineClick(index)}
                        className={`w-2.5 h-2.5 rounded-full transition-colors ${
                          index === currentLineIndex
                            ? 'bg-blue-500'
                            : completedLines.includes(index)
                              ? 'bg-green-500'
                              : isDark ? 'bg-slate-600' : 'bg-gray-300'
                        }`}
                      />
                    ))}
                  </div>

                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={handleNextLine}
                    className="p-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 text-white"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </motion.button>
                </div>
              </div>
            )}

            {/* All Lines */}
            <div className={`rounded-2xl p-4 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-3 text-sm">
                All Lines
              </h3>
              <div className="space-y-2">
                {selectedConversation.lines.map((line, index) => (
                  <motion.button
                    key={line.id}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleLineClick(index)}
                    className={`w-full p-3 rounded-xl text-left transition-colors flex items-start gap-3 ${
                      index === currentLineIndex
                        ? 'bg-blue-500/20 border border-blue-500'
                        : completedLines.includes(index)
                          ? 'bg-green-500/20'
                          : isDark
                            ? 'hover:bg-slate-700'
                            : 'hover:bg-gray-50'
                    }`}
                  >
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                      line.speaker === 'person1'
                        ? 'bg-blue-500/20 text-blue-500'
                        : 'bg-purple-500/20 text-purple-500'
                    }`}>
                      {index + 1}
                    </span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-900 dark:text-white">
                        {line.english}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {line.arabic}
                      </div>
                    </div>
                    {completedLines.includes(index) && (
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    )}
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
