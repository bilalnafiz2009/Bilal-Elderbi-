import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft, ChevronRight, BookOpen, CheckCircle, XCircle,
  Volume2, Lightbulb
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { grammarLessons } from '../data/vocabulary';
import { useTextToSpeech } from '../hooks';
import type { GrammarLesson } from '../types';

export function Grammar() {
  const [selectedLesson, setSelectedLesson] = useState<GrammarLesson | null>(null);
  const [currentExampleIndex, setCurrentExampleIndex] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [selectedLevel, setSelectedLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');

  const { isDark } = useTheme();
  const { addXP } = useProgress();
  const { speak } = useTextToSpeech();

  const levelColors = {
    beginner: 'from-green-500 to-emerald-500',
    intermediate: 'from-yellow-500 to-orange-500',
    advanced: 'from-red-500 to-pink-500',
  };

  const levelLabels: Record<string, string> = {
    beginner: 'مبتدئ',
    intermediate: 'متوسط',
    advanced: 'متقدم',
  };

  const filteredLessons = grammarLessons.filter(l => l.level === selectedLevel);
  const currentExample = selectedLesson?.examples[currentExampleIndex];

  const handleSelectLesson = (lesson: GrammarLesson) => {
    setSelectedLesson(lesson);
    setCurrentExampleIndex(0);
    setShowQuiz(false);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  const handleNextExample = () => {
    if (selectedLesson && currentExampleIndex < selectedLesson.examples.length - 1) {
      setCurrentExampleIndex(prev => prev + 1);
    } else {
      setShowQuiz(true);
    }
  };

  const handlePreviousExample = () => {
    if (currentExampleIndex > 0) {
      setCurrentExampleIndex(prev => prev - 1);
    }
  };

  const handleAnswerClick = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
  };

  const handleCheckAnswer = () => {
    if (selectedAnswer === null || !selectedLesson) return;
    const exercise = selectedLesson.exercises[0];
    if (exercise.type === 'multiple-choice' && selectedAnswer === exercise.correctAnswer) {
      setScore(prev => prev + 1);
      addXP(15);
    }
    setShowResult(true);
  };

  const handleNextQuiz = () => {
    if (selectedLesson && currentQuestionIndex < selectedLesson.exercises.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      // Quiz complete
      addXP(50);
      setShowQuiz(false);
      setSelectedLesson(null);
    }
  };

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-6 pt-6 pb-4 ${
        isDark ? 'bg-slate-800' : 'bg-white'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Grammar
            </h1>
            <p className="text-gray-500 dark:text-gray-400">
              Learn English grammar rules
            </p>
          </div>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Level Selection */}
        {!selectedLesson && !showQuiz && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
              {(['beginner', 'intermediate', 'advanced'] as const).map((level) => (
                <motion.button
                  key={level}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedLevel(level)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                    selectedLevel === level
                      ? `bg-gradient-to-r ${levelColors[level]} text-white shadow-lg`
                      : isDark
                        ? 'bg-slate-800 text-gray-300'
                        : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {level.charAt(0).toUpperCase() + level.slice(1)} ({levelLabels[level]})
                </motion.button>
              ))}
            </div>

            {/* Lessons Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredLessons.map((lesson, index) => (
                <motion.button
                  key={lesson.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectLesson(lesson)}
                  className={`p-5 rounded-2xl text-left border ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 hover:border-orange-500'
                      : 'bg-white border-gray-100 hover:border-orange-400'
                  }`}
                >
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${levelColors[lesson.level]} text-white mb-3`}>
                    <BookOpen className="w-3 h-3" />
                    {lesson.level}
                  </div>
                  <div className="font-bold text-gray-900 dark:text-white mb-1">
                    {lesson.title}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                    {lesson.titleArabic}
                  </div>
                  <div className="text-xs text-gray-400">
                    {lesson.exercises.length} exercises
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Lesson View */}
        {selectedLesson && !showQuiz && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {/* Back Button */}
            <button
              onClick={() => {
                setSelectedLesson(null);
                setCurrentExampleIndex(0);
              }}
              className={`mb-4 flex items-center gap-2 text-sm ${
                isDark ? 'text-gray-400 hover:text-gray-200' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              ← Back to lessons
            </button>

            {/* Lesson Title */}
            <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium mb-4 ${
              isDark ? 'bg-slate-700 text-gray-300' : 'bg-gray-100 text-gray-600'
            }`}>
              {selectedLesson.level}
            </div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              {selectedLesson.title}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              {selectedLesson.titleArabic}
            </p>

            {/* Content Card */}
            <div className={`p-6 rounded-2xl mb-6 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            } shadow-xl`}>
              <div className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                {selectedLesson.content}
              </div>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                {selectedLesson.contentArabic}
              </div>

              {/* Examples */}
              <div className="border-t border-gray-200 dark:border-slate-700 pt-4 mt-4">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
                    Example {currentExampleIndex + 1} of {selectedLesson.examples.length}
                  </span>
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={() => currentExample && speak(currentExample.english, 'en-US')}
                    className="p-2 rounded-full bg-blue-500/20 text-blue-500"
                  >
                    <Volume2 className="w-4 h-4" />
                  </motion.button>
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentExampleIndex}
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    className={`p-4 rounded-xl ${
                      isDark ? 'bg-slate-700' : 'bg-gray-50'
                    }`}
                  >
                    <div className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                      "{currentExample?.english}"
                    </div>
                    <div className="text-gray-600 dark:text-gray-300 mb-3">
                      {currentExample?.arabic}
                    </div>
                    <div className="flex items-start gap-2 p-3 bg-blue-500/10 rounded-lg">
                      <Lightbulb className="w-4 h-4 text-blue-500 mt-0.5" />
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        <span className="font-medium text-blue-500">Rule: </span>
                        {currentExample?.explanation}
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>

                {/* Navigation */}
                <div className="flex items-center justify-between mt-4">
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={handlePreviousExample}
                    disabled={currentExampleIndex === 0}
                    className={`p-3 rounded-xl ${
                      currentExampleIndex === 0
                        ? 'opacity-30 cursor-not-allowed'
                        : ''
                    } ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </motion.button>

                  <div className="flex gap-1">
                    {selectedLesson.examples.map((_, index) => (
                      <div
                        key={index}
                        className={`w-2 h-2 rounded-full ${
                          index === currentExampleIndex
                            ? 'bg-blue-500'
                            : index < currentExampleIndex
                              ? 'bg-green-500'
                              : isDark ? 'bg-slate-600' : 'bg-gray-300'
                        }`}
                      />
                    ))}
                  </div>

                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={handleNextExample}
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white font-semibold flex items-center gap-2"
                  >
                    {currentExampleIndex < selectedLesson.examples.length - 1 ? (
                      <>Next <ChevronRight className="w-4 h-4" /></>
                    ) : (
                      <>Take Quiz <ChevronRight className="w-4 h-4" /></>
                    )}
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Quiz View */}
        {showQuiz && selectedLesson && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {/* Quiz Header */}
            <div className={`p-4 rounded-2xl mb-6 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Question {currentQuestionIndex + 1} of {selectedLesson.exercises.length}
                </span>
                <span className={`text-sm font-bold ${
                  score > 0 ? 'text-green-500' : 'text-gray-400'
                }`}>
                  Score: {score}
                </span>
              </div>
              <div className="h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentQuestionIndex + 1) / selectedLesson.exercises.length) * 100}%` }}
                  className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full"
                />
              </div>
            </div>

            {/* Question Card */}
            <div className={`p-6 rounded-2xl mb-6 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            } shadow-xl`}>
              <div className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                {selectedLesson.exercises[currentQuestionIndex]?.question}
              </div>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                {selectedLesson.exercises[currentQuestionIndex]?.questionArabic}
              </div>

              {/* Options */}
              <div className="space-y-3">
                {selectedLesson.exercises[currentQuestionIndex]?.options?.map((option, index) => {
                  const isCorrect = index === selectedLesson.exercises[currentQuestionIndex].correctAnswer;
                  const isSelected = selectedAnswer === index;

                  return (
                    <motion.button
                      key={index}
                      whileTap={{ scale: showResult ? 1 : 0.98 }}
                      onClick={() => handleAnswerClick(index)}
                      disabled={showResult}
                      className={`w-full p-4 rounded-xl text-left border-2 transition-all ${
                        showResult
                          ? isCorrect
                            ? 'border-green-500 bg-green-500/20'
                            : isSelected
                              ? 'border-red-500 bg-red-500/20'
                              : 'border-gray-200 dark:border-slate-700'
                          : isSelected
                            ? 'border-blue-500 bg-blue-500/10'
                            : isDark
                              ? 'border-slate-700 hover:border-slate-600'
                              : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                          showResult
                            ? isCorrect
                              ? 'bg-green-500 text-white'
                              : isSelected
                                ? 'bg-red-500 text-white'
                                : ''
                            : isSelected
                              ? 'bg-blue-500 text-white'
                              : isDark
                                ? 'bg-slate-700 text-gray-300'
                                : 'bg-gray-100 text-gray-600'
                        }`}>
                          {showResult ? (
                            isCorrect ? <CheckCircle className="w-4 h-4" /> : isSelected ? <XCircle className="w-4 h-4" /> : String.fromCharCode(65 + index)
                          ) : (
                            String.fromCharCode(65 + index)
                          )}
                        </div>
                        <span className="text-gray-900 dark:text-white">{option}</span>
                      </div>
                    </motion.button>
                  );
                })}
              </div>

              {/* Result */}
              {showResult && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`mt-4 p-4 rounded-xl ${
                    selectedAnswer === selectedLesson.exercises[currentQuestionIndex].correctAnswer
                      ? 'bg-green-500/20 border border-green-500'
                      : 'bg-red-500/20 border border-red-500'
                  }`}
                >
                  <div className={`font-bold ${
                    selectedAnswer === selectedLesson.exercises[currentQuestionIndex].correctAnswer
                      ? 'text-green-500'
                      : 'text-red-500'
                  }`}>
                    {selectedAnswer === selectedLesson.exercises[currentQuestionIndex].correctAnswer
                      ? 'Correct! Well done!'
                      : 'Not quite right. Keep trying!'}
                  </div>
                </motion.div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end">
              {!showResult ? (
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleCheckAnswer}
                  disabled={selectedAnswer === null}
                  className={`px-6 py-3 rounded-xl font-semibold ${
                    selectedAnswer === null
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                  }`}
                >
                  Check Answer
                </motion.button>
              ) : (
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleNextQuiz}
                  className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold flex items-center gap-2"
                >
                  {currentQuestionIndex < selectedLesson.exercises.length - 1 ? (
                    <>Next Question <ChevronRight className="w-4 h-4" /></>
                  ) : (
                    <>Finish Quiz <ChevronRight className="w-4 h-4" /></>
                  )}
                </motion.button>
              )}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
