import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ChevronLeft, Search, Filter, BookOpen, Shuffle,
  Star, Mic, Volume2
} from 'lucide-react';
import { categories } from '../data/categories';
import { getWordsByCategory, searchWords } from '../data/vocabulary';
import { useProgress } from '../context/ProgressContext';
import { useTheme } from '../context/ThemeContext';
import { useTextToSpeech } from '../hooks';
import { Flashcard } from '../components/ui/Cards';
import type { Word } from '../types';

type Difficulty = 'all' | 1 | 2 | 3;
type WordType = 'all' | 'vocabulary' | 'verb' | 'adjective' | 'phrase' | 'idiom';

export function Vocabulary() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('all');
  const [wordType, setWordType] = useState<WordType>('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [flashcardMode, setFlashcardMode] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [knownWords, setKnownWords] = useState<string[]>([]);
  const [isShuffled, setIsShuffled] = useState(false);

  const { categoryId } = useParams();
  const navigate = useNavigate();
  const { updateCategoryProgress, addXP, toggleFavorite, isFavorite, markWordComplete } = useProgress();
  const { isDark } = useTheme();
  const { speak, isSpeaking } = useTextToSpeech();

  // Get current category info
  const currentCategory = categoryId
    ? categories.find(c => c.id === categoryId)
    : null;

  // Get words based on selection
  const getFilteredWords = useCallback((): Word[] => {
    let words: Word[] = [];

    if (selectedCategory) {
      words = getWordsByCategory(selectedCategory);
    } else if (searchQuery) {
      words = searchWords(searchQuery);
    } else if (currentCategory) {
      words = getWordsByCategory(currentCategory.id);
    }

    // Apply filters
    if (difficulty !== 'all') {
      words = words.filter(w => w.difficulty === difficulty);
    }
    if (wordType !== 'all') {
      words = words.filter(w => w.wordType === wordType);
    }
    if (showFavoritesOnly) {
      words = words.filter(w => isFavorite(w.id));
    }

    return isShuffled ? [...words].sort(() => Math.random() - 0.5) : words;
  }, [selectedCategory, currentCategory, searchQuery, difficulty, wordType, showFavoritesOnly, isShuffled, isFavorite]);

  const words = getFilteredWords();
  const currentWord = words[currentCardIndex];

  const handleSwipe = (direction: 'left' | 'right') => {
    if (currentWord) {
      if (direction === 'right') {
        setKnownWords(prev => [...prev, currentWord.id]);
        markWordComplete(currentWord.id);
        addXP(10);
      }
    }

    if (currentCardIndex < words.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
    } else {
      // Session complete
      setFlashcardMode(false);
      if (currentCategory) {
        const progress = (knownWords.length / words.length) * 100;
        updateCategoryProgress(currentCategory.id, progress);
      }
    }
  };

  const handleSpeak = (word: Word) => {
    speak(word.english, 'en-US');
  };

  const shuffleWords = () => {
    setIsShuffled(prev => !prev);
  };

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`sticky top-16 z-30 px-4 py-4 backdrop-blur-md ${
        isDark ? 'bg-slate-900/95' : 'bg-white/95'
      } border-b ${isDark ? 'border-slate-700' : 'border-gray-200'}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => navigate(-1)}
              className={`p-2 rounded-xl ${isDark ? 'bg-slate-800' : 'bg-gray-100'}`}
            >
              <ChevronLeft className="w-5 h-5" />
            </motion.button>
            <div>
              <h1 className="font-bold text-lg text-gray-900 dark:text-white">
                {currentCategory?.name || 'All Vocabulary'}
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {words.length} words available
              </p>
            </div>
          </div>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={shuffleWords}
            className={`p-3 rounded-xl ${isDark ? 'bg-slate-800' : 'bg-gray-100'}`}
          >
            <Shuffle className={`w-5 h-5 ${isShuffled ? 'text-blue-500' : ''}`} />
          </motion.button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search 6000+ words..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-10 pr-4 py-3 rounded-xl ${
              isDark
                ? 'bg-slate-800 text-white placeholder-gray-400 border-slate-700'
                : 'bg-gray-100 text-gray-900 placeholder-gray-400 border-gray-200'
            } border focus:outline-none focus:ring-2 focus:ring-blue-500`}
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setDifficulty('all')}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              difficulty === 'all'
                ? 'bg-blue-500 text-white'
                : isDark
                  ? 'bg-slate-800 text-gray-300'
                  : 'bg-gray-100 text-gray-600'
            }`}
          >
            All Levels
          </motion.button>
          {[1, 2, 3].map(level => (
            <motion.button
              key={level}
              whileTap={{ scale: 0.95 }}
              onClick={() => setDifficulty(level as Difficulty)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                difficulty === level
                  ? level === 1 ? 'bg-green-500 text-white'
                    : level === 2 ? 'bg-yellow-500 text-white'
                    : 'bg-red-500 text-white'
                  : isDark
                    ? 'bg-slate-800 text-gray-300'
                    : 'bg-gray-100 text-gray-600'
              }`}
            >
              Level {level}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Categories Grid (when no category selected) */}
      {!selectedCategory && !searchQuery && !currentCategory && (
        <div className="px-4 py-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map((category) => (
              <motion.div
                key={category.id}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setSelectedCategory(category.id)}
                className={`p-4 rounded-2xl cursor-pointer border ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 hover:border-slate-600'
                    : 'bg-white border-gray-100 hover:border-gray-300'
                } shadow-sm`}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-3 text-2xl"
                  style={{ backgroundColor: `${category.color}20` }}
                >
                  {category.id === 'daily-conversations' && '💬'}
                  {category.id === 'restaurant' && '🍽️'}
                  {category.id === 'travel-airports' && '✈️'}
                  {category.id === 'hotels-booking' && '🏨'}
                  {category.id === 'shopping-supermarket' && '🛒'}
                  {category.id === 'cars-transportation' && '🚗'}
                  {category.id === 'school-education' && '📚'}
                  {category.id === 'business-english' && '💼'}
                  {category.id === 'technology' && '💻'}
                  {category.id === 'food-drinks' && '🍕'}
                  {category.id === 'family-friends' && '👨‍👩‍👧‍👦'}
                  {category.id === 'jobs-work' && '💼'}
                  {category.id === 'numbers-counting' && '🔢'}
                  {category.id === 'time-dates' && '📅'}
                  {category.id === 'weather' && '🌤️'}
                  {category.id === 'emergency-phrases' && '⚠️'}
                  {category.id === 'common-verbs' && '🏃'}
                  {category.id === 'common-adjectives' && '✨'}
                  {category.id === 'idioms-expressions' && '💡'}
                </div>
                <div className="font-semibold text-gray-900 dark:text-white text-sm mb-1">
                  {category.name}
                </div>
                <div className="text-xs text-gray-500 mb-2">{category.nameArabic}</div>
                <div className="text-xs text-gray-400">
                  {category.description}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Selected Category Words */}
      {(selectedCategory || currentCategory || searchQuery) && (
        <div className="px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="text-sm text-gray-500 dark:text-gray-400">
              showing {words.length} words
            </div>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setFlashcardMode(true);
                setCurrentCardIndex(0);
                setKnownWords([]);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold"
            >
              <BookOpen className="w-4 h-4" />
              Start Learning
            </motion.button>
          </div>

          {/* Words List */}
          <div className="space-y-3">
            {words.slice(0, 50).map((word, index) => (
              <motion.div
                key={word.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className={`p-4 rounded-2xl border ${isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100'}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold text-gray-900 dark:text-white">
                        {word.english}
                      </span>
                      <motion.button
                        whileTap={{ scale: 0.8 }}
                        onClick={() => handleSpeak(word)}
                        className="p-2 rounded-full bg-blue-500/20 text-blue-500"
                      >
                        <Volume2 className="w-4 h-4" />
                      </motion.button>
                    </div>
                    <div className="text-gray-600 dark:text-gray-300 mt-1">
                      {word.arabic}
                    </div>
                    <div className="text-sm text-gray-400 italic mt-1">
                      /{word.pronunciation}/
                    </div>
                  </div>
                  <motion.button
                    whileTap={{ scale: 0.8 }}
                    onClick={() => toggleFavorite(word.id)}
                    className={`p-2 ${isFavorite(word.id) ? 'text-pink-500' : 'text-gray-300'}`}
                  >
                    <Star className={`w-5 h-5 ${isFavorite(word.id) ? 'fill-current' : ''}`} />
                  </motion.button>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex gap-1">
                    {[1, 2, 3].slice(0, word.difficulty).map((i) => (
                      <div
                        key={i}
                        className={`w-2 h-2 rounded-full ${
                          word.difficulty === 1 ? 'bg-green-500'
                            : word.difficulty === 2 ? 'bg-yellow-500'
                            : 'bg-red-500'
                        }`}
                      />
                    ))}
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    word.wordType === 'verb' ? 'bg-blue-500/20 text-blue-500'
                      : word.wordType === 'adjective' ? 'bg-purple-500/20 text-purple-500'
                      : word.wordType === 'idiom' ? 'bg-yellow-500/20 text-yellow-600'
                      : 'bg-gray-500/20 text-gray-500'
                  }`}>
                    {word.wordType}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Flashcard Modal */}
      <AnimatePresence>
        {flashcardMode && currentWord && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end md:items-center justify-center p-4"
            onClick={() => setFlashcardMode(false)}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className={`w-full max-w-lg rounded-t-3xl md:rounded-3xl p-6 ${
                isDark ? 'bg-slate-800' : 'bg-white'
              }`}
            >
              {/* Progress */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    Card {currentCardIndex + 1} of {words.length}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {Math.round((currentCardIndex / words.length) * 100)}%
                  </span>
                </div>
                <div className="h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(currentCardIndex / words.length) * 100}%` }}
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
                  />
                </div>
              </div>

              {/* Flashcard */}
              <Flashcard
                word={currentWord}
                onSwipe={handleSwipe}
                onSpeak={() => handleSpeak(currentWord)}
                isSpeaking={isSpeaking}
                isFavorite={isFavorite(currentWord.id)}
                onToggleFavorite={() => toggleFavorite(currentWord.id)}
              />

              {/* Actions */}
              <div className="flex gap-3 mt-6">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleSwipe('left')}
                  className="flex-1 py-4 bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 rounded-xl font-semibold flex items-center justify-center gap-2"
                >
                  Skip
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleSwipe('right')}
                  className="flex-1 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold flex items-center justify-center gap-2"
                >
                  Know it!
                </motion.button>
              </div>

              {/* Close Button */}
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => setFlashcardMode(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-gray-200 dark:bg-slate-700"
              >
                ✕
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
