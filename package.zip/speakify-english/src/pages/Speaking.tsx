import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Mic, MicOff, Volume2, RotateCcw, ChevronRight, CheckCircle,
  XCircle, Star, Zap
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { speakingPractice } from '../data/vocabulary';
import { useTextToSpeech } from '../hooks';

interface PracticeItem {
  id: string;
  prompt: string;
  promptArabic: string;
  targetPhrase: string;
  helpfulWords: string[];
}

export function Speaking() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [spokenText, setSpokenText] = useState('');
  const [score, setScore] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [streak, setStreak] = useState(0);
  const [showHint, setShowHint] = useState(false);

  const { isDark } = useTheme();
  const { addXP } = useProgress();
  const { speak, isSpeaking } = useTextToSpeech();

  const currentPractice = speakingPractice[currentIndex];

  // Auto-speak the phrase
  useEffect(() => {
    if (currentPractice && !isRecording) {
      setTimeout(() => {
        speak(currentPractice.targetPhrase, 'en-US');
      }, 500);
    }
  }, [currentIndex, currentPractice, speak, isRecording]);

  const handleStartRecording = async () => {
    try {
      // Simulate recording for demo (actual speech recognition would go here)
      setIsRecording(true);
      setSpokenText('');
      setScore(null);
      setShowResult(false);

      // Simulate recording duration
      setTimeout(() => {
        // Simulate recognized speech (in production, use Web Speech API)
        setSpokenText(currentPractice.targetPhrase);
        setIsRecording(false);
        // Generate a random score for demo
        const randomScore = Math.floor(Math.random() * 30) + 70; // 70-100
        setScore(randomScore);
        setShowResult(true);

        if (randomScore >= 80) {
          setStreak(prev => prev + 1);
          addXP(20);
        } else {
          setStreak(0);
        }
      }, 3000);
    } catch (error) {
      console.error('Recording error:', error);
      setIsRecording(false);
    }
  };

  const handleNext = () => {
    if (currentIndex < speakingPractice.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowResult(false);
      setScore(null);
      setSpokenText('');
    } else {
      // Restart from beginning
      setCurrentIndex(0);
      setShowResult(false);
      setScore(null);
      setSpokenText('');
    }
  };

  const handleReplay = () => {
    speak(currentPractice.targetPhrase, 'en-US');
  };

  const getScoreColor = (s: number) => {
    if (s >= 90) return 'text-green-500';
    if (s >= 70) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreEmoji = (s: number) => {
    if (s >= 90) return '🌟';
    if (s >= 70) return '👍';
    return '💪';
  };

  const getScoreMessage = (s: number) => {
    if (s >= 90) return 'Excellent!';
    if (s >= 70) return 'Good job!';
    return 'Keep practicing!';
  };

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-6 pt-6 pb-4 ${
        isDark ? 'bg-slate-800' : 'bg-white'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Speaking Practice
            </h1>
            <p className="text-gray-500 dark:text-gray-400">
              Practice your pronunciation
            </p>
          </div>
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${
            streak > 0 ? 'bg-green-500/20 text-green-500' : 'bg-gray-200 dark:bg-slate-700'
          }`}>
            <Star className={`w-4 h-4 ${streak > 0 ? 'fill-current' : ''}`} />
            <span className="font-bold">{streak} streak</span>
          </div>
        </div>

        {/* Progress */}
        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
          <span>Progress: {currentIndex + 1} / {speakingPractice.length}</span>
          <div className="flex-1 h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${((currentIndex + 1) / speakingPractice.length) * 100}%` }}
              className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 py-8">
        {/* Practice Card */}
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          className={`p-6 rounded-3xl ${
            isDark ? 'bg-slate-800' : 'bg-white'
          } shadow-xl mb-6`}
        >
          {/* Prompt */}
          <div className="text-center mb-6">
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
              {currentPractice.promptArabic}
            </div>
            <div className="text-lg text-gray-600 dark:text-gray-300 mb-2">
              {currentPractice.prompt}
            </div>
          </div>

          {/* Target Phrase */}
          <AnimatePresence mode="wait">
            {!showResult ? (
              <motion.div
                key="phrase"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="text-center py-8"
              >
                <div className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
                  "{currentPractice.targetPhrase}"
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleReplay}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-500 rounded-full"
                >
                  <Volume2 className="w-5 h-5" />
                  Listen Again
                </motion.button>
              </motion.div>
            ) : (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.9, opacity: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="text-center py-8"
              >
                {/* Score */}
                <div className="mb-6">
                  <div className={`text-6xl mb-2 ${getScoreColor(score!)}`}>
                    {getScoreEmoji(score!)}
                  </div>
                  <div className="text-5xl font-bold mb-2">
                    <span className={getScoreColor(score!)}>{score}</span>
                    <span className="text-2xl text-gray-400">%</span>
                  </div>
                  <div className={`text-lg font-semibold ${getScoreColor(score!)}`}>
                    {getScoreMessage(score!)}
                  </div>
                </div>

                {/* Spoken Text */}
                {spokenText && (
                  <div className="mb-6">
                    <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                      You said:
                    </div>
                    <div className="text-xl text-gray-700 dark:text-gray-300 italic">
                      "{spokenText}"
                    </div>
                  </div>
                )}

                {/* XP Earned */}
                {score && score >= 70 && (
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <Zap className="w-5 h-5 text-yellow-500" />
                    <span className="text-yellow-500 font-bold">+20 XP</span>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Helpful Words */}
          {!showResult && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="border-t border-gray-200 dark:border-slate-700 pt-4"
            >
              <button
                onClick={() => setShowHint(!showHint)}
                className="w-full flex items-center justify-between mb-3 text-sm text-gray-500 dark:text-gray-400"
              >
                <span>Helpful words</span>
                <motion.span
                  animate={{ rotate: showHint ? 90 : 0 }}
                >
                  <ChevronRight className="w-4 h-4" />
                </motion.span>
              </button>
              <AnimatePresence>
                {showHint && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="flex flex-wrap gap-2 overflow-hidden"
                  >
                    {currentPractice.helpfulWords.map((word, i) => (
                      <motion.button
                        key={word}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => speak(word, 'en-US')}
                        className={`px-3 py-1.5 rounded-full text-sm ${
                          isDark ? 'bg-slate-700 text-gray-300' : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {word}
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </motion.div>

        {/* Microphone Button */}
        <div className="flex justify-center mb-8">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStartRecording}
            disabled={isRecording}
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${
              isRecording
                ? 'bg-red-500 animate-pulse scale-110'
                : 'bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/30'
            }`}
          >
            {isRecording ? (
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <MicOff className="w-10 h-10 text-white" />
              </motion.div>
            ) : (
              <Mic className="w-10 h-10 text-white" />
            )}
          </motion.button>
        </div>

        {/* Instructions */}
        <div className="text-center mb-8">
          <p className="text-gray-500 dark:text-gray-400">
            {isRecording
              ? 'Listening... Speak clearly'
              : isSpeaking
                ? 'Listen to the phrase'
                : 'Tap the microphone and speak'}
          </p>
        </div>

        {/* Action Button */}
        {showResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleNext}
              className="flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold rounded-2xl"
            >
              {currentIndex < speakingPractice.length - 1 ? 'Next Phrase' : 'Start Over'}
              <ChevronRight className="w-5 h-5" />
            </motion.button>
          </motion.div>
        )}

        {/* Tips Section */}
        <div className={`mt-10 p-6 rounded-2xl ${
          isDark ? 'bg-slate-800' : 'bg-blue-50'
        }`}>
          <h3 className="font-bold text-gray-900 dark:text-white mb-3">
            💡 Tips for Better Pronunciation
          </h3>
          <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
            <li>• Speak clearly and at a natural pace</li>
            <li>• Pay attention to word stress patterns</li>
            <li>• Listen to the audio multiple times</li>
            <li>• Practice regularly for best results</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
