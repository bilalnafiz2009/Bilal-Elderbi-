import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  RotateCcw, Subtitles, Settings, ChevronDown
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { conversations } from '../data/vocabulary';
import { useTextToSpeech } from '../hooks';
import type { Conversation } from '../types';

export function Listening() {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  const { isDark } = useTheme();
  const { addXP } = useProgress();
  const { speak } = useTextToSpeech();

  const currentLine = selectedConversation?.lines[currentLineIndex];

  // Auto-play lines
  useEffect(() => {
    if (!isPlaying || !selectedConversation || isMuted) return;

    const currentLineData = selectedConversation.lines[currentLineIndex];
    speak(currentLineData.english, 'en-US');

    const duration = (currentLineData.english.length / 10) * 1000 / playbackSpeed;
    const timer = setTimeout(() => {
      if (currentLineIndex < selectedConversation.lines.length - 1) {
        setCurrentLineIndex(prev => prev + 1);
        setProgress(((currentLineIndex + 1) / selectedConversation.lines.length) * 100);
      } else {
        setIsPlaying(false);
        addXP(50);
      }
    }, Math.max(duration, 1500));

    return () => clearTimeout(timer);
  }, [isPlaying, currentLineIndex, selectedConversation, speak, playbackSpeed, isMuted, addXP]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handlePrevious = () => {
    if (currentLineIndex > 0) {
      setCurrentLineIndex(prev => prev - 1);
      setProgress(((currentLineIndex - 1) / (selectedConversation?.lines.length || 1)) * 100);
    }
  };

  const handleNext = () => {
    if (selectedConversation && currentLineIndex < selectedConversation.lines.length - 1) {
      setCurrentLineIndex(prev => prev + 1);
      setProgress(((currentLineIndex + 1) / selectedConversation.lines.length) * 100);
    }
  };

  const handleSpeedChange = () => {
    const speeds = [0.75, 1, 1.25, 1.5];
    const currentIndex = speeds.indexOf(playbackSpeed);
    setPlaybackSpeed(speeds[(currentIndex + 1) % speeds.length]);
  };

  const handleLineClick = (index: number) => {
    setCurrentLineIndex(index);
    setProgress((index / (selectedConversation?.lines.length || 1)) * 100);
    if (!isMuted && selectedConversation) {
      speak(selectedConversation.lines[index].english, 'en-US');
    }
  };

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-6 pt-6 pb-4 ${
        isDark ? 'bg-slate-800' : 'bg-white'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Listening Practice
            </h1>
            <p className="text-gray-500 dark:text-gray-400">
              Native speaker audio
            </p>
          </div>
          <button
            onClick={() => setShowSubtitles(!showSubtitles)}
            className={`p-2 rounded-xl ${
              showSubtitles
                ? 'bg-blue-500 text-white'
                : isDark ? 'bg-slate-700 text-gray-300'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            <Subtitles className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Conversation Selection */}
        {!selectedConversation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
              Choose a Conversation
            </h2>
            {conversations.map((conversation) => (
              <motion.button
                key={conversation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setSelectedConversation(conversation);
                  setCurrentLineIndex(0);
                  setProgress(0);
                }}
                className={`w-full p-4 rounded-2xl text-left border ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 hover:border-slate-600'
                    : 'bg-white border-gray-100 hover:border-blue-300'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-2xl flex-shrink-0">
                    {conversation.category === 'restaurant' && '🍽️'}
                    {conversation.category === 'travel-airports' && '✈️'}
                    {conversation.category === 'hotels-booking' && '🏨'}
                    {conversation.category === 'business-english' && '💼'}
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-gray-900 dark:text-white mb-1">
                      {conversation.title}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">
                      {conversation.titleArabic}
                    </div>
                    <div className="text-xs text-gray-400">
                      {conversation.lines.length} exchanges
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </motion.div>
        )}

        {/* Listening Practice View */}
        {selectedConversation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {/* Back Button */}
            <button
              onClick={() => {
                setSelectedConversation(null);
                setIsPlaying(false);
                setCurrentLineIndex(0);
              }}
              className={`mb-4 flex items-center gap-2 text-sm ${
                isDark ? 'text-gray-400 hover:text-gray-200' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              ← Back to conversations
            </button>

            {/* Title */}
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              {selectedConversation.title}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              {selectedConversation.titleArabic}
            </p>

            {/* Progress */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2 text-sm">
                <span className="text-gray-500 dark:text-gray-400">
                  Progress: {currentLineIndex + 1} / {selectedConversation.lines.length}
                </span>
                <span className="text-gray-500 dark:text-gray-400">
                  {Math.round(progress)}%
                </span>
              </div>
              <div className="h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                />
              </div>
            </div>

            {/* Main Content Card */}
            <div className={`p-6 rounded-3xl mb-6 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            } shadow-xl`}>
              {/* Current Line */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentLineIndex}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={`p-4 rounded-2xl mb-4 ${
                    currentLine?.speaker === 'person1'
                      ? 'bg-blue-500/10 border-l-4 border-blue-500'
                      : 'bg-purple-500/10 border-l-4 border-purple-500'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                      currentLine?.speaker === 'person1'
                        ? 'bg-blue-500/20 text-blue-500'
                        : 'bg-purple-500/20 text-purple-500'
                    }`}>
                      {currentLine?.speaker === 'person1' ? 'Person 1' : 'Person 2'}
                    </span>
                  </div>
                  <div className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    "{currentLine?.english}"
                  </div>
                  {showSubtitles && (
                    <div className="text-gray-600 dark:text-gray-300">
                      {currentLine?.arabic}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={handlePrevious}
                  disabled={currentLineIndex === 0}
                  className={`p-3 rounded-full ${
                    currentLineIndex === 0
                      ? 'opacity-30 cursor-not-allowed'
                      : ''
                  } ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                >
                  <SkipBack className="w-6 h-6" />
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handlePlayPause}
                  className="w-16 h-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white flex items-center justify-center shadow-lg"
                >
                  {isPlaying ? (
                    <Pause className="w-8 h-8" />
                  ) : (
                    <Play className="w-8 h-8 ml-1" />
                  )}
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={handleNext}
                  disabled={currentLineIndex === selectedConversation.lines.length - 1}
                  className={`p-3 rounded-full ${
                    currentLineIndex === selectedConversation.lines.length - 1
                      ? 'opacity-30 cursor-not-allowed'
                      : ''
                  } ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                >
                  <SkipForward className="w-6 h-6" />
                </motion.button>
              </div>

              {/* Speed Control */}
              <div className="flex items-center justify-center gap-2 mt-4">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={`p-2 rounded-lg ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                >
                  {isMuted ? (
                    <VolumeX className="w-5 h-5" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                </button>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={handleSpeedChange}
                  className={`px-4 py-2 rounded-full text-sm font-medium ${
                    isDark ? 'bg-slate-700' : 'bg-gray-100'
                  }`}
                >
                  {playbackSpeed}x
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    setCurrentLineIndex(0);
                    setProgress(0);
                  }}
                  className={`p-2 rounded-lg ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                >
                  <RotateCcw className="w-5 h-5" />
                </motion.button>
              </div>
            </div>

            {/* Transcript */}
            <div className={`rounded-2xl p-4 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-3 text-sm">
                Full Transcript
              </h3>
              <div className="space-y-2">
                {selectedConversation.lines.map((line, index) => (
                  <motion.button
                    key={line.id}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleLineClick(index)}
                    className={`w-full p-3 rounded-xl text-left transition-colors ${
                      index === currentLineIndex
                        ? 'bg-blue-500/20 border border-blue-500'
                        : isDark
                          ? 'hover:bg-slate-700'
                          : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`w-2 h-2 rounded-full ${
                        line.speaker === 'person1' ? 'bg-blue-500' : 'bg-purple-500'
                      }`} />
                      <span className="text-xs text-gray-400">
                        {line.speaker === 'person1' ? 'P1' : 'P2'}
                      </span>
                    </div>
                    <div className="text-sm text-gray-900 dark:text-white">
                      {line.english}
                    </div>
                    {showSubtitles && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {line.arabic}
                      </div>
                    )}
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
