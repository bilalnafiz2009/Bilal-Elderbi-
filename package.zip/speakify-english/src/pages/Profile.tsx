import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Settings, Award, Flame, Zap, BookOpen, Calendar,
  Trophy, Target, Star, ChevronRight, Volume2, Check
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { achievements } from '../data/vocabulary';
import { useTextToSpeech } from '../hooks';

export function Profile() {
  const [activeTab, setActiveTab] = useState<'stats' | 'achievements' | 'settings'>('stats');
  const [testAudioText, setTestAudioText] = useState('');

  const { isDark } = useTheme();
  const { progress, resetProgress } = useProgress();
  const { speak } = useTextToSpeech();

  const tabs = [
    { id: 'stats' as const, label: 'Statistics', icon: <Trophy className="w-5 h-5" /> },
    { id: 'achievements' as const, label: 'Achievements', icon: <Award className="w-5 h-5" /> },
    { id: 'settings' as const, label: 'Settings', icon: <Settings className="w-5 h-5" /> },
  ];

  const getProgressBarColor = (percentage: number) => {
    if (percentage >= 100) return 'bg-green-500';
    if (percentage >= 50) return 'bg-blue-500';
    if (percentage >= 25) return 'bg-yellow-500';
    return 'bg-gray-300';
  };

  const getNextLevelXP = () => {
    return (progress.level) * 1000;
  };

  const getCurrentLevelXP = () => {
    return (progress.level - 1) * 1000;
  };

  const getProgressToNextLevel = () => {
    const currentXP = progress.xp - getCurrentLevelXP();
    const neededXP = getNextLevelXP() - getCurrentLevelXP();
    return Math.min((currentXP / neededXP) * 100, 100);
  };

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-6 pt-6 pb-4 ${
        isDark ? 'bg-slate-800' : 'bg-white'
      }`}>
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Profile
          </h1>
          <div className={`w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center`}>
            <User className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* User Info Card */}
        <div className={`p-5 rounded-2xl mb-4 ${
          isDark ? 'bg-slate-700' : 'bg-gradient-to-br from-blue-50 to-purple-50'
        }`}>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="font-bold text-gray-900 dark:text-white text-lg">English Learner</div>
              <div className="text-sm text-gray-500 dark:text-gray-400">Level {progress.level} Student</div>
            </div>
          </div>

          {/* Level Progress */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-500 dark:text-gray-400">Level {progress.level}</span>
              <span className="text-gray-500 dark:text-gray-400">Level {progress.level + 1}</span>
            </div>
            <div className="h-3 bg-gray-200 dark:bg-slate-600 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${getProgressToNextLevel()}%` }}
                className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
              />
            </div>
            <div className="text-right text-xs text-gray-400 mt-1">
              {progress.xp.toLocaleString()} / {getNextLevelXP().toLocaleString()} XP
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className={`p-4 rounded-2xl text-center ${isDark ? 'bg-slate-700' : 'bg-white'}`}>
            <Flame className={`w-6 h-6 mx-auto mb-2 ${progress.streak > 0 ? 'text-orange-500' : 'text-gray-400'}`} />
            <div className="font-bold text-gray-900 dark:text-white">{progress.streak}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Day Streak</div>
          </div>
          <div className={`p-4 rounded-2xl text-center ${isDark ? 'bg-slate-700' : 'bg-white'}`}>
            <Zap className="w-6 h-6 mx-auto mb-2 text-yellow-500" />
            <div className="font-bold text-gray-900 dark:text-white">{progress.xp.toLocaleString()}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Total XP</div>
          </div>
          <div className={`p-4 rounded-2xl text-center ${isDark ? 'bg-slate-700' : 'bg-white'}`}>
            <BookOpen className="w-6 h-6 mx-auto mb-2 text-blue-500" />
            <div className="font-bold text-gray-900 dark:text-white">{progress.totalWordsLearned}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Words Learn</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 py-4">
        <div className="flex gap-2 border-b border-gray-200 dark:border-slate-700">
          {tabs.map((tab) => (
            <motion.button
              key={tab.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-500'
                  : 'border-transparent text-gray-500 dark:text-gray-400'
              }`}
            >
              {tab.icon}
              <span className="text-sm font-medium hidden sm:inline">{tab.label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      <div className="px-6 py-4">
        {/* Stats Tab */}
        {activeTab === 'stats' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            <div className={`p-5 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-500" />
                Learning Stats
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Words Learned</span>
                  <span className="font-bold text-gray-900 dark:text-white">{progress.totalWordsLearned}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Completed Words</span>
                  <span className="font-bold text-gray-900 dark:text-white">{progress.completedWords.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Favorite Words</span>
                  <span className="font-bold text-gray-900 dark:text-white">{progress.favoriteWords.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Total Study Time</span>
                  <span className="font-bold text-gray-900 dark:text-white">{progress.totalMinutesSpent} min</span>
                </div>
              </div>
            </div>

            <div className={`p-5 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-green-500" />
                Daily Goals
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-600 dark:text-gray-400">Learn 10 words</span>
                    <span className="text-sm text-gray-500">{Math.min(progress.totalWordsLearned, 10)}/10</span>
                  </div>
                  <div className="h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full transition-all"
                      style={{ width: `${Math.min((progress.totalWordsLearned / 10) * 100, 100)}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-600 dark:text-gray-400">Practice speaking</span>
                    <span className="text-sm text-gray-500">0/5 min</span>
                  </div>
                  <div className="h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"
                      style={{ width: '10%' }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Achievements Tab */}
        {activeTab === 'achievements' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement, index) => {
                const isUnlocked = progress.achievements.includes(achievement.id);
                return (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`p-4 rounded-2xl text-center border ${
                      isUnlocked
                        ? 'bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/50'
                        : isDark
                          ? 'bg-slate-800 border-slate-700'
                          : 'bg-white border-gray-100'
                    }`}
                  >
                    <div className={`w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center ${
                      isUnlocked
                        ? 'bg-yellow-500'
                        : isDark
                          ? 'bg-slate-700'
                          : 'bg-gray-100'
                    }`}>
                      {isUnlocked ? (
                        <Star className={`w-6 h-6 ${isDark ? 'text-yellow-300' : 'text-yellow-500'}`} />
                      ) : (
                        <span className="text-gray-400 text-xl">🔒</span>
                      )}
                    </div>
                    <div className="font-semibold text-gray-900 dark:text-white text-sm mb-1">{achievement.name}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">{achievement.nameArabic}</div>
                    <div className="text-xs text-gray-400">{achievement.description}</div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            {/* Test TTS */}
            <div className={`p-5 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-blue-500" />
                Test Text-to-Speech
              </h3>
              <input
                type="text"
                value={testAudioText}
                onChange={(e) => setTestAudioText(e.target.value)}
                placeholder="Type something to hear it..."
                className={`w-full px-4 py-3 rounded-xl mb-3 ${
                  isDark
                    ? 'bg-slate-700 text-white placeholder-gray-400'
                    : 'bg-gray-50 text-gray-900 placeholder-gray-400'
                } border ${isDark ? 'border-slate-600' : 'border-gray-200'} focus:outline-none focus:ring-2 focus:ring-blue-500`}
              />
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => speak(testAudioText || 'Hello, this is a test!', 'en-US')}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-semibold rounded-xl flex items-center justify-center gap-2"
              >
                <Volume2 className="w-5 h-5" />
                Play Audio
              </motion.button>
            </div>

            {/* Reset Progress */}
            <div className={`p-5 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4">Reset Progress</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                This will reset all your learning progress, achievements, and reset your streak. This action cannot be undone.
              </p>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={resetProgress}
                className="w-full py-3 bg-red-500/20 text-red-500 font-semibold rounded-xl border border-red-500"
              >
                Reset All Progress
              </motion.button>
            </div>

            {/* App Info */}
            <div className={`p-5 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4">About Speakify English</h3>
              <div className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                <div>Version 1.0.0</div>
                <div>Built with React + Tailwind CSS</div>
                <div>6000+ vocabulary words</div>
                <div>Arabic translations included</div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
