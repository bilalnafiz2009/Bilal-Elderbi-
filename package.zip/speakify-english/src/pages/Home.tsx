import { motion } from 'framer-motion';
import {
  Zap, Trophy, Flame, Target, ChevronRight, Sparkles,
  Mic, BookOpen, Headphones, MessageCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { categories, getCategoryWordCount } from '../data/categories';

export function Home() {
  const { isDark } = useTheme();
  const { progress, addXP } = useProgress();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div className={`min-h-screen pb-24 md:pb-8 ${
      isDark ? 'bg-slate-900' : 'bg-gray-50'
    }`}>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgZmlsdGVyPSJ1cmwoI2dyaWQpIj48cGF0aCBkPSJNIDYwIDAgTCAwIDAgMCA2MCIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9Ii4wNSIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30" />

        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10 px-6 pt-8 pb-16 md:pt-12 md:pb-24"
        >
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white mb-6"
            >
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">Learn English Smartly</span>
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-4xl md:text-6xl font-bold text-white mb-4"
            >
              Learn English
              <span className="block mt-2 bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                Smartly
              </span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto"
            >
              Master 6000+ English Words, Pronunciation, and Real Conversations with AI-powered learning
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to="/vocabulary">
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full sm:w-auto px-8 py-4 bg-white text-blue-600 font-bold rounded-2xl shadow-xl flex items-center justify-center gap-2"
                >
                  <Zap className="w-5 h-5" />
                  Start Learning
                </motion.button>
              </Link>
              <Link to="/vocabulary">
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full sm:w-auto px-8 py-4 bg-white/20 backdrop-blur-sm text-white font-bold rounded-2xl border-2 border-white/40 hover:bg-white/30 transition-colors flex items-center justify-center gap-2"
                >
                  <BookOpen className="w-5 h-5" />
                  Browse Categories
                </motion.button>
              </Link>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="px-6 -mt-8 relative z-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-4xl mx-auto grid grid-cols-3 gap-3"
        >
          <motion.div
            variants={itemVariants}
            className={`p-4 rounded-2xl backdrop-blur-md ${
              isDark ? 'bg-slate-800/90' : 'bg-white/90'
            } shadow-xl text-center`}
          >
            <div className="inline-flex items-center justify-center w-10 h-10 bg-orange-500/20 rounded-xl mb-2">
              <Flame className="w-5 h-5 text-orange-500" />
            </div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {progress.streak}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Day Streak</div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className={`p-4 rounded--2xl backdrop-blur-md ${
              isDark ? 'bg-slate-800/90' : 'bg-white/90'
            } shadow-xl text-center`}
          >
            <div className="inline-flex items-center justify-center w-10 h-10 bg-yellow-500/20 rounded-xl mb-2">
              <Zap className="w-5 h-5 text-yellow-500" />
            </div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {progress.xp.toLocaleString()}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Total XP</div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className={`p-4 rounded-2xl backdrop-blur-md ${
              isDark ? 'bg-slate-800/90' : 'bg-white/90'
            } shadow-xl text-center`}
          >
            <div className="inline-flex items-center justify-center w-10 h-10 bg-purple-500/20 rounded-xl mb-2">
              <Trophy className="w-5 h-5 text-purple-500" />
            </div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              Level {progress.level}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Current</div>
          </motion.div>
        </motion.div>
      </section>

      {/* Daily Challenge */}
      <section className="px-6 mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className={`max-w-4xl mx-auto p-5 rounded-2xl ${
            isDark ? 'bg-gradient-to-br from-slate-800 to-slate-800/50' : 'bg-gradient-to-br from-blue-50 to-purple-50'
          } border ${isDark ? 'border-slate-700' : 'border-blue-100'}`}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-gray-900 dark:text-white">Daily Challenge</div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Complete to earn bonus XP</div>
              </div>
            </div>
            <div className="px-3 py-1 bg-yellow-400 text-yellow-900 rounded-full text-sm font-bold">
              +50 XP
            </div>
          </div>
          <Link to="/vocabulary">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full py-3 bg-blue-500 text-white font-semibold rounded-xl flex items-center justify-center gap-2"
            >
              Learn 10 New Words Today
              <ChevronRight className="w-5 h-5" />
            </motion.button>
          </Link>
        </motion.div>
      </section>

      {/* Quick Actions */}
      <section className="px-6 mt-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
            Practice Now
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <Link to="/speaking">
              <motion.div
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className={`p-5 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 text-white ${
                  isDark ? 'bg-opacity-90' : ''
                } shadow-lg cursor-pointer`}
              >
                <Mic className="w-8 h-8 mb-3" />
                <div className="font-bold text-lg mb-1">Speaking Practice</div>
                <div className="text-sm text-white/80">Practice pronunciation</div>
              </motion.div>
            </Link>

            <Link to="/listening">
              <motion.div
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className={`p-5 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white ${
                  isDark ? 'bg-opacity-90' : ''
                } shadow-lg cursor-pointer`}
              >
                <Headphones className="w-8 h-8 mb-3" />
                <div className="font-bold text-lg mb-1">Listening Practice</div>
                <div className="text-sm text-white/80">Train your ear</div>
              </motion.div>
            </Link>

            <Link to="/conversations">
              <motion.div
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className={`p-5 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 text-white ${
                  isDark ? 'bg-opacity-90' : ''
                } shadow-lg cursor-pointer`}
              >
                <MessageCircle className="w-8 h-8 mb-3" />
                <div className="font-bold text-lg mb-1">Real Conversations</div>
                <div className="text-sm text-white/80">Learn everyday phrases</div>
              </motion.div>
            </Link>

            <Link to="/grammar">
              <motion.div
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className={`p-5 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 text-white ${
                  isDark ? 'bg-opacity-90' : ''
                } shadow-lg cursor-pointer`}
              >
                <BookOpen className="w-8 h-8 mb-3" />
                <div className="font-bold text-lg mb-1">Grammar!</div>
                <div className="text-sm text-white/80">Master the rules</div>
              </motion.div>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="px-6 mt-10">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">
              Browse Categories
            </h2>
            <Link
              to="/vocabulary"
              className="text-blue-500 text-sm font-medium flex items-center gap-1"
            >
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.slice(0, 8).map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link to={`/vocabulary/${category.id}`}>
                  <motion.div
                    whileHover={{ scale: 1.05, y: -4 }}
                    whileTap={{ scale: 0.95 }}
                    className={`p-4 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-white'} shadow-lg cursor-pointer border ${
                      isDark ? 'border-slate-700' : 'border-gray-100'
                    }`}
                  >
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      <span style={{ color: category.color }} className="text-xl">
                        {category.id === 'daily-conversations' && '💬'}
                        {category.id === 'restaurant' && '🍽️'}
                        {category.id === 'travel-airports' && '✈️'}
                        {category.id === 'hotels-booking' && '🏨'}
                        {category.id === 'shopping-supermarket' && '🛒'}
                        {category.id === 'cars-transportation' && '🚗'}
                        {category.id === 'school-education' && '📚'}
                        {category.id === 'business-english' && '💼'}
                        {category.id === 'technology' && '💻'}
                        {category.id === 'food-drinks' && '🍕'}
                        {category.id === 'family-friends' && '👨‍👩‍👧‍👦'}
                        {category.id === 'jobs-work' && '💼'}
                        {category.id === 'numbers-counting' && '🔢'}
                        {category.id === 'time-dates' && '📅'}
                        {category.id === 'weather' && '🌤️'}
                        {category.id === 'emergency-phrases' && '⚠️'}
                        {category.id === 'common-verbs' && '🏃'}
                        {category.id === 'common-adjectives' && '✨'}
                        {category.id === 'idioms-expressions' && '💡'}
                      </span>
                    </div>
                    <div className="font-semibold text-gray-900 dark:text-white text-sm mb-1 line-clamp-1">
                      {category.name}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                      {category.nameArabic}
                    </div>
                    <div className="text-xs text-gray-400">
                      {getCategoryWordCount(category.id)} words
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-3 h-1.5 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${progress.categoryProgress[category.id] || 0}%` }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: category.color }}
                      />
                    </div>
                  </motion.div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
