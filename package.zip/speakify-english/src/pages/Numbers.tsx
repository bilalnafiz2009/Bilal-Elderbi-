import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft, ChevronRight, Volume2, RotateCcw, Shuffle,
  Hash, DollarSign, Calendar, Clock
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useProgress } from '../context/ProgressContext';
import { numberItems } from '../data/vocabulary';
import { useTextToSpeech } from '../hooks';

type TabType = 'numbers' | 'money' | 'dates' | 'time';

export function Numbers() {
  const [activeTab, setActiveTab] = useState<TabType>('numbers');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [range, setRange] = useState<[number, number]>([1, 20]);

  const { isDark } = useTheme();
  const { addXP } = useProgress();
  const { speak } = useTextToSpeech();

  const tabs: { id: TabType; label: string; labelArabic: string; icon: React.ReactNode }[] = [
    { id: 'numbers', label: 'Numbers', labelArabic: 'الأرقام', icon: <Hash className="w-5 h-5" /> },
    { id: 'money', label: 'Money', labelArabic: 'المال', icon: <DollarSign className="w-5 h-5" /> },
    { id: 'dates', label: 'Dates', labelArabic: 'التواريخ', icon: <Calendar className="w-5 h-5" /> },
    { id: 'time', label: 'Time', labelArabic: 'الوقت', icon: <Clock className="w-5 h-5" /> },
  ];

  const rangeOptions: { label: string; value: [number, number] }[] = [
    { label: '1-20', value: [1, 20] },
    { label: '1-50', value: [1, 50] },
    { label: '1-100', value: [1, 100] },
    { label: '1-1000', value: [1, 1000] },
  ];

  const filteredNumbers = numberItems.filter(n => n.number >= range[0] && n.number <= range[1]);
  const currentNumber = filteredNumbers[currentIndex];

  useEffect(() => {
    if (isPlaying && currentNumber) {
      speak(currentNumber.english, 'en-US');
      const timer = setTimeout(() => {
        if (currentIndex < filteredNumbers.length - 1) {
          setCurrentIndex(prev => prev + 1);
        } else {
          setIsPlaying(false);
          addXP(30);
        }
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isPlaying, currentIndex, currentNumber, filteredNumbers.length, speak, addXP]);

  const handleSpeak = () => {
    if (currentNumber) {
      speak(currentNumber.english, 'en-US');
    }
  };

  const handleNext = () => {
    if (currentIndex < filteredNumbers.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    } else {
      setCurrentIndex(filteredNumbers.length - 1);
    }
  };

  const handleShuffle = () => {
    setCurrentIndex(Math.floor(Math.random() * filteredNumbers.length));
  };

  // Money examples
  const moneyExamples = [
    { amount: 5.99, english: 'Five dollars and ninety-nine cents', arabic: 'خمسة دولارات وتسعة وتسعون سنتاً' },
    { amount: 10.50, english: 'Ten dollars and fifty cents', arabic: 'عشرة دولارات وخمسون سنتاً' },
    { amount: 25.00, english: 'Twenty-five dollars', arabic: 'خمسة وعشرون دولاراً' },
    { amount: 99.99, english: 'Ninety-nine dollars and ninety-nine cents', arabic: 'تسعة وتسعون دولاراً وتسعة وتسعون سنتاً' },
    { amount: 150.25, english: 'One hundred fifty dollars and twenty-five cents', arabic: 'مئة وخمسون دولاراً وخمس وعشرون سنتاً' },
  ];

  // Days of week
  const daysOfWeek = [
    { english: 'Sunday', arabic: 'الأحد' },
    { english: 'Monday', arabic: 'الإثنين' },
    { english: 'Tuesday', arabic: 'الثلاثاء' },
    { english: 'Wednesday', arabic: 'الأربعاء' },
    { english: 'Thursday', arabic: 'الخميس' },
    { english: 'Friday', arabic: 'الجمعة' },
    { english: 'Saturday', arabic: 'السبت' },
  ];

  // Months
  const months = [
    { english: 'January', arabic: 'يناير', short: 'Jan' },
    { english: 'February', arabic: 'فبراير', short: 'Feb' },
    { english: 'March', arabic: 'مارس', short: 'Mar' },
    { english: 'April', arabic: 'أبريل', short: 'Apr' },
    { english: 'May', arabic: 'مايو', short: 'May' },
    { english: 'June', arabic: 'يونيو', short: 'Jun' },
    { english: 'July', arabic: 'يوليو', short: 'Jul' },
    { english: 'August', arabic: 'أغسطس', short: 'Aug' },
    { english: 'September', arabic: 'سبتمبر', short: 'Sep' },
    { english: 'October', arabic: 'أكتوبر', short: 'Oct' },
    { english: 'November', arabic: 'نوفمبر', short: 'Nov' },
    { english: 'December', arabic: 'ديسمبر', short: 'Dec' },
  ];

  return (
    <div className={`min-h-screen pb-24 ${isDark ? 'bg-slate-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-6 pt-6 pb-4 ${
        isDark ? 'bg-slate-800' : 'bg-white'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Numbers & Time
            </h1>
            <p className="text-gray-500 dark:text-gray-400">
              Master numbers with audio
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-6 px-6">
          {tabs.map((tab) => (
            <motion.button
              key={tab.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white'
                  : isDark
                    ? 'bg-slate-700 text-gray-300'
                    : 'bg-gray-100 text-gray-600'
              }`}
            >
              {tab.icon}
              {tab.label}
            </motion.button>
          ))}
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Numbers Tab */}
        {activeTab === 'numbers' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {/* Range Selector */}
            <div className="flex items-center justify-between mb-6">
              <span className="text-sm text-gray-500 dark:text-gray-400">Select range:</span>
              <div className="flex gap-2">
                {rangeOptions.map((option) => (
                  <motion.button
                    key={option.label}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setRange(option.value);
                      setCurrentIndex(0);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      range[0] === option.value[0]
                        ? 'bg-teal-500 text-white'
                        : isDark
                          ? 'bg-slate-700 text-gray-300'
                          : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {option.label}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Main Card */}
            <div className={`p-8 rounded-3xl mb-6 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            } shadow-xl text-center`}>
              {/* Progress */}
              <div className="flex items-center justify-between mb-6 text-sm">
                <button onClick={handlePrevious} className={`p-2 rounded-lg ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}>
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <span className="text-gray-500 dark:text-gray-400">
                  {currentIndex + 1} / {filteredNumbers.length}
                </span>
                <button onClick={handleNext} className={`p-2 rounded-lg ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}>
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Number Display */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentIndex}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="mb-6"
                >
                  <div className="text-7xl font-bold text-gray-900 dark:text-white mb-2">
                    {currentNumber?.number}
                  </div>
                  <div className="text-2xl text-gray-600 dark:text-gray-300 mb-4">
                    {currentNumber?.arabic}
                  </div>
                  <div className="text-lg text-gray-400 italic">
                    {currentNumber?.english}
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={handleShuffle}
                  className={`p-3 rounded-xl ${isDark ? 'bg-slate-700' : 'bg-gray-100'}`}
                >
                  <Shuffle className="w-5 h-5" />
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handleSpeak}
                  className="w-16 h-16 rounded-full bg-gradient-to-r from-teal-500 to-cyan-500 text-white flex items-center justify-center shadow-lg"
                >
                  <Volume2 className="w-7 h-7" />
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`p-3 rounded-xl ${
                    isPlaying
                      ? 'bg-red-500 text-white'
                      : isDark
                        ? 'bg-slate-700'
                        : 'bg-gray-100'
                  }`}
                >
                  {isPlaying ? '⏸️' : '▶️'}
                </motion.button>
              </div>
            </div>

            {/* Quick Grid */}
            <div className={`p-4 rounded-2xl ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <div className="grid grid-cols-5 gap-2">
                {filteredNumbers.slice(0, 20).map((num, index) => (
                  <motion.button
                    key={num.id}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setCurrentIndex(index)}
                    className={`p-3 rounded-xl text-center transition-colors ${
                      index === currentIndex
                        ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white'
                        : isDark
                          ? 'bg-slate-700 text-gray-300'
                          : 'bg-gray-50 text-gray-600'
                    }`}
                  >
                    <div className="font-bold">{num.number}</div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Money Tab */}
        {activeTab === 'money' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {moneyExamples.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-5 rounded-2xl ${
                    isDark ? 'bg-slate-800' : 'bg-white'
                  } border ${isDark ? 'border-slate-700' : 'border-gray-100'}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      ${item.amount.toFixed(2)}
                    </div>
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => speak(item.english, 'en-US')}
                      className="p-2 rounded-full bg-green-500/20 text-green-500"
                    >
                      <Volume2 className="w-4 h-4" />
                    </motion.button>
                  </div>
                  <div className="text-gray-600 dark:text-gray-300 mb-1">
                    {item.english}
                  </div>
                  <div className="text-sm text-gray-400">
                    {item.arabic}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Dates Tab */}
        {activeTab === 'dates' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {/* Days of Week */}
            <div className={`p-4 rounded-2xl mb-6 ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4">Days of the Week</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {daysOfWeek.map((day, index) => (
                  <motion.button
                    key={index}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => speak(day.english, 'en-US')}
                    className={`p-4 rounded-xl text-center border ${
                      isDark ? 'bg-slate-700 border-slate-600' : 'bg-gray-50 border-gray-100'
                    }`}
                  >
                    <div className="text-gray-900 dark:text-white font-medium">{day.english}</div>
                    <div className="text-sm text-gray-400">{day.arabic}</div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Months */}
            <div className={`p-4 rounded-2xl ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4">Months</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {months.map((month, index) => (
                  <motion.button
                    key={index}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => speak(month.english, 'en-US')}
                    className={`p-4 rounded-xl text-center border ${
                      isDark ? 'bg-slate-700 border-slate-600' : 'bg-gray-50 border-gray-100'
                    }`}
                  >
                    <div className="text-gray-900 dark:text-white font-medium">{month.english}</div>
                    <div className="text-sm text-gray-400">{month.arabic}</div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Time Tab */}
        {activeTab === 'time' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className={`p-6 rounded-2xl ${
              isDark ? 'bg-slate-800' : 'bg-white'
            }`}>
              <h3 className="font-bold text-gray-900 dark:text-white mb-4">Time Telling</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { time: '3:00', english: 'Three o\'clock', arabic: 'الثالثة' },
                  { time: '6:30', english: 'Six thirty', arabic: 'السادسة والنصف' },
                  { time: '9:15', english: 'Quarter past nine', arabic: 'التاسعة والربع' },
                  { time: '12:45', english: 'Quarter to one', arabic: 'الواحدة إلا ربع' },
                  { time: '5:00', english: 'Five o\'clock', arabic: 'الخامسة' },
                  { time: '11:30', english: 'Half past eleven', arabic: 'الحادية عشر والنصف' },
                ].map((item, index) => (
                  <motion.button
                    key={index}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => speak(item.english, 'en-US')}
                    className={`p-4 rounded-xl text-center border ${
                      isDark ? 'bg-slate-700 border-slate-600' : 'bg-gray-50 border-gray-100'
                    }`}
                  >
                    <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{item.time}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-300">{item.english}</div>
                    <div className="text-xs text-gray-400">{item.arabic}</div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
