import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { UserProgress } from '../types';

const defaultProgress: UserProgress = {
  xp: 0,
  level: 1,
  streak: 0,
  lastActiveDate: '',
  completedWords: [],
  favoriteWords: [],
  categoryProgress: {},
  totalWordsLearned: 0,
  totalMinutesSpent: 0,
  achievements: [],
};

interface ProgressContextType {
  progress: UserProgress;
  addXP: (amount: number) => void;
  markWordComplete: (wordId: string) => void;
  toggleFavorite: (wordId: string) => void;
  isFavorite: (wordId: string) => boolean;
  isWordComplete: (wordId: string) => boolean;
  updateCategoryProgress: (category: string, progress: number) => void;
  unlockAchievement: (achievementId: string) => void;
  increaseStreak: () => void;
  resetStreak: () => void;
  resetProgress: () => void;
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined);

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('speakify-progress');
    return saved ? JSON.parse(saved) : defaultProgress;
  });

  useEffect(() => {
    localStorage.setItem('speakify-progress', JSON.stringify(progress));
  }, [progress]);

  // Check and update streak on load
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const lastActive = progress.lastActiveDate;

    if (lastActive) {
      const lastDate = new Date(lastActive);
      const todayDate = new Date(today);
      const diffDays = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));

      if (diffDays > 1) {
        // Streak broken
        setProgress(prev => ({ ...prev, streak: 0 }));
      }
    }
  }, []);

  const addXP = useCallback((amount: number) => {
    setProgress(prev => {
      const newXP = prev.xp + amount;
      const newLevel = Math.floor(newXP / 1000) + 1;
      return {
        ...prev,
        xp: newXP,
        level: newLevel,
        lastActiveDate: new Date().toISOString().split('T')[0],
      };
    });
  }, []);

  const markWordComplete = useCallback((wordId: string) => {
    setProgress(prev => {
      if (prev.completedWords.includes(wordId)) return prev;
      return {
        ...prev,
        completedWords: [...prev.completedWords, wordId],
        totalWordsLearned: prev.totalWordsLearned + 1,
        lastActiveDate: new Date().toISOString().split('T')[0],
      };
    });
  }, []);

  const toggleFavorite = useCallback((wordId: string) => {
    setProgress(prev => {
      const isFav = prev.favoriteWords.includes(wordId);
      return {
        ...prev,
        favoriteWords: isFav
          ? prev.favoriteWords.filter(id => id !== wordId)
          : [...prev.favoriteWords, wordId],
      };
    });
  }, []);

  const isFavorite = useCallback((wordId: string) => {
    return progress.favoriteWords.includes(wordId);
  }, [progress.favoriteWords]);

  const isWordComplete = useCallback((wordId: string) => {
    return progress.completedWords.includes(wordId);
  }, [progress.completedWords]);

  const updateCategoryProgress = useCallback((category: string, progressValue: number) => {
    setProgress(prev => ({
      ...prev,
      categoryProgress: {
        ...prev.categoryProgress,
        [category]: progressValue,
      },
    }));
  }, []);

  const unlockAchievement = useCallback((achievementId: string) => {
    setProgress(prev => {
      if (prev.achievements.includes(achievementId)) return prev;
      return {
        ...prev,
        achievements: [...prev.achievements, achievementId],
      };
    });
  }, []);

  const increaseStreak = useCallback(() => {
    setProgress(prev => {
      const today = new Date().toISOString().split('T')[0];
      if (prev.lastActiveDate === today) return prev;
      return {
        ...prev,
        streak: prev.streak + 1,
        lastActiveDate: today,
      };
    });
  }, []);

  const resetStreak = useCallback(() => {
    setProgress(prev => ({ ...prev, streak: 0 }));
  }, []);

  const resetProgress = useCallback(() => {
    setProgress(defaultProgress);
  }, []);

  return (
    <ProgressContext.Provider value={{
      progress,
      addXP,
      markWordComplete,
      toggleFavorite,
      isFavorite,
      isWordComplete,
      updateCategoryProgress,
      unlockAchievement,
      increaseStreak,
      resetStreak,
      resetProgress,
    }}>
      {children}
    </ProgressContext.Provider>
  );
}

export function useProgress() {
  const context = useContext(ProgressContext);
  if (!context) {
    throw new Error('useProgress must be used within a ProgressProvider');
  }
  return context;
}
