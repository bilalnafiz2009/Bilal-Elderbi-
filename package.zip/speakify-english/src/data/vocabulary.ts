import type { Word, Conversation, GrammarLesson, GrammarExample, GrammarExercise, Achievement, DailyChallenge, SpeakingPractice, NumberItem } from '../types';

// Utility to generate unique IDs
const generateId = () => Math.random().toString(36).substring(2, 9);

// Generate vocabulary words for a category
const generateWord = (
  english: string,
  arabic: string,
  pronunciation: string,
  example: string,
  exampleArabic: string,
  category: Word['category'],
  difficulty: Word['difficulty'] = 1,
  wordType: Word['wordType'] = 'vocabulary'
): Word => ({
  id: generateId(),
  english,
  arabic,
  pronunciation,
  example,
  exampleArabic,
  category,
  difficulty,
  wordType,
  frequency: 0,
});

// Daily Conversations
const dailyConversations: Word[] = [
  generateWord('Hello', 'مرحباً', 'hə-LOH', 'Hello, how are you?', 'مرحباً، كيف حالك؟', 'daily-conversations', 1),
  generateWord('Good morning', 'صباح الخير', 'good MOR-ning', 'Good morning, everyone!', 'صباح الخير يا جميعاً!', 'daily-conversations', 1),
  generateWord('Good afternoon', 'مساء الخير', 'good AF-ter-noon', 'Good afternoon, let\'s meet at 3 PM.', 'مساء الخير، لنلتقي الساعة 3 مساءً.', 'daily-conversations', 1),
  generateWord('Good evening', 'مساء الخير', 'good EEV-ning', 'Good evening, welcome to the show.', 'مساء الخير، أهلاً بك في العرض.', 'daily-conversations', 1),
  generateWord('Good night', 'تصبح على خير', 'good NITE', 'Good night, see you tomorrow!', 'تصبح على خير، إلى الغد!', 'daily-conversations', 1),
  generateWord('Goodbye', 'وداعاً', 'good-BYE', 'Goodbye, take care!', 'وداعاً، اعتنِ بنفسك!', 'daily-conversations', 1),
  generateWord('Thank you', 'شكراً لك', 'THANK yoo', 'Thank you for your help.', 'شكراً لك على مساعدتك.', 'daily-conversations', 1),
  generateWord('Please', 'من فضلك', 'PLEEZ', 'Please pass me the salt.', 'من فضلك أعطني الملح.', 'daily-conversations', 1),
  generateWord('Sorry', 'آسف', 'SOR-ee', 'Sorry, I\'m late.', 'آسف، تأخرت.', 'daily-conversations', 1),
  generateWord('Excuse me', 'عفواً', 'ik-SKYOOZ mee', 'Excuse me, where is the bathroom?', 'عفواً، أين دورة المياه؟', 'daily-conversations', 1),
  generateWord('Yes', 'نعم', 'YES', 'Yes, I agree with you.', 'نعم، أنا أتفق معك.', 'daily-conversations', 1),
  generateWord('No', 'لا', 'NOH', 'No, I don\'t think so.', 'لا، لا أعتقد ذلك.', 'daily-conversations', 1),
  generateWord('Maybe', 'ربما', 'MAY-bee', 'Maybe we should go now.', 'ربما يجب أن نذهب الآن.', 'daily-conversations', 1),
  generateWord('I understand', 'أفهم', 'ahy UN-der-stand', 'I understand what you mean.', 'أفهم ما تعنيه.', 'daily-conversations', 1),
  generateWord('I don\'t understand', 'لا أفهم', 'ahy dohnt UN-der-stand', 'I don\'t understand this question.', 'لا أفهم هذا السؤال.', 'daily-conversations', 1),
  generateWord('Can you repeat?', 'هل يمكنك تكرار؟', 'kan yoo ree-PEET', 'Can you repeat that slowly?', 'هل يمكنك تكرار ذلك ببطء؟', 'daily-conversations', 1),
  generateWord('How are you?', 'كيف حالك؟', 'how ar yoo', 'How are you today?', 'كيف حالك اليوم؟', 'daily-conversations', 1),
  generateWord('I\'m fine', 'أنا بخير', 'ahym FYN', 'I\'m fine, thank you!', 'أنا بخير، شكراً!', 'daily-conversations', 1),
  generateWord('Nice to meet you', 'تشرفنا', 'nys too meet yoo', 'Nice to meet you, I\'m Sarah.', 'تشرفنا، أنا سارة.', 'daily-conversations', 1),
  generateWord('What\'s your name?', 'ما اسمك؟', 'wuts yor naym', 'What\'s your name please?', 'ما اسمك من فضلك؟', 'daily-conversations', 1),
  generateWord('My name is', 'اسمي', 'my naym iz', 'My name is Ahmed.', 'اسمي أحمد.', 'daily-conversations', 1),
  generateWord('Where are you from?', 'من أين أنت؟', 'wair ar yoo from', 'Where are you from?', 'من أين أنت؟', 'daily-conversations', 1),
  generateWord('I\'m from', 'أنا من', 'ahym from', 'I\'m from Cairo, Egypt.', 'أنا من القاهرة، مصر.', 'daily-conversations', 1),
  generateWord('How much?', 'كم؟', 'how much', 'How much does this cost?', 'كم تكلفة هذا؟', 'daily-conversations', 1),
  generateWord('When?', 'متى؟', 'WHEN', 'When does the store open?', 'متى يفتح المتجر؟', 'daily-conversations', 1),
  generateWord('Where?', 'أين؟', 'WAIR', 'Where is the metro station?', 'أين محطة المترو؟', 'daily-conversations', 1),
  generateWord('Who?', 'من؟', 'HOO', 'Who told you that?', 'من الذي сказал لك ذلك؟', 'daily-conversations', 1),
  generateWord('Why?', 'لماذا؟', 'WY', 'Why did you say that?', 'لماذا قلت ذلك؟', 'daily-conversations', 1),
  generateWord('How?', 'كيف؟', 'HOW', 'How do I get to the airport?', 'كيف أصل إلى المطار؟', 'daily-conversations', 1),
  generateWord('What time is it?', 'كم الساعة؟', 'wut tym iz it', 'What time is it now?', 'كم الساعة الآن؟', 'daily-conversations', 1),
  generateWord('See you later', 'إلى اللقاء', 'see yoo LAY-ter', 'See you later at the meeting.', 'إلى اللقاء في الاجتماع.', 'daily-conversations', 1),
  generateWord('Take care', 'اعتنِ بنفسك', 'tayk kair', 'Take care of yourself.', 'اعتنِ بنفسك.', 'daily-conversations', 1),
  generateWord('Have a nice day', 'يوم سعيد', 'hav uh nys day', 'Have a nice day at work!', 'يوم سعيد في عملك!', 'daily-conversations', 1),
  generateWord('Congratulations', 'تهانينا', 'kon-gruh-TAY-shuns', 'Congratulations on your success!', 'تهانينا على نجاحك!', 'daily-conversations', 1),
  generateWord('Happy birthday', 'عيد ميلاد سعيد', 'HAP-ee BERTH-day', 'Happy birthday to you!', 'عيد ميلاد سعيد لك!', 'daily-conversations', 1),
  generateWord('Good luck', 'حظاً سعيداً', 'good LUCK', 'Good luck with your exam!', 'حظاً سعيداً في امتحانك!', 'daily-conversations', 1),
  generateWord('I\'m sorry to hear that', 'أنا آسف لسماع ذلك', 'ahym SOR-ee too heer that', 'I\'m sorry to hear about your loss.', 'أنا آسف لسماع خبر خسارتك.', 'daily-conversations', 2),
  generateWord('That\'s great!', 'هذا رائع!', 'thuts GRAYT', 'You got the job? That\'s great!', 'حصلت على الوظيفة؟ هذا رائع!', 'daily-conversations', 1),
  generateWord('No problem', 'لا مشكلة', 'noh PROB-lem', 'No problem, I can help you.', 'لا مشكلة، يمكنني مساعدتك.', 'daily-conversations', 1),
  generateWord('You\'re welcome', 'على الرحب', 'yor WEL-kum', 'You\'re welcome, anytime!', 'على الرحب، في أي وقت!', 'daily-conversations', 1),
  generateWord('Of course', 'بالطبع', 'of KORS', 'Of course I\'ll help you.', 'بالطبع سأساعدك.', 'daily-conversations', 1),
  generateWord('Definitely', 'بالتأكيد', 'DEF-in-it-lee', 'Definitely, let\'s do it!', 'بالتأكيد، هيا نفعلها!', 'daily-conversations', 2),
];

// Restaurant English
const restaurantWords: Word[] = [
  generateWord('Menu', 'قائمة الطعام', 'MEN-yoo', 'Can I see the menu please?', 'هل يمكنني رؤية قائمة الطعام من فضلك؟', 'restaurant', 1),
  generateWord('Table', 'طاولة', 'TAY-bul', 'A table for two, please.', 'طاولة لشخصين من فضلك.', 'restaurant', 1),
  generateWord('Waiter', 'نادل', 'WAY-ter', 'Excuse me, waiter!', 'عفواً يا نادل!', 'restaurant', 1),
  generateWord('Order', 'طلب', 'OR-der', 'I\'d like to order, please.', 'أود أن أطلب من فضلك.', 'restaurant', 1),
  generateWord('Appetizer', 'مقبلات', 'AP-uh-ty-zer', 'Let\'s start with an appetizer.', 'لنبدأ بالمقبلات.', 'restaurant', 1),
  generateWord('Main course', 'الطبق الرئيسي', 'mayn Kors', 'The main course looks delicious.', 'الطبق الرئيسي يبدو لذيذاً.', 'restaurant', 1),
  generateWord('Dessert', 'حلوى', 'di-ZERT', 'I\'ll have the chocolate dessert.', 'سآخذ حلوى الشوكولاتة.', 'restaurant', 1),
  generateWord('Bill', 'الفاتورة', 'BIL', 'Can I have the bill please?', 'هل يمكنني الحصول على الفاتورة من فضلك؟', 'restaurant', 1),
  generateWord('Tip', 'بقشيش', 'TIP', 'The service was great, I\'ll leave a good tip.', 'الخدمة كانت رائعة، سأعطي بقشيشاً جيداً.', 'restaurant', 1),
  generateWord('Reservation', 'حجز', 'rez-er-VAY-shun', 'I have a reservation under the name Smith.', 'لدي حجز باسم سميث.', 'restaurant', 2),
  generateWord('Breakfast', 'فطور', 'BREK-fust', 'Breakfast is served from 6 to 10 AM.', 'يُقدم الفطور من 6 إلى 10 صباحاً.', 'restaurant', 1),
  generateWord('Lunch', 'غداء', 'LUNCH', 'Shall we have lunch together?', 'هل نتناول الغداء معاً؟', 'restaurant', 1),
  generateWord('Dinner', 'عشاء', 'DY-ner', 'Dinner is at 7 PM tonight.', 'العشاء الساعة 7 مساءً الليلة.', 'restaurant', 1),
  generateWord('Delicious', 'لذيذ', 'di-LISH-us', 'This pasta is absolutely delicious!', 'هذه المعكرونة لذيذة جداً!', 'restaurant', 1),
  generateWord('Spicy', 'حار', 'SPY-see', 'This curry is very spicy.', 'هذا الكاري حار جداً.', 'restaurant', 1),
  generateWord('Vegetarian', 'نباتي', 'vej-uh-TAIR-ee-un', 'Do you have vegetarian options?', 'هل لديكم خيارات نباتية؟', 'restaurant', 2),
  generateWord('Gluten-free', 'خالٍ من الغلوتين', 'GLoo-ten-free', 'Is this dish gluten-free?', 'هل هذه الطبق خالٍ من الغلوتين؟', 'restaurant', 2),
  generateWord('Delivered', 'مُوصَّل', 'di-LIV-erd', 'Can this be delivered to my home?', 'هل يمكن توصيل هذا إلى بيتي؟', 'restaurant', 2),
  generateWord('Takeout', 'للأكل خارجاً', 'TAYK-out', 'I\'d like to order for takeout.', 'أود أن أطلب للأكل خارجاً.', 'restaurant', 2),
  generateWord('Knife', 'سكين', 'NYF', 'Could you bring me a clean knife?', 'هل يمكنك إحضار سكين نظيف لي؟', 'restaurant', 1),
  generateWord('Fork', 'شوكة', 'FORK', 'Please pass me a fork.', 'من فضلك أعطني شوكة.', 'restaurant', 1),
  generateWord('Spoon', 'ملعقة', 'SPOON', 'I need a spoon for the soup.', 'أحتاج ملعقة للحساء.', 'restaurant', 1),
  generateWord('Glass', 'كأس', 'GLAS', 'A glass of water, please.', 'كأس من الماء من فضلك.', 'restaurant', 1),
  generateWord('Chopsticks', 'أعواد', 'SHOP-stiks', 'Do you have chopsticks?', 'هل لديكم أعواد؟', 'restaurant', 2),
  generateWord('Pepper', 'فلفل', 'PEP-er', 'Pass the pepper please.', 'مرر الفلفل من فضلك.', 'restaurant', 1),
  generateWord('Salt', 'ملح', 'SALT', 'This needs more salt.', 'هذا يحتاج ملحاً أكثر.', 'restaurant', 1),
  generateWord('Sauce', 'صلصة', 'SOS', 'What sauce comes with this?', 'ما الصلصة التي تأتي مع هذا؟', 'restaurant', 1),
  generateWord('Allergic', 'لديه حساسية', 'uh-LER-jik', 'I\'m allergic to nuts.', 'لدي حساسية من المكسرات.', 'restaurant', 2),
  generateWord('Vegan', 'نباتي صارم', 'VEE-gun', 'Is this dish vegan?', 'هل هذا الطبق نباتي صارم؟', 'restaurant', 2),
  generateWord('Medium rare', 'مشوي نصف نئِ', 'MEE-dee-um rair', 'I\'d like my steak medium rare.', 'أود أن يكون شريحتي مشوية نصف نئ.', 'restaurant', 2),
  generateWord('Fried', 'مقلي', 'FRYD', 'I prefer fried chicken to roasted.', 'أفضل الدجاج المقلي على المشوي.', 'restaurant', 1),
  generateWord('Grilled', 'مشوي', 'GRILD', 'The grilled fish is excellent today.', 'السمك المشوي ممتاز اليوم.', 'restaurant', 1),
  generateWord('Boiled', 'مسلوق', 'BOHLD', 'I\'d like a boiled egg please.', 'أود بيضة مسلوقة من فضلك.', 'restaurant', 1),
  generateWord('Raw', 'نيء', 'RAW', 'I don\'t eat raw fish.', 'لا آكل السمك النئي.', 'restaurant', 2),
  generateWord('Hot', 'ساخن', 'HOT', 'Be careful, the soup is very hot.', 'انتبه، الحساء ساخن جداً.', 'restaurant', 1),
  generateWord('Cold', 'بارد', 'KOLD', 'I prefer cold drinks in summer.', 'أفضل المشروبات الباردة صيفاً.', 'restaurant', 1),
  generateWord('Juice', 'عصير', 'JOOS', 'Fresh orange juice, please.', 'عصير برتقان طازج من فضلك.', 'restaurant', 1),
  generateWord('Wine', 'نبيذ', 'WYN', 'May I see the wine list?', 'هل يمكنني رؤية قائمة النبيذ؟', 'restaurant', 2),
  generateWord('Coffee', 'قهوة', 'KOF-ee', 'One coffee, black please.', 'قهوة واحدة سوداء من فضلك.', 'restaurant', 1),
  generateWord('Tea', 'شاي', 'TEE', 'I\'d like green tea, please.', 'أود شاياً أخضر من فضلك.', 'restaurant', 1),
];

// Travel and Airports
const travelWords: Word[] = [
  generateWord('Passport', 'جواز السفر', 'PAS-port', 'Don\'t forget your passport!', 'لا تنسَ جواز سفرك!', 'travel-airports', 1),
  generateWord('Boarding pass', 'بطاقة الصعود', 'BOR-ding pas', 'Show your boarding pass at the gate.', 'أظهر بطاقة صعودك عند البوابة.', 'travel-airports', 1),
  generateWord('Flight', 'رحلة جوية', 'FLYT', 'What time is our flight?', 'متى رحلتنا الجوية؟', 'travel-airports', 1),
  generateWord('Gate', 'بوابة', 'GAYT', 'Our gate is number 12.', 'بوابتنا رقم 12.', 'travel-airports', 1),
  generateWord('Terminal', 'صالة', 'TER-muh-nul', 'The terminal is very big.', 'الصالة كبيرة جداً.', 'travel-airports', 2),
  generateWord('Luggage', 'أمتعة', 'LUG-ij', 'Where is the luggage claim?', 'أين مكان استلام الأمتعة؟', 'travel-airports', 1),
  generateWord('Suitcase', 'حقيبة سفر', 'SOOT-kays', 'My suitcase weighs 20 kilograms.', 'حقيبتي تزن 20 كيلوغراماً.', 'travel-airports', 1),
  generateWord(' suitcase', 'حقيبة', 'BAG', 'I\'m looking for my bag.', 'أبحث عن حقيبتي.', 'travel-airports', 1),
  generateWord('Airport', 'مطار', 'AIR-port', 'The airport is very crowded today.', 'المطار مكتظ جداً اليوم.', 'travel-airports', 1),
  generateWord('Arrivals', 'الوصول', 'uh-RY-vulz', 'The arrivals area is on the first floor.', 'منطقة الوصول في الطابق الأول.', 'travel-airports', 2),
  generateWord('Departures', 'المغادرة', 'di-PAR-churz', 'Check the departures board for updates.', 'تحقق من لوحة المغادرة للتحديثات.', 'travel-airports', 2),
  generateWord('Delay', 'تأخير', 'di-LAY', 'There\'s a two-hour flight delay.', 'هناك تأخير في الرحلة لمدة ساعتين.', 'travel-airports', 2),
  generateWord('Cancel', 'إلغاء', 'KAN-sl', 'My flight was cancelled due to weather.', 'تم إلغاء رحلتي بسبب الطقس.', 'travel-airports', 2),
  generateWord('Security', 'أمن', 'si-KYOOR-uh-tee', 'Go through security, please.', 'مر عبر نقطة الأمان من فضلك.', 'travel-airports', 2),
  generateWord('Customs', 'جمارك', 'KUS-tums', 'Do you have anything to declare at customs?', 'هل لديك شيء Declare في الجمارك؟', 'travel-airports', 2),
  generateWord('Immigration', 'الهجرة', 'im-uh-GRAY-shun', 'Please line up at immigration.', 'الرجاء الوقوف في طابور الهجرة.', 'travel-airports', 2),
  generateWord('Visa', 'تأشيرة', 'VEE-zuh', 'Do I need a visa for this country?', 'هل أحتاج تأشيرة لهذا البلد؟', 'travel-airports', 2),
  generateWord('Destination', 'الوجهة', 'des-tuh-NAY-shun', 'What\'s your final destination?', 'ما هي وجهتك النهائية؟', 'travel-airports', 2),
  generateWord('Seat', 'مقعد', 'SEET', 'I\'d like a window seat.', 'أود مقعداً بجانب النافذة.', 'travel-airports', 1),
  generateWord('Aisle', 'ممر', 'YL', 'I prefer the aisle seat for more legroom.', 'أفضل مقعد الممر للحصول على مساحة أكبر للساقين.', 'travel-airports', 2),
  generateWord('Take off', 'إقلاع', 'TAYK of', 'The plane is about to take off.', 'الطائرة على وشك الإقلاع.', 'travel-airports', 1),
  generateWord('Landing', 'هبوط', 'LAN-ding', 'We\'re beginning our descent for landing.', 'نحن نبدأ نزولنا للهبوط.', 'travel-airports', 2),
  generateWord('Baggage allowance', 'السماح للأمتعة', 'BAG-ij uh-LOW-uhns', 'What\'s the baggage allowance?', 'ما هو الحد المسموح للأمتعة؟', 'travel-airports', 2),
  generateWord('Overweight', 'زيادة الوزن', 'OH-ver-wayt', 'My luggage is overweight by 3 kilos.', 'أمتعتي زائدة الوزن بـ 3 كيلوغرامات.', 'travel-airports', 2),
  generateWord('Lost and found', 'الأشياء المفقودة', 'lost and found', 'I need to go to lost and found.', 'أحتاج للذهاب إلى قسم المفقودات.', 'travel-airports', 2),
  generateWord('Check-in', 'تسجيل الوصول', 'CHEK-in', 'Online check-in opens at midnight.', 'تسجيل الوصول عبر الإنترنت يفتح في منتصف الليل.', 'travel-airports', 2),
  generateWord('Carry-on', 'حقيبة يد', 'KAR-ee-on', 'This is my carry-on luggage.', 'هذه حقيبة يدي.', 'travel-airports', 2),
  generateWord('Connection', 'ترانزيت', 'kuh-NEK-shun', 'My connection flight is in 2 hours.', 'رحلتي الترانزيت بعد ساعتين.', 'travel-airports', 2),
  generateWord('Runway', 'مدرج', 'RUN-way', 'The plane is waiting on the runway.', 'الطائرة تنتظر على المدرج.', 'travel-airports', 3),
  generateWord('Captain', 'قائد الطائرة', 'KAP-tun', 'The captain has turned on the seatbelt sign.', 'قائد الطائرة أشعل ضوء حزام الأمان.', 'travel-airports', 2),
  generateWord('Turbulence', 'اضطراب', 'ter-byoo-LUNS', 'We\'re experiencing some turbulence.', 'نواجه بعض الاضطراب.', 'travel-airports', 3),
  generateWord('Emergenciy exit', 'مخرج الطوارئ', 'i-MER-jun-see eg-zit', 'Please locate your nearest emergency exit.', 'الرجاء تحديد أقرب مخرج للطوارئ.', 'travel-airports', 2),
  generateWord('Life vest', 'سترة النجاة', 'lyf vest', 'Put on your life vest underneath your seat.', 'البس سترة النجاة تحت مقعدك.', 'travel-airports', 2),
  generateWord('Tray table', 'طاولة Tray', 'TRAY TAY-bul', 'Put your tray table up for landing.', 'ارفع طاولة Tray الخاصة بك للهبوط.', 'travel-airports', 2),
  generateWord('Reclining seat', 'مقعد قابل للرجوع', 'ri-KLY-ing seet', 'Please return your seat to upright position.', 'الرجاء إعادة مقعدك إلى الوضع العمودي.', 'travel-airports', 2),
  generateWord('First class', 'الدرجة الأولى', 'FERST klas', 'We\'re now boarding first class passengers.', 'نقوم الآن بصعود ركاب الدرجة الأولى.', 'travel-airports', 2),
  generateWord('Economy', 'الدرجة الاقتصادية', 'i-KON-uh-mee', 'Economy class is at the back of the plane.', 'الدرجة السياحية في مؤخرة الطائرة.', 'travel-airports', 2),
  generateWord('Upgrade', 'ترقية', 'UP-grayd', 'Can I upgrade to business class?', 'هل يمكنني الترقية إلى درجة رجال الأعمال؟', 'travel-airports', 2),
  generateWord('Travel insurance', 'تأمين سفر', 'TRAV-ul in-SHUR-uhns', 'Do you have travel insurance?', 'هل لديك تأمين سفر؟', 'travel-airports', 2),
];

// More categories continue... (I'll add more substantial word lists)
const technologyWords: Word[] = [
  generateWord('Computer', 'حاسوب', 'kum-PYOO-ter', 'I need a new computer for work.', 'أحتاج حاسوباً جديداً للعمل.', 'technology', 1),
  generateWord('Internet', 'إنترنت', 'IN-ter-net', 'The internet connection is slow today.', 'اتصال الإنترنت بطيء اليوم.', 'technology', 1),
  generateWord('Website', 'موقع إلكتروني', 'WEB-syt', 'Visit our website for more info.', 'زُر موقعنا الإلكترونى لمزيد من المعلومات.', 'technology', 1),
  generateWord('Email', 'بريد إلكتروني', 'EE-mayl', 'I sent you an email this morning.', 'أرسلت لك بريداً إلكترونياً هذا الصباح.', 'technology', 1),
  generateWord('Software', 'برنامج', 'SOFT-wair', 'I need to update my software.', 'أحتاج لتحديث برنامجي.', 'technology', 2),
  generateWord('Hardware', 'عتاد', 'HARD-wair', 'The hardware needs to be replaced.', 'العتاد يحتاج للاستبدال.', 'technology', 2),
  generateWord('Download', 'تحميل', 'DAHN-lohd', 'Let me download this file.', 'دعني أحمّل هذا الملف.', 'technology', 1),
  generateWord('Upload', 'رفع', 'UP-lohd', 'I need to upload my documents.', 'أحتاج لرفع مستنداتي.', 'technology', 1),
  generateWord('Password', 'كلمة مرور', 'PAS-wurd', 'Remember to change your password regularly.', 'تذكر تغيير كلمة مرورك بانتظام.', 'technology', 1),
  generateWord('Username', 'اسم المستخدم', 'YOO-zer-naym', 'What\'s your username?', 'ما اسم المستخدم الخاص بك؟', 'technology', 1),
  generateWord('Login', 'تسجيل الدخول', 'LOG-in', 'Click here to login.', 'اضغط هنا لتسجيل الدخول.', 'technology', 1),
  generateWord('Logout', 'تسجيل الخروج', 'LOG-out', 'Please logout when you\'re done.', 'الرجاء تسجيل الخروج عند الانتهاء.', 'technology', 1),
  generateWord('App', 'تطبيق', 'AP', 'ASP', 'Download our new app today!', 'حمّل تطبيقنا الجديد اليوم!', 'technology', 1),
  generateWord('Screen', 'شاشة', 'SKREEN', 'The screen is too small for this.', 'الشاشة صغيرة جداً لهذا.', 'technology', 1),
  generateWord('Keyboard', 'لوحة المفاتيح', 'KEE-bor', 'The keyboard isn\'t working properly.', 'لوحة المفاتيح لا تعمل بشكل صحيح.', 'technology', 1),
  generateWord('Mouse', 'فأرة', 'MOS', 'I need a wireless mouse.', 'أحتاج فأرة لاسلكية.', 'technology', 1),
  generateWord('Charging', 'شحن', 'CHAR-jing', 'My phone needs charging.', 'هاتفي يحتاج للشحن.', 'technology', 1),
  generateWord('Battery', 'بطارية', 'BAT-uh-ree', 'The battery lasts all day.', 'البطارية تدوم طوال اليوم.', 'technology', 1),
  generateWord('WiFi', 'واي فاي', 'WY-fy', 'What\'s the WiFi password?', 'ما هي كلمة مرور الواي فاي؟', 'technology', 1),
  generateWord('Bluetooth', 'بلوتوث', 'BLoo-tooth', 'Turn on Bluetooth to connect.', 'شغّل البلوتوث للاتصال.', 'technology', 2),
  generateWord('Cloud', 'سحابة', 'KLOWD', 'Save your files to the cloud.', 'احفظ ملفاتك على السحابة.', 'technology', 2),
  generateWord('Camera', 'كاميرا', 'KAM-uh-ruh', 'The camera quality is excellent.', 'جودة الكاميرا ممتازة.', 'technology', 1),
  generateWord('Speaker', 'مكبر صوت', 'SPEE-kur', 'Connect to the Bluetooth speaker.', 'اتصل بمكبر الصوت البلوتوثي.', 'technology', 1),
  generateWord('Headphones', 'سماعات', 'HED-fohnz', 'I prefer wireless headphones.', 'أفضل السماعات اللاسلكية.', 'technology', 1),
  generateWord('Tablet', 'جهاز لوحي', 'TAB-luht', 'Use the tablet for the presentation.', 'استخدم الجهاز اللوحي للعرض.', 'technology', 1),
  generateWord('Smartphone', 'هاتف ذكي', 'SMAHRT-fohn', 'Everyone has a smartphone now.', 'الجميع الآن لديه هاتف ذكي.', 'technology', 1),
  generateWord('Laptop', 'حاسوب محمول', 'LAP-top', 'I work from my laptop at home.', 'أعمل من حاسوبي المحمول في البيت.', 'technology', 1),
  generateWord('Printer', 'طابعة', 'PRY-ter', 'The printer is out of ink.', 'الطابعة نفد الحبر منها.', 'technology', 2),
  generateWord('Scanner', 'ماسح ضوئي', 'SKAN-er', 'Use the scanner to copy documents.', 'استخدم الماسح الضوئي لنسخ المستندات.', 'technology', 2),
  generateWord('Router', 'موجه', 'ROW-ter', 'Restart the router to fix the connection.', 'أعد تشغيل الموجه لإصلاح الاتصال.', 'technology', 2),
  generateWord('Server', 'خادم', 'SER-ver', 'The server is down for maintenance.', 'الخادم متوقف للصيانة.', 'technology', 3),
  generateWord('Database', 'قاعدة بيانات', 'DAY-tuh-bays', 'Update the database with new records.', 'حدّث قاعدة البيانات بسجلات جديدة.', 'technology', 3),
  generateWord('Backup', 'نسخة احتياطية', 'BAK-up', 'Create a backup of your files.', 'أنشئ نسخة احتياطية من ملفاتك.', 'technology', 2),
  generateWord('Update', 'تحديث', 'UP-dayt', 'There\'s a new update available.', 'هناك تحديث جديد متاح.', 'technology', 1),
  generateWord('Upgrade', 'ترقية', 'UP-grayd', 'It\'s time to upgrade your system.', 'حان الوقت لترقية نظامك.', 'technology', 2),
  generateWord('Bug', 'خلل', 'BUG', 'They fixed a bug in the latest version.', 'أصلحوا خللاً في النسخة الأخيرة.', 'technology', 2),
  generateWord('Virus', 'فيروس', 'VY-rus', 'My computer has a virus.', 'حاسوبي مصاب بفايروس.', 'technology', 2),
  generateWord('Antivirus', 'مضاد فيروسات', 'an-tee-VY-rus', 'Install antivirus software.', 'ثبّت برنامج مضاد الفيروسات.', 'technology', 2),
  generateWord('Firewall', 'جدار حماية', 'FYR-wol', 'The firewall blocked the connection.', 'جدار الحماية حظر الاتصال.', 'technology', 3),
];

// Food and Drinks
const foodWords: Word[] = [
  generateWord('Water', 'ماء', 'WOT-er', 'Can I have a glass of water?', 'هل يمكنني الحصول على كوب ماء؟', 'food-drinks', 1),
  generateWord('Bread', 'خبز', 'BRED', 'Fresh bread is delicious.', 'الخبز الطازج لذيذ.', 'food-drinks', 1),
  generateWord('Rice', 'أرز', 'RYS', 'I prefer white rice with curry.', 'أفضل الأرز الأبيض مع الكاري.', 'food-drinks', 1),
  generateWord('Chicken', 'دجاج', 'CHIK-en', 'Grilled chicken is my favorite.', 'الدجاج المشوي مفضلي.', 'food-drinks', 1),
  generateWord('Meat', 'لحم', 'MEET', 'I don\'t eat red meat.', 'لا آكل اللحم الأحمر.', 'food-drinks', 1),
  generateWord('Fish', 'سمك', 'FISH', 'Fresh fish is available today.', 'السمك الطازج متوفر اليوم.', 'food-drinks', 1),
  generateWord('Egg', 'بيضة', 'EG', 'I\'d like a fried egg.', 'أود بيضة مقلية.', 'food-drinks', 1),
  generateWord('Cheese', 'جبن', 'CHEEZ', 'I love cheese on my pizza.', 'أحب الجبن على البيتزا.', 'food-drinks', 1),
  generateWord('Milk', 'حليب', 'MILK', 'I drink milk every morning.', 'esh', 'أشرب الحليب كل صباح.', 'food-drinks', 1),
  generateWord('Butter', 'زبدة', 'BUT-er', 'Put butter on the bread.', 'ضع الزبدة على الخبز.', 'food-drinks', 1),
  generateWord('Sugar', 'سكر', 'SHOOG-er', 'I take my coffee without sugar.', 'أشرب قهوتي بدون سكر.', 'food-drinks', 1),
  generateWord('Salt', 'ملح', 'SALT', 'This food needs more salt.', 'هذا الطعام يحتاج ملحاً أكثر.', 'food-drinks', 1),
  generateWord('Oil', 'زيت', 'OYL', 'Use olive oil for cooking.', 'استخدم زيت الزيتون للطبخ.', 'food-drinks', 1),
  generateWord('Fruit', 'فاكهة', 'FROOT', 'Eat more fruit for health.', 'كُل المزيد من الفاكهة للصحة.', 'food-drinks', 1),
  generateWord('Apple', 'تفاحة', 'AP-ul', 'An apple a day keeps the doctor away.', 'تفاحة في اليوم تُبعد Doctor.', 'food-drinks', 1),
  generateWord('Orange', 'برتقالة', 'OR-inj', 'I\'d like some orange juice.', 'أود بعض عصير البرتقان.', 'food-drinks', 1),
  generateWord('Banana', 'موز', 'buh-NAN-uh', 'Bananas are rich in potassium.', 'الموز غني بالبوتاسيوم.', 'food-drinks', 1),
  generateWord('Vegetable', 'خضار', 'VEJ-tuh-bul', 'Eat your vegetables!', 'كُل خضارك!', 'food-drinks', 1),
  generateWord('Tomato', 'طماطم', 'tuh-MAH-toh', 'This tomato is very ripe.', 'هذه الطماطم ناضجة جداً.', 'food-drinks', 1),
  generateWord('Onion', 'بصلة', 'UN-yun', 'Don\'t add onion please.', 'من فضلك لا تضف بصلاً.', 'food-drinks', 1),
  generateWord('Garlic', 'ثوم', 'GAR-lik', 'Garlic is good for health.', 'الثوم مفيد للصحة.', 'food-drinks', 1),
  generateWord('Potato', 'بطاطس', 'puh-TAY-toh', 'I love French fries.', 'أحب بطاطس fries.', 'food-drinks', 1),
  generateWord('Carrot', 'جزر', 'KAR-ut', 'Carrots are good for your eyes.', 'الجزر مفيد لعينيك.', 'food-drinks', 1),
  generateWord('Salad', 'سلطة', 'SAL-ud', 'I\'ll have a green salad.', 'سآخذ سلطة خضراء.', 'food-drinks', 1),
  generateWord('Soup', 'حساء', 'SOOP', 'This soup is very flavorful.', 'هذا الحساء مليء بالنكهة.', 'food-drinks', 1),
  generateWord('Pasta', 'معكرونة', 'PAS-tuh', 'Let\'s have pasta for dinner.', 'هيا نتناول المعكرونة للعشاء.', 'food-drinks', 1),
  generateWord('Pizza', 'بيتزا', 'PEET-suh', 'I\'m craving some pizza.', 'أرغب في البيتزا.', 'food-drinks', 1),
  generateWord('Burger', 'برغر', 'BUR-ger', 'I want a burger with fries.', 'أريد برغر مع بطاطس.', 'food-drinks', 1),
  generateWord('Sandwich', 'ساندويتش', 'SAND-wich', 'This sandwich is very filling.', 'هذا الساندويتش مشبع جداً.', 'food-drinks', 1),
  generateWord('Ice cream', 'آيس كريم', 'YS kreem', 'I\'ll have chocolate ice cream.', 'سآخذ آيس كريم بالشوكولاتة.', 'food-drinks', 1),
  generateWord('Chocolate', 'شوكولاتة', 'CHOK-uh-luht', 'Dark chocolate is good for you.', 'الشوكولاتة الداكنة مفيدة لك.', 'food-drinks', 1),
  generateWord('Cake', 'كيك', 'KAYK', 'Happy birthday! Let\'s have cake!', 'عيد ميلاد سعيد! هيا نأكل كيك!', 'food-drinks', 1),
  generateWord('Cookie', 'كوكي', 'KOOK-ee', 'I baked fresh cookies today.', 'خبزث كوكيز طازجة اليوم.', 'food-drinks', 1),
  generateWord('Honey', 'عسل', 'HUN-ee', 'Honey is a natural sweetener.', 'العسل مُحلّي طبيعي.', 'food-drinks', 1),
  generateWord('Coffee', 'قهوة', 'KOF-ee', 'I need my morning coffee.', 'أحتاج قهوتي الصباحية.', 'food-drinks', 1),
  generateWord('Tea', 'شاي', 'TEE', 'Would you like some tea?', 'هل تحب بعض الشاي؟', 'food-drinks', 1),
  generateWord('Juice', 'عصير', 'JOOS', 'Fresh orange juice, please.', 'عصير برتقان طازج من فضلك.', 'food-drinks', 1),
  generateWord('Soda', 'مشروب غازي', 'SOH-duh', 'I\'ll have a soda, please.', 'سآخذ مشروباً غازياً من فضلك.', 'food-drinks', 1),
  generateWord('Wine', 'نبيذ', 'WYN', 'A glass of red wine, please.', 'كأس نبيذ أحمر من فضلك.', 'food-drinks', 2),
];

// Common Verbs
const verbWords: Word[] = [
  generateWord('Be', 'يكون', 'bee', 'I am happy.', 'أنا سعيد.', 'common-verbs', 1, 'verb'),
  generateWord('Have', 'يملك', 'HAV', 'I have a car.', 'لدي سيارة.', 'common-verbs', 1, 'verb'),
  generateWord('Do', 'يفعل', 'DOO', 'I do my homework every day.', 'أفعل واجباتي كل يوم.', 'common-verbs', 1, 'verb'),
  generateWord('Say', 'يقول', 'SAY', 'What did you say?', 'ماذا قلت؟', 'common-verbs', 1, 'verb'),
  generateWord('Get', 'يحصل', 'GET', 'I got your message.', 'حصلت على رسالتك.', 'common-verbs', 1, 'verb'),
  generateWord('Make', 'يصنع', 'MAYK', 'Let me make coffee.', 'دعني أصنع القهوة.', 'common-verbs', 1, 'verb'),
  generateWord('Go', 'يذهب', 'GOH', 'Let\'s go home.', 'هيا نذهب للمنزل.', 'common-verbs', 1, 'verb'),
  generateWord('Take', 'يأخذ', 'TAYK', 'Take this with you.', 'خُذ هذا معك.', 'common-verbs', 1, 'verb'),
  generateWord('Come', 'يأتي', 'KUM', 'Please come here.', 'الرجاء تعال هنا.', 'common-verbs', 1, 'verb'),
  generateWord('See', 'يرى', 'SEE', 'I can see the mountains.', 'أستطيع رؤية الجبال.', 'common-verbs', 1, 'verb'),
  generateWord('Know', 'يعرف', 'NOH', 'I know the answer.', 'أعرف الإجابة.', 'common-verbs', 1, 'verb'),
  generateWord('Think', 'يفكر', 'THINGK', 'I think you\'re right.', 'أظن أنك على حق.', 'common-verbs', 1, 'verb'),
  generateWord('Look', 'ينظر', 'LOOK', 'Look at this!', 'انظر لهذا!', 'common-verbs', 1, 'verb'),
  generateWord('Want', 'يريد', 'WONT', 'I want to learn English.', 'أريد أن أتعلم الإنجليزية.', 'common-verbs', 1, 'verb'),
  generateWord('Give', 'يعطي', 'GIV', 'Give me a call.', 'اتصل بي.', 'common-verbs', 1, 'verb'),
  generateWord('Use', 'يستخدم', 'YOOS', 'Use this tool.', 'استخدم هذه الأداة.', 'common-verbs', 1, 'verb'),
  generateWord('Find', 'يجد', 'FYND', 'I can\'t find my keys.', 'لا أستطيع إيجاد مفاتيحي.', 'common-verbs', 1, 'verb'),
  generateWord('Tell', 'يخبر', 'TEL', 'Tell me the truth.', 'أخبرني بالحقيقة.', 'common-verbs', 1, 'verb'),
  generateWord('Ask', 'يسأل', 'ASK', 'Ask me anything.', 'اسألني أي شيء.', 'common-verbs', 1, 'verb'),
  generateWord('Work', 'يعمل', 'WURK', 'I work at a bank.', 'أعمل في بنك.', 'common-verbs', 1, 'verb'),
  generateWord('Try', 'يحاول', 'TRY', 'Try again.', 'حاول مرة أخرى.', 'common-verbs', 1, 'verb'),
  generateWord('Call', 'ياتصل', 'KOL', 'Call me tomorrow.', 'اتصل بي غداً.', 'common-verbs', 1, 'verb'),
  generateWord('Need', 'يحتاج', 'NEED', 'I need help.', 'أحتاج مساعدة.', 'common-verbs', 1, 'verb'),
  generateWord('Feel', 'يشعر', 'FEEL', 'I feel happy today.', 'أشعر بالسعادة اليوم.', 'common-verbs', 1, 'verb'),
  generateWord('Become', 'يصبح', 'bi-KUM', 'I want to become a doctor.', 'أريد أن أصبح طبيباً.', 'common-verbs', 2, 'verb'),
  generateWord('Leave', 'يترك', 'LEEV', 'I have to leave now.', 'يجب أن أترك الآن.', 'common-verbs', 1, 'verb'),
  generateWord('Put', 'يضع', 'PUT', 'Put it on the table.', 'ضعه على الطاولة.', 'common-verbs', 1, 'verb'),
  generateWord('Mean', 'يعني', 'MEEN', 'What does this mean?', 'ماذا يعني هذا؟', 'common-verbs', 1, 'verb'),
  generateWord('Keep', 'يحافظ', 'KEEP', 'Keep going!', 'استمر!', 'common-verbs', 1, 'verb'),
  generateWord('Let', 'يدع', 'LET', 'Let me help you.', 'دعني أساعدك.', 'common-verbs', 1, 'verb'),
  generateWord('Begin', 'يبدأ', 'bi-GIN', 'Let\'s begin the lesson.', 'هيا نبدأ الدرس.', 'common-verbs', 2, 'verb'),
  generateWord('Seem', 'يبدو', 'SEEM', 'You seem tired.', 'تبدو متعباً.', 'common-verbs', 2, 'verb'),
  generateWord('Help', 'يساعد', 'HELP', 'Can you help me?', 'هل يمكنك مساعدتي؟', 'common-verbs', 1, 'verb'),
  generateWord('Show', 'يُظهر', 'SHOH', 'Show me how to do it.', 'أظهر لي كيف أفعلها.', 'common-verbs', 1, 'verb'),
  generateWord('Play', 'يلعب', 'PLAY', 'Let\'s play a game.', 'هيا نلعب لعبة.', 'common-verbs', 1, 'verb'),
  generateWord('Run', 'يهرول', 'RUN', 'I run every morning.', 'أهرول كل صباح.', 'common-verbs', 1, 'verb'),
  generateWord('Move', 'يتحرك', 'MOOV', 'Don\'t move!', 'لا تتحرك!', 'common-verbs', 1, 'verb'),
  generateWord('Live', 'يعيش', 'LIV', 'I live in Cairo.', 'أعيش في القاهرة.', 'common-verbs', 1, 'verb'),
  generateWord('Believe', 'يؤمن', 'bi-LEEV', 'I believe in you.', 'أؤمن بك.', 'common-verbs', 2, 'verb'),
  generateWord('Bring', 'يجلب', 'BRING', 'Bring me a glass of water.', 'اجلب لي كوب ماء.', 'common-verbs', 2, 'verb'),
];

// Common Adjectives
const adjectiveWords: Word[] = [
  generateWord('Good', 'جيد', 'GOOD', 'This is a good idea.', 'هذه فكرة جيدة.', 'common-adjectives', 1, 'adjective'),
  generateWord('Bad', 'سيء', 'BAD', 'That was a bad decision.', 'تلك كانت قراراً سيئاً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Big', 'كبير', 'BIG', 'This is a big house.', 'هذا منزل كبير.', 'common-adjectives', 1, 'adjective'),
  generateWord('Small', 'صغير', 'SMOL', 'I have a small car.', 'لدي سيارة صغيرة.', 'common-adjectives', 1, 'adjective'),
  generateWord('New', 'جديد', 'NOO', 'I bought a new phone.', 'اشتريت هاتفاً جديداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Old', 'قديم', 'OHLD', 'This is an old building.', 'هذا مبنى قديم.', 'common-adjectives', 1, 'adjective'),
  generateWord('Young', 'شاب', 'YUNG', 'She is very young.', 'هي صغيرة جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Long', 'طويل', 'LONG', 'It\'s a long road.', 'إنها طريق طويل.', 'common-adjectives', 1, 'adjective'),
  generateWord('Short', 'قصير', 'SHORT', 'I have short hair.', 'لدي شعر قصير.', 'common-adjectives', 1, 'adjective'),
  generateWord('Beautiful', 'جميل', 'BYOO-tuh-ful', 'What a beautiful view!', 'ما هي منظر جميل!', 'common-adjectives', 1, 'adjective'),
  generateWord('Ugly', 'قبيح', 'UG-lee', 'Don\'t judge by looks, ugly things can be beautiful.', 'لا تحكم بالمظهر، الأشياء القبيحة يمكن أن تكون جميلة.', 'common-adjectives', 1, 'adjective'),
  generateWord('Happy', 'سعيد', 'HAP-ee', 'You look happy today.', 'تبدو سعيداً اليوم.', 'common-adjectives', 1, 'adjective'),
  generateWord('Sad', 'حزين', 'SAD', 'Don\'t be sad.', 'لا تحزن.', 'common-adjectives', 1, 'adjective'),
  generateWord('Hot', 'حار', 'HOT', 'The weather is very hot.', 'الطقس حار جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Cold', 'بارد', 'KOLD', 'It\'s cold outside.', 'الطقس بارد بالخارج.', 'common-adjectives', 1, 'adjective'),
  generateWord('Fast', 'سريع', 'FAST', 'He is a fast runner.', 'هو عدّاء سريع.', 'common-adjectives', 1, 'adjective'),
  generateWord('Slow', 'بطيء', 'SLOH', 'The traffic is very slow.', 'المرور بطيء جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Easy', 'سهل', 'EE-zee', 'This test is easy.', 'هذا الاختبار سهل.', 'common-adjectives', 1, 'adjective'),
  generateWord('Difficult', 'صعب', 'DIF-uh-kult', 'Math is difficult for me.', 'الرياضيات صعبة عليّ.', 'common-adjectives', 1, 'adjective'),
  generateWord('Rich', 'غني', 'RICH', 'He is a rich man.', 'هو رجل غني.', 'common-adjectives', 1, 'adjective'),
  generateWord('Poor', 'فقير', 'POOR', 'Help the poor people.', 'ساعد الفقراء.', 'common-adjectives', 1, 'adjective'),
  generateWord('Clean', 'نظيف', 'KLEEN', 'This room is very clean.', 'هذه الغرفة نظيفة جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Dirty', 'وسخ', 'DUR-tee', 'My shoes are dirty.', 'حذائي وسخ.', 'common-adjectives', 1, 'adjective'),
  generateWord('Bright', 'مشرق', 'BRYT', 'The future looks bright.', 'المستقبل يبدو مشرقاً.', 'common-adjectives', 2, 'adjective'),
  generateWord('Dark', 'داكن', 'DARK', 'The room is very dark.', 'الغرفة داكنة جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Strong', 'قوي', 'STRONG', 'He is a strong man.', 'هو رجل قوي.', 'common-adjectives', 1, 'adjective'),
  generateWord('Weak', 'ضعيف', 'WEEK', 'I feel weak today.', 'أشعر بالضعف اليوم.', 'common-adjectives', 1, 'adjective'),
  generateWord('High', 'عالي', 'HY', 'The building is very high.', 'المبنى مرتفع جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Low', 'منخفض', 'LOH', 'The price is low.', 'السعر منخفض.', 'common-adjectives', 1, 'adjective'),
  generateWord('Wide', 'واسع', 'WYD', 'The road is wide.', 'الطريق واسع.', 'common-adjectives', 2, 'adjective'),
  generateWord('Narrow', 'ضيق', 'NAR-oh', 'This is a narrow street.', 'هذه شارع ضيق.', 'common-adjectives', 2, 'adjective'),
  generateWord('Deep', 'عميق', 'DEEP', 'The ocean is very deep.', 'المحيط عميق جداً.', 'common-adjectives', 2, 'adjective'),
  generateWord('Laughed', 'ضحك', 'LAF', 'She laughed at the joke.', 'هي ضحكت على النكتة.', 'common-adjectives', 2, 'adjective'),
  generateWord('Thick', 'سميك', 'THIK', 'This book is thick.', 'هذا الكتاب سميك.', 'common-adjectives', 2, 'adjective'),
  generateWord('Thin', 'رفيع', 'THIN', 'She has thin hair.', 'لديها شعر رفيع.', 'common-adjectives', 2, 'adjective'),
  generateWord('Soft', 'ناعم', 'SOFT', 'This fabric is very soft.', 'هذه القماش ناعمة جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Hard', 'صعب', 'HARD', 'Life can be hard.', 'الحياة يمكن أن تكون صعبة.', 'common-adjectives', 1, 'adjective'),
  generateWord('Light', 'خفيف', 'LYT', 'This box is light.', 'هذه العلبة خفيفة.', 'common-adjectives', 1, 'adjective'),
  generateWord('Heavy', 'ثقيل', 'HEV-ee', 'This bag is too heavy.', 'هذه الحقيبة ثقيلة جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Loud', 'صخب', 'LOWD', 'The music is too loud.', 'الموسيقى صخب جداً.', 'common-adjectives', 1, 'adjective'),
  generateWord('Quiet', 'هادئ', 'KWY-ut', 'Please be quiet.', 'الرجاء كن هادئاً.', 'common-adjectives', 1, 'adjective'),
];

// Idioms and Expressions
const idiomWords: Word[] = [
  generateWord('Break a leg', 'حظاً موفقاً', 'BRAYK uh LEG', 'Break a leg on your exam!', 'حظاً موفقاً في امتحانك!', 'idioms-expressions', 2, 'idiom'),
  generateWord('Break the ice', 'كسر حاجز الخجل', 'BRAYK thuh YS', 'He tried to break the ice with a joke.', 'حاول كسر حاجز الخجل بنكتة.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Hit the nail on the head', 'أصيب كبد الأمر', 'HIT thuh nayl on thuh HED', 'You hit the nail on the head with your analysis.', 'أصبت كبد الأمر بتحليلك.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Piece of cake', 'أمر سهل', 'PEES uhv KAYK', 'The exam was a piece of cake!', 'الاختبار كان أمراً سهلاً!', 'idioms-expressions', 1, 'idiom'),
  generateWord('Cost an arm and a leg', 'مكلف جداً', 'KOST an ARM and uh LEG', 'That designer bag costs an arm and a leg.', 'تلك الحقيبة Designer مكلفة جداً.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Bite the bullet', 'يواجه الموقف بشجاعة', 'BYT thuh BOO-lit', 'You have to bite the bullet and tell him.', 'يجب أن تواجه الموقف بشجاعة وتخبره.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Burning the midnight oil', 'السهر حتى وقت متأخر', 'BUR-ning thuh MY-dayt YL', 'She was burning the midnight oil to finish the project.', 'كانت تسهر حتى وقت متأخر لإنهاء المشروع.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Kill two birds with one stone', 'عصفورين بحجر', 'KIL TOO BURDZ with WUN STON', 'Studying here kills two birds with one stone.', 'الدراسة هنا تضرب عصفورين بحجر.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Let the cat out of the bag', 'كشف السر', 'LET thuh KAT owt uhv thuh BAG', 'Who let the cat out of the bag?', 'من كشف السر؟', 'idioms-expressions', 3, 'idiom'),
  generateWord('Miss the boat', 'ضيع الفرصة', 'MIS thuh BOHT', 'Don\'t miss the boat on this opportunity.', 'لا تضيع الفرصة في هذه الفرصة.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Once in a blue moon', 'نادراً ما', 'WUNS IN uh BLOO MOON', 'He visits us once in a blue moon.', 'يزورنا نادراً ما.', 'idioms-expressions', 3, 'idiom'),
  generateWord('On thin ice', 'في موقف خطر', 'ON THIN YS', 'He is on thin ice after being late again.', 'هو في موقف خطر بعد التأخر مرة أخرى.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Under the weather', 'متوعك', 'UN-der THU WETH-er', 'I\'m feeling under the weather today.', 'أشعر بالتوعك اليوم.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Spill the beans', 'كشف المعلومات', 'SPIL thuh BEENZ', 'Please don\'t spill the beans about the party.', 'الرجاء لا تكشف المعلومات عن الحفلة.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Raining cats and dogs', 'تمطر بشدة', 'RAY-ning kats and DAGS', 'It\'s raining cats and dogs outside.', 'إنها تمطر بشدة بالخارج.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Elvis has left the building', 'انتهى الأمر', 'EL-vis haz left thuh BIL-ding', 'After the concert, Elvis has left the building.', 'بعد الحفلة، انتهى الأمر.', 'idioms-expressions', 3, 'idiom'),
  generateWord('The ball is in your court', 'القرار بيدك', 'THUH BOL iz IN yor KORT', 'The ball is in your court now.', 'القرار теперь بيدك.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Hit the sack', 'يذهب للنوم', 'HIT thuh SAK', 'I\'m tired, I\'m going to hit the sack.', 'أنا متعب، سأذهب للنوم.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Burn bridges', 'تدمير العلاقات', 'BURN BRID-jiz', 'Don\'t burn bridges with your coworkers.', 'لا تدمير علاقاتك مع زملائك.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Bite off more than you can chew', 'تولي أكثر من طاقتك', 'BYT of MOR than yoo kan CHO', 'He bit off more than he could chew.', 'تولى أكثر من طاقته.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Beat around the bush', 'يتملّص من الموضوع', 'BEET uh-ROWD THUH BUSH', 'Stop beating around the bush and tell me.', 'توقف عن التملّص وقُل لي.', 'idioms-expressions', 3, 'idiom'),
  generateWord('A blessing in disguise', 'نعمة متخفية', 'uh BLES-sing in di-GYZ', 'Losing that job was a blessing in disguise.', 'فقدان تلك الوظيفة كان نعمة متخفية.', 'idioms-expressions', 3, 'idiom'),
  generateWord('Cry over spilled milk', 'لا فائدة من الحزن على ما فات', 'CRY OH-ver SPILD MILK', 'Don\'t cry over spilled milk.', 'لا تحزن على ما فات.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Best of both worlds', 'أفضل ما في العالمين', 'BEST ov BOHTH WURLDZ', 'Working from home is the best of both worlds.', 'العمل من البيت أفضل ما في العالمين.', 'idioms-expressions', 2, 'idiom'),
  generateWord('Fit as a fiddle', 'بصحة جيدة', 'FIT az uh DIF-ul', 'She\'s 80 but fit as a fiddle.', 'لديها 80 سنة لكنها بصحة جيدة.', 'idioms-expressions', 3, 'idiom'),
];

// Shopping and Supermarket
const shoppingWords: Word[] = [
  generateWord('Price', 'سعر', 'PRYS', 'What\'s the price of this shirt?', 'ما هو سعر هذه القميص؟', 'shopping-supermarket', 1),
  generateWord('Discount', 'خصم', 'DIS-kount', 'We have a 20% discount today.', 'لدينا خصم 20% اليوم.', 'shopping-supermarket', 1),
  generateWord('Sale', 'تخفيض', 'SAYL', 'Everything is on sale this week.', 'كل شيء هناك تخفيض هذا الأسبوع.', 'shopping-supermarket', 1),
  generateWord('Buy', 'يشتري', 'BY', 'I want to buy this dress.', 'أريد أن أشتري هذه الفستان.', 'shopping-supermarket', 1),
  generateWord('Sell', 'يبيع', 'SEL', 'They sell fresh vegetables here.', 'يبيعون خضروات طازجة هنا.', 'shopping-supermarket', 1),
  generateWord('Pay', 'يدفع', 'PAY', 'How would you like to pay?', 'كيف تحب أن تدفع؟', 'shopping-supermarket', 1),
  generateWord('Cash', 'نقدي', 'KASH', 'Do you pay by cash or card?', 'هل تدفع نقدياً أو بالبطاقة؟', 'shopping-supermarket', 1),
  generateWord('Card', 'بطاقة', 'KARD', 'I\'ll pay by card.', 'سأدفع بالبطاقة.', 'shopping-supermarket', 1),
  generateWord('Receipt', 'إيصال', 'ri-SEET', 'Keep your receipt for exchange.', 'احتفظ بإيصالك للاستبدال.', 'shopping-supermarket', 1),
  generateWord('Change', 'باقي', 'CHAYNJ', 'Do you have change for a hundred?', 'هل لديك باقي لمئة؟', 'shopping-supermarket', 1),
  generateWord('Size', 'مقاس', 'SYZ', 'What size do you wear?', 'ما المقاس الذي ترتديه؟', 'shopping-supermarket', 1),
  generateWord('Color', 'لون', 'KUL-er', 'What color do you prefer?', 'ما اللون الذي تفضله؟', 'shopping-supermarket', 1),
  generateWord('Try on', 'يجرب', 'TRY ON', 'Can I try this on?', 'هل يمكنني تجربة هذا؟', 'shopping-supermarket', 1),
  generateWord('Fitting room', 'غرفة التجربة', 'FIT-ting room', 'The fitting room is over there.', 'غرفة التجربة هناك.', 'shopping-supermarket', 1),
  generateWord('Too expensive', 'باهظ الثمن', 'TOO ik-SPEN-siv', 'This is too expensive for me.', 'هذا باهظ الثمن بالنسبة لي.', 'shopping-supermarket', 1),
  generateWord('Affordable', 'بمثابة', 'uh-FOR-duh-bul', 'Everything here is affordable.', 'كل شيء هنا بأسعار معقولة.', 'shopping-supermarket', 2),
  generateWord('Free', 'مجاني', 'FREE', 'Delivery is free over $50.', 'التوصيل مجاني فوق 50 دولار.', 'shopping-supermarket', 1),
  generateWord('Return', 'استبدال', 'ri-TURN', 'Can I return this item?', 'هل يمكنني استبدال هذا المنتج؟', 'shopping-supermarket', 1),
  generateWord('Exchange', 'تبادل', 'iks-CHAYNJ', 'I\'d like to exchange this for a larger size.', 'أود استبدال هذا بمقاس أكبر.', 'shopping-supermarket', 1),
  generateWord('Store', 'متجر', 'STOR', 'This store opens at 9 AM.', 'هذا المتجر يفتح في 9 صباحاً.', 'shopping-supermarket', 1),
  generateWord('Product', 'منتج', 'PROD-ukt', 'This product has a one-year warranty.', 'هذا المنتج له ضمان سنة.', 'shopping-supermarket', 1),
  generateWord('Brand', 'علامة تجارية', 'BRAND', 'What brand is this phone?', 'ما هي علامة هذا الهاتف التجارية؟', 'shopping-supermarket', 1),
  generateWord('Quality', 'جودة', 'KWOL-uh-tee', 'This product is high quality.', 'هذا المنتج عالي الجودة.', 'shopping-supermarket', 2),
  generateWord('Customer', 'عميل', 'KUS-tuh-mer', 'The customer is always right.', 'العميل دائماً على حق.', 'shopping-supermarket', 1),
  generateWord('Cart', 'عربة', 'KART', 'Get a cart for your groceries.', 'احصل على عربة لبقالتك.', 'shopping-supermarket', 1),
];

// More words to complete the 6000+ vocabulary
// I'll create a function to generate more words programmatically
// and ensure we have enough vocabulary for each category

// Combine all words into the main vocabulary array
export const vocabulary: Word[] = [
  ...dailyConversations,
  ...restaurantWords,
  ...travelWords,
  ...technologyWords,
  ...foodWords,
  ...verbWords,
  ...adjectiveWords,
  ...idiomWords,
  ...shoppingWords,
];

// Generate more words to reach 6000+ (I'll create a bulk generator)
const bulkGeneratedWords: Word[] = [];

const additionalCategories: Array<{
  category: Word['category'];
  words: Array<{ english: string; arabic: string; pronunciation: string; example: string; exampleArabic: string; difficulty?: Word['difficulty'] }>;
}> = [
  {
    category: 'hotels-booking',
    words: [
      { english: 'Room', arabic: 'غرفة', pronunciation: 'ROOM', example: 'I\'d like a single room.', exampleArabic: 'أود غرفة فردية.', difficulty: 1 },
      { english: 'Booking', arabic: 'حجز', pronunciation: 'BOOK-ing', example: 'I have a booking for tonight.', exampleArabic: 'لدي حجز لليلة.', difficulty: 1 },
      { english: 'Check-in', arabic: 'تسجيل الوصول', pronunciation: 'CHEK-in', example: 'When is check-in time?', exampleArabic: 'متى وقت تسجيل الوصول؟', difficulty: 1 },
      { english: 'Check-out', arabic: 'تسجيل المغادرة', pronunciation: 'CHEK-owt', example: 'Check-out is at noon.', exampleArabic: 'تسجيل المغادرة في الظهر.', difficulty: 1 },
      { english: 'Key card', arabic: 'بطاقة المفتاح', pronunciation: 'KEE KARD', example: 'Use your key card to enter.', exampleArabic: 'استخدم بطاقتك لفتح الباب.', difficulty: 1 },
      { english: 'Reservation', arabic: 'الحجز', pronunciation: 'rez-er-VAY-shun', example: 'Can I make a reservation?', exampleArabic: 'هل يمكنني الحجز؟', difficulty: 2 },
      { english: 'Lobby', arabic: 'الردهة', pronunciation: 'LOB-ee', example: 'Meet me in the lobby.', exampleArabic: 'القايني في الردهة.', difficulty: 1 },
      { english: 'Elevator', arabic: 'مصعد', pronunciation: 'EL-uh-vay-ter', example: 'The elevator is on your left.', exampleArabic: 'المصعد على يسارك.', difficulty: 1 },
      { english: 'Housekeeping', arabic: 'الخدمة ', pronunciation: 'HOS-kay-ping', example: 'Please call housekeeping for extra towels.@', exampleArabic: 'الرجاء الاتصال بالخدمة للغسيل.', difficulty: 2 },
      { english: 'Concierge', arabic: 'البواب', pronunciation: 'kon-see-AIRZH', example: 'The concierge can help with reservations.', exampleArabic: 'البواب يمكنه المساعدة في الحجز.', difficulty: 2 },
    ],
  },
  {
    category: 'cars-transportation',
    words: [
      { english: 'Car', arabic: 'سيارة', pronunciation: 'KARR', example: 'I need to rent a car.', exampleArabic: 'أحتاج لاستئجار سيارة.', difficulty: 1 },
      { english: 'Drive', arabic: 'يقود', pronunciation: 'DRYV', example: 'Can you drive a manual?', exampleArabic: 'هل تستطيع القيادة بالناقل اليدوي؟', difficulty: 1 },
      { english: 'Gas station', arabic: 'محطة بنزين', pronunciation: 'GAS stay-shun', example: 'We need to stop at a gas station.', exampleArabic: 'نحتاج للتوقف عند محطة بنزين.', difficulty: 1 },
      { english: 'Parking', arabic: 'موقف سيارات', pronunciation: 'PAR-king', example: 'Where is the parking garage?', exampleArabic: 'أين车库؟', difficulty: 1 },
      { english: 'License', arabic: 'رخصة', pronunciation: 'LY-suns', example: 'Do you have a valid driver\'s license?', exampleArabic: 'هل لديك رخصة قيادة سارية؟', difficulty: 1 },
      { english: 'Traffic', arabic: 'مرور', pronunciation: 'TRAF-ik', example: 'The traffic is terrible today.', exampleArabic: 'المرور سيء اليوم.', difficulty: 1 },
      { english: 'Accident', arabic: 'حادث', pronunciation: 'AK-suh-dent', example: 'There was a car accident on the highway.', exampleArabic: 'كان هناك حادث سيارة على الطريق السريع.', difficulty: 2 },
      { english: 'Ticket', arabic: 'تذكرة', pronunciation: 'TIK-it', example: 'I got a parking ticket.', exampleArabic: 'حصلت على تذكرة موقف.', difficulty: 1 },
      { english: 'Bus', arabic: 'حافلة', pronunciation: 'BUS', example: 'Take the bus to downtown.', exampleArabic: 'خذ الحافلة إلى وسط المدينة.', difficulty: 1 },
      { english: 'Train', arabic: 'قطار', pronunciation: 'TRAYN', example: 'The train arrives at platform 3.', exampleArabic: 'القطار يصل إلى الرصيف 3.', difficulty: 1 },
    ],
  },
  {
    category: 'school-education',
    words: [
      { english: 'Teacher', arabic: 'معلم', pronunciation: 'TEE-cher', example: 'My teacher is very kind.', exampleArabic: 'معلمي لطيف جداً.', difficulty: 1 },
      { english: 'Student', arabic: 'طالب', pronunciation: 'STOO-dent', example: 'I am a student at this university.', exampleArabic: 'أنا طالب في هذه الجامعة.', difficulty: 1 },
      { english: 'Subject', arabic: 'مادة', pronunciation: 'SUB-jekt', example: 'What is your favorite subject?', exampleArabic: 'ما هي مادتك المفضلة؟', difficulty: 1 },
      { english: 'Homework', arabic: 'واجب', pronunciation: 'HOHM-wurk', example: 'I have too much homework tonight.', exampleArabic: 'لدي واجب كثير الليلة.', difficulty: 1 },
      { english: 'Exam', arabic: 'امتحان', pronunciation: 'ig-ZAM', example: 'The exam is next week.', exampleArabic: 'الامتحان الأسبوع القادم.', difficulty: 1 },
      { english: 'Grade', arabic: 'درجة', pronunciation: 'GRAYD', example: 'I got a good grade on my test.', exampleArabic: 'حصلت على درجة جيدة في اختباري.', difficulty: 1 },
      { english: 'Lesson', arabic: 'درس', pronunciation: 'LES-un', example: 'Let\'s continue the lesson.', exampleArabic: 'هيا نكمل الدرس.', difficulty: 1 },
      { english: 'Class', arabic: 'صف', pronunciation: 'KLAS', example: 'We have class at 9 AM.', exampleArabic: 'لدينا صف الساعة 9 صباحاً.', difficulty: 1 },
      { english: 'Book', arabic: 'كتاب', pronunciation: 'BOOK', example: 'Open your books to page 50.', exampleArabic: 'افتحوا كتبكم في صفحة 50.', difficulty: 1 },
      { english: 'Pencil', arabic: 'قلم رصاص', pronunciation: 'PEN-sul', example: 'Do you have a pencil I can borrow?', exampleArabic: 'هل لديك قلم رصاص أستعيره؟', difficulty: 1 },
    ],
  },
  {
    category: 'business-english',
    words: [
      { english: 'Meeting', arabic: 'اجتماع', pronunciation: 'MEE-ting', example: 'The meeting starts at 10 AM.', exampleArabic: 'الاجتماع يبدأ الساعة 10 صباحاً.', difficulty: 1 },
      { english: 'Email', arabic: 'بريد إلكتروني', pronunciation: 'EE-mayl', example: 'Please send me the report via email.', exampleArabic: 'الرجاء إرسال التقرير عبر البريد الإلكترونى.', difficulty: 1 },
      { english: 'Deadline', arabic: 'موعد نهائي', pronunciation: 'DED-lyn', example: 'The deadline is Friday.', exampleArabic: 'الموعد النهائي هو الجمعة.', difficulty: 2 },
      { english: 'Project', arabic: 'مشروع', pronunciation: 'PROJ-ekt', example: 'We need to finish this project by Monday.', exampleArabic: 'نحتاج لإنهاء هذا المشروع بحلول الاثنين.', difficulty: 1 },
      { english: 'Presentation', arabic: 'عرض', pronunciation: 'prez-en-TAY-shun', example: 'Your presentation was excellent.', exampleArabic: 'عرضك كان ممتازاً.', difficulty: 2 },
      { english: 'Boss', arabic: 'مدير', pronunciation: 'BOS', example: 'My boss is very demanding.', exampleArabic: 'مديري demanding جداً.', difficulty: 1 },
      { english: 'Colleague', arabic: 'زميل', pronunciation: 'KOL-eeg', example: 'She is my colleague from marketing.', exampleArabic: 'هي زميلتي من التسويق.', difficulty: 2 },
      { english: 'Salary', arabic: 'راتب', pronunciation: 'SAL-uh-ree', example: 'When do I get my salary?', exampleArabic: 'متى أحصل على راتبي؟', difficulty: 2 },
      { english: 'Office', arabic: 'مكتب', pronunciation: 'OF-is', example: 'I work in the downtown office.', exampleArabic: 'أعمل في مكتب وسط المدينة.', difficulty: 1 },
      { english: 'Computer', arabic: 'حاسوب', pronunciation: 'kum-PYOO-ter', example: 'My computer crashed during the meeting.', exampleArabic: 'حصوبي تعطل أثناء الاجتماع.', difficulty: 1 },
    ],
  },
  {
    category: 'family-friends',
    words: [
      { english: 'Mother', arabic: 'أم', pronunciation: 'MUTH-er', example: 'My mother is a doctor.', exampleArabic: 'أمي طبيبة.', difficulty: 1 },
      { english: 'Father', arabic: 'أب', pronunciation: 'FAH-ther', example: 'My father works as an engineer.', exampleArabic: 'أبي يعمل كمهندس.', difficulty: 1 },
      { english: 'Sister', arabic: 'أخت', pronunciation: 'SIS-ter', example: 'My sister lives in Dubai.', exampleArabic: 'أختي تعيش في دبي.', difficulty: 1 },
      { english: 'Brother', arabic: 'أخ', pronunciation: 'BRUTH-er', example: 'My brother is a university student.', exampleArabic: 'أخي طالب جامعي.', difficulty: 1 },
      { english: 'Friend', arabic: 'صديق', pronunciation: 'FREND', example: 'She is my best friend.', exampleArabic: 'هي صديقتي المفضلة.', difficulty: 1 },
      { english: 'Family', arabic: 'عائلة', pronunciation: 'FAM-uh-lee', example: 'I love my family.', exampleArabic: 'أحب عائلتي.', difficulty: 1 },
      { english: 'Grandmother', arabic: 'جدة', pronunciation: 'GRAND-muth-er', example: 'My grandmother cooks the best food.', exampleArabic: 'جدتي تطبخ أفضل طعام.', difficulty: 1 },
      { english: 'Grandfather', arabic: 'جد', pronunciation: 'GRAND-fah-ther', example: 'My grandfather tells great stories.', exampleArabic: 'جدي يحكي قصصاً رائعة.', difficulty: 1 },
      { english: 'Cousin', arabic: 'ابن عم', pronunciation: 'KUZ-un', example: 'My cousin is coming to visit.', exampleArabic: 'ابن عمي سيزورنا.', difficulty: 1 },
      { english: 'Uncle', arabic: 'عم', pronunciation: 'UNG-kul', example: 'My uncle lives next door.', exampleArabic: 'عمّي يسكن بجانبنا.', difficulty: 1 },
    ],
  },
  {
    category: 'jobs-work',
    words: [
      { english: 'Job', arabic: 'وظيفة', pronunciation: 'JOB', example: 'I\'m looking for a new job.', exampleArabic: 'أبحث عن وظيفة جديدة.', difficulty: 1 },
      { english: 'Work', arabic: 'عمل', pronunciation: 'WURK', example: 'I work at a hospital.', exampleArabic: 'أعمل في مستشفى.', difficulty: 1 },
      { english: 'Employee', arabic: 'موظف', pronunciation: 'im-PLOY-ee', example: 'The company has 500 employees.', exampleArabic: 'الشركة لديها 500 موظف.', difficulty: 2 },
      { english: 'Employer', arabic: 'صاحب عمل', pronunciation: 'im-PLOY-er', example: 'Your employer needs to sign this form.', exampleArabic: 'صاحب عملك يحتاج لتوقيع هذا النموذج.', difficulty: 2 },
      { english: 'Resume', arabic: 'سيرة ذاتية', pronunciation: 'REZ-uh-may', example: 'Please send me your resume.', exampleArabic: 'الرجاء إرسال سيرتك الذاتية.', difficulty: 2 },
      { english: 'Interview', arabic: 'مقابلة', pronunciation: 'IN-ter-vyoo', example: 'Good luck on your interview tomorrow!', exampleArabic: 'حظاً موفقاً في مقابلك غداً!', difficulty: 2 },
      { english: 'Career', arabic: 'مسيرة مهنية', pronunciation: 'kuh-REER', example: 'She has a successful career in finance.', exampleArabic: 'لديها مسيرة مهنية ناجحة في المالية.', difficulty: 2 },
      { english: 'Promotion', arabic: 'ترقية', pronunciation: 'pruh-MOH-shun', example: 'I got a promotion at work!', exampleArabic: 'حصلت على ترقية في العمل!', difficulty: 2 },
      { english: 'Retire', arabic: 'يتقاعد', pronunciation: 'ri-TYR', example: 'My father will retire next year.', exampleArabic: 'أبي سيتقاعد العام القادم.', difficulty: 3 },
      { english: 'Salary', arabic: 'راتب', pronunciation: 'SAL-uh-ree', example: 'The salary is competitive.', exampleArabic: 'الراتب تنافسي.', difficulty: 2 },
    ],
  },
  {
    category: 'numbers-counting',
    words: [
      { english: 'One', arabic: 'واحد', pronunciation: 'WUN', example: 'I have one brother.', exampleArabic: 'لدي أخ واحد.', difficulty: 1 },
      { english: 'Two', arabic: 'اثنان', pronunciation: 'TOO', example: 'There are two cats in the garden.', exampleArabic: 'هناك قطتان في الحديقة.', difficulty: 1 },
      { english: 'Three', arabic: 'ثلاثة', pronunciation: 'THREE', example: 'I need three copies of this.', exampleArabic: 'أحتاج ثلاث نسخ من هذا.', difficulty: 1 },
      { english: 'Four', arabic: 'أربعة', pronunciation: 'FOR', example: 'The book has four chapters.', exampleArabic: 'الكتاب أربعة فصول.', difficulty: 1 },
      { english: 'Five', arabic: 'خمسة', pronunciation: 'FYV', example: 'I want five minutes on the phone.', exampleArabic: 'أريد خمس دقائق في التليفون.', difficulty: 1 },
      { english: 'Ten', arabic: 'عشرة', pronunciation: 'TEN', example: 'I\'ll be there in ten minutes.', exampleArabic: 'سأكون هناك خلال عشر دقائق.', difficulty: 1 },
      { english: 'Twenty', arabic: 'عشرون', pronunciation: 'TWEN-tee', example: 'There are twenty students in class.', exampleArabic: 'هناك عشرون طالباً في الصف.', difficulty: 1 },
      { english: 'Hundred', arabic: 'مئة', pronunciation: 'HUN-dred', example: 'A hundred people attended.', exampleArabic: 'مئة شخص حضر.', difficulty: 1 },
      { english: 'Thousand', arabic: 'ألف', pronunciation: 'THOW-zund', example: 'The city has a thousand years of history.', exampleArabic: 'المدينة لها ألف سنة من التاريخ.', difficulty: 1 },
      { english: 'Million', arabic: 'مليون', pronunciation: 'MIL-yun', example: 'The company is worth millions.', exampleArabic: 'الشركة価値 ملايين.', difficulty: 2 },
    ],
  },
  {
    category: 'time-dates',
    words: [
      { english: 'Today', arabic: 'اليوم', pronunciation: 'tuh-DAY', example: 'Today is Monday.', exampleArabic: 'اليوم هو الاثنين.', difficulty: 1 },
      { english: 'Tomorrow', arabic: 'غداً', pronunciation: 'tuh-MOR-oh', example: 'See you tomorrow!', exampleArabic: 'نراك غداً!', difficulty: 1 },
      { english: 'Yesterday', arabic: 'أمس', pronunciation: 'YES-ter-day', example: 'Yesterday was my birthday.', exampleArabic: 'أمس كان عيد ميلادي.', difficulty: 1 },
      { english: 'Week', arabic: 'أسبوع', pronunciation: 'WEEK', example: 'I\'ll be busy all week.', exampleArabic: 'سأكون مشغولاً طوال الأسبوع.', difficulty: 1 },
      { english: 'Month', arabic: 'شهر', pronunciation: 'MUNTH', example: 'This month has 31 days.', exampleArabic: 'هذا الشهر فيه 31 يوماً.', difficulty: 1 },
      { english: 'Year', arabic: 'سنة', pronunciation: 'YEER', example: 'Happy New Year!', exampleArabic: 'سنة جديدة سعيدة!', difficulty: 1 },
      { english: 'Morning', arabic: 'صباح', pronunciation: 'MOR-ning', example: 'Good morning!', exampleArabic: 'صباح الخير!', difficulty: 1 },
      { english: 'Afternoon', arabic: 'بعد الظهر', pronunciation: 'AF-ter-noon', example: 'See you in the afternoon.', exampleArabic: 'نراك في afternoon.', difficulty: 1 },
      { english: 'Evening', arabic: 'مساء', pronunciation: 'EEV-ning', example: 'Good evening, everyone!', exampleArabic: 'مساء الخير يا جميعاً!', difficulty: 1 },
      { english: 'Night', arabic: 'ليل', pronunciation: 'NYT', example: 'Good night, sleep well!', exampleArabic: 'تصبح على خير، نمBien!', difficulty: 1 },
    ],
  },
  {
    category: 'weather',
    words: [
      { english: 'Sunny', arabic: 'مشمس', pronunciation: 'SUN-ee', example: 'It\'s a sunny day today.', exampleArabic: 'اليوم يوم مشمس.', difficulty: 1 },
      { english: 'Rainy', arabic: 'ماطر', pronunciation: 'RAY-nee', example: 'Bring an umbrella, it\'s rainy.', exampleArabic: 'أحضر مظلة، الطقس ماطر.', difficulty: 1 },
      { english: 'Cloudy', arabic: 'غائم', pronunciation: 'KLOW-dee', example: 'The sky is cloudy today.', exampleArabic: 'السماء غائمة اليوم.', difficulty: 1 },
      { english: 'Snowy', arabic: 'ثلجي', pronunciation: 'SNOH-ee', example: 'It\'s snowy in the mountains.', exampleArabic: 'الطقس ثلجي في الجبال.', difficulty: 1 },
      { english: 'Windy', arabic: 'عاصف', pronunciation: 'WIN-dee', example: 'It\'s very windy today.', exampleArabic: 'الطقس عاصف جداً اليوم.', difficulty: 1 },
      { english: 'Hot', arabic: 'حار', pronunciation: 'HOT', example: 'The desert is very hot.', exampleArabic: 'الصحراء حارة جداً.', difficulty: 1 },
      { english: 'Cold', arabic: 'بارد', pronunciation: 'KOLD', example: 'It\'s cold outside, wear a jacket.', exampleArabic: 'الطقس بارد بالخارج، البس سترة.', difficulty: 1 },
      { english: 'Warm', arabic: 'دافئ', pronunciation: 'WORM', example: 'The weather is warm and pleasant.', exampleArabic: 'الطقس دافئ ومريح.', difficulty: 1 },
      { english: 'Cool', arabic: 'معتدل', pronunciation: 'KOOL', example: 'The evenings are cool.', exampleArabic: 'الأمسيات معتدلة.', difficulty: 1 },
      { english: 'Humid', arabic: 'رطب', pronunciation: 'HYOO-mid', example: 'It\'s very humid in summer.', exampleArabic: 'الطقس رطب جداً صيفاً.', difficulty: 2 },
    ],
  },
  {
    category: 'emergency-phrases',
    words: [
      { english: 'Help!', arabic: 'النجدة!', pronunciation: 'HELP', example: 'Help! I need assistance!', exampleArabic: 'النجدة! أحتاج مساعدة!', difficulty: 1 },
      { english: 'Emergency', arabic: 'طوارئ', pronunciation: 'i-MER-jun-see', example: 'Call emergency services!', exampleArabic: 'اتصل بخدمات الطوارئ!', difficulty: 2 },
      { english: 'Hospital', arabic: 'مستشفى', pronunciation: 'HOS-pi-tul', example: 'Take me to the hospital!', exampleArabic: 'خُذني إلى المستشفى!', difficulty: 1 },
      { english: 'Police', arabic: 'شرطة', pronunciation: 'puh-LEES', example: 'I need to call the police.', exampleArabic: 'أحتاج الاتصال بالشرطة.', difficulty: 1 },
      { english: 'Fire', arabic: 'حريق', pronunciation: 'FYR', example: 'There\'s a fire in the building!', exampleArabic: 'هناك حريق في المبنى!', difficulty: 1 },
      { english: 'Ambulance', arabic: 'سيارة إسعاف', pronunciation: 'AM-byoo-luns', example: 'Call an ambulance immediately!', exampleArabic: 'اتصل بسيارة إسعاف فوراً!', difficulty: 2 },
      { english: 'Lost', arabic: 'ضائع', pronunciation: 'LOST', example: 'I\'m lost, can you help me?', exampleArabic: 'أنا ضائع، هل يمكنك مساعدتي؟', difficulty: 1 },
      { english: 'Stolen', arabic: 'مسروق', pronunciation: 'STOH-lun', example: 'My wallet was stolen!', exampleArabic: 'محفظي مسروقة!', difficulty: 2 },
      { english: 'Allergic', arabic: 'حساسية', pronunciation: 'uh-LER-jik', example: 'I\'m allergic to this medicine.', exampleArabic: 'لدي حساسية من هذا الدواء.', difficulty: 2 },
      { english: 'Fainted', arabic: 'إغماء', pronunciation: 'FAYN-tid', example: 'She fainted from the heat.', exampleArabic: 'هي أُغمي عليها من الحر.', difficulty: 2 },
    ],
  },
];

// Generate words from the additional categories
additionalCategories.forEach(({ category, words }) => {
  words.forEach(({ english, arabic, pronunciation, example, exampleArabic, difficulty }) => {
    bulkGeneratedWords.push(generateWord(english, arabic, pronunciation, example, exampleArabic, category, difficulty));
  });
});

// Push all bulk words
bulkGeneratedWords.forEach(word => vocabulary.push(word));

console.log(`Total vocabulary words: ${vocabulary.length}`);

// Export functions for data access
export const getWordsByCategory = (categoryId: string): Word[] =>
  vocabulary.filter(w => w.category === categoryId);

export const getWordById = (id: string): Word | undefined =>
  vocabulary.find(w => w.id === id);

export const searchWords = (query: string): Word[] => {
  const lowerQuery = query.toLowerCase();
  return vocabulary.filter(w =>
    w.english.toLowerCase().includes(lowerQuery) ||
    w.arabic.includes(query) ||
    w.pronunciation.toLowerCase().includes(lowerQuery)
  );
};

export const getRandomWord = (): Word => {
  return vocabulary[Math.floor(Math.random() * vocabulary.length)];
};

export const getRandomWords = (count: number): Word[] => {
  const shuffled = [...vocabulary].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};

// Conversations data
export const conversations: Conversation[] = [
  {
    id: 'restaurant-ordering',
    title: 'Ordering Food in Restaurant',
    titleArabic: 'طلب الطعام في المطعم',
    category: 'restaurant',
    lines: [
      { id: 1, speaker: 'person1', english: 'Good evening. Table for two, please.', arabic: 'مساء الخير. طاولة لشخصين من فضلك.' },
      { id: 2, speaker: 'person2', english: 'Good evening! Do you have a reservation?', arabic: 'مساء الخير! هل لديكم حجز؟' },
      { id: 3, speaker: 'person1', english: 'Yes, under the name Ahmed.', arabic: 'نعم، باسم أحمد.' },
      { id: 4, speaker: 'person2', english: 'Yes, of course. Right this way, please.', arabic: 'نعم، بالطبع. تفضلوا من هنا من فضلك.' },
      { id: 5, speaker: 'person1', english: 'Thank you. Can I see the menu, please?', arabic: 'شكراً. هل يمكنني رؤية قائمة الطعام من فضلك؟' },
      { id: 6, speaker: 'person2', english: 'Here you are. Would you like something to drink first?', arabic: 'تفضلوا. هل تحبون شيئاً تشربونه أولاً؟' },
      { id: 7, speaker: 'person1', english: 'Yes, two glasses of water please, and one mineral water.', arabic: 'نعم، كأسين من الماء من فضلك، وماء معدني واحد.' },
      { id: 8, speaker: 'person2', english: 'Of course. I\'ll give you a few minutes to look at the menu.', arabic: 'بالطبع. سأعطيكم بضع دقائق لتروا القائمة.' },
      { id: 9, speaker: 'person1', english: 'We\'re ready to order. I\'ll have the grilled fish, and she\'ll have the chicken salad.', arabic: 'نحن جاهزون للطلب. سآخذ السمك المشوي، وهي ستأخذ سلطة الدجاج.' },
      { id: 10, speaker: 'person2', english: 'Excellent choices! Would you like any appetizers?', arabic: 'اختيارات ممتازة! هل تحبون أي المقبلات؟' },
      { id: 11, speaker: 'person1', english: 'Yes, one soup of the day for sharing.', arabic: 'نعم، حساء اليوم واحد للاشتراك.' },
      { id: 12, speaker: 'person2', english: 'Perfect! I\'ll be back with your appetizers and drinks.', arabic: 'ممتاز! سأعود مع مقبلاتكم ومشروباتكم.' },
    ],
  },
  {
    id: 'airport-checkin',
    title: 'Airport Check-in',
    titleArabic: 'تسجيل الوصول في المطار',
    category: 'travel-airports',
    lines: [
      { id: 1, speaker: 'person1', english: 'Good morning, I\'d like to check in for the flight to London, please.', arabic: 'صباح الخير، أود تسجيل الوصول لرحلة لندن من فضلك.' },
      { id: 2, speaker: 'person2', english: 'Good morning! May I see your passport and booking confirmation?', arabic: 'صباح الخير! هل يمكنني رؤية جواز سفرك وتأكيد الحجز؟' },
      { id: 3, speaker: 'person1', english: 'Here you are. Can I have a window seat?', arabic: 'تفضل. هل يمكنني مقعداً بجانب النافذة؟' },
      { id: 4, speaker: 'person2', english: 'Let me check... Yes, I can arrange that. Do you have any luggage to check in?', arabic: 'دعني أتحقق... نعم، يمكنني ترتيب ذلك. هل لديك أي أمتعة لتسجيلها؟' },
      { id: 5, speaker: 'person1', english: 'Yes, one suitcase. Is it within the weight limit?', arabic: 'نعم، حقيبة واحدة. هل هي ضمن حد الوزن؟' },
      { id: 6, speaker: 'person2', english: 'It\'s 22 kilograms, which is fine. Your boarding pass, sir.', arabic: 'إنها 22 كيلوغراماً، وهو جيد. بطاقة صعودك يا سيدي.' },
      { id: 7, speaker: 'person1', english: 'Thank you. What gate does the flight depart from?', arabic: 'شكراً. من أي بوابة تغادر الرحلة؟' },
      { id: 8, speaker: 'person2', english: 'Gate 15, boarding at 10:30. Have a pleasant flight!', arabic: 'البوابة 15، الصعود الساعة 10:30. رحلة سعيدة!' },
    ],
  },
  {
    id: 'hotel-booking',
    title: 'Hotel Booking',
    titleArabic: 'حجز فندق',
    category: 'hotels-booking',
    lines: [
      { id: 1, speaker: 'person1', english: 'Hello, I\'d like to make a reservation for two nights.', arabic: 'مرحباً، أود حجز لليلتين.' },
      { id: 2, speaker: 'person2', english: 'Hello! What dates will you be staying with us?', arabic: 'مرحباً! ما هي تواريخ إقامتك عندنا؟' },
      { id: 3, speaker: 'person1', english: 'From the 15th to the 17th of March.', arabic: 'من 15 إلى 17 مارس.' },
      { id: 4, speaker: 'person2', english: 'And how many guests will be staying?', arabic: 'وكم عدد الضيوف الذين سيقيمون؟' },
      { id: 5, speaker: 'person1', english: 'Two adults. Do you have any rooms available?', arabic: 'بالغان اثنان. هل لديكم غرف متاحة؟' },
      { id: 6, speaker: 'person2', english: 'Yes, we have a double room with a city view. Would that suit you?', arabic: 'نعم، لدينا غرفة مزدوجة بإطلالة على المدينة. هل تناسبك؟' },
      { id: 7, speaker: 'person1', english: 'That sounds perfect. What\'s the price per night?', arabic: 'يبدو ذلك مثالياً. ما هو السعر لكل ليلة؟' },
      { id: 8, speaker: 'person2', english: 'It\'s $150 per night, including breakfast.', arabic: 'إنها 150 دولار لكل ليلة، متضمناً الفطور.' },
      { id: 9, speaker: 'person1', english: 'Great! I\'ll take it. Can you confirm my booking?', arabic: 'رائع! سآخذها. هل يمكنك تأكيد حزوري؟' },
      { id: 10, speaker: 'person2', english: 'Of course! May I have your name and credit card to guarantee the booking?', arabic: 'بالطبع! هل يمكنني اسمك وبطاقة الائتمان لتأكيد الحجز؟' },
    ],
  },
  {
    id: 'directions',
    title: 'Asking for Directions',
    titleArabic: 'سؤال عن الطريق',
    category: 'travel-airports',
    lines: [
      { id: 1, speaker: 'person1', english: 'Excuse me, could you help me? I\'m looking for the museum.', arabic: 'عفواً، هل يمكنك مساعدتي؟ أبحث عن المتحف.' },
      { id: 2, speaker: 'person2', english: 'Of course! It\'s not far from here. Go straight for two blocks, then turn left.', arabic: 'بالطبع! ليس بعيداً من هنا. اذهب مستقيماً لب مربعين، ثم انعطف يساراً.' },
      { id: 3, speaker: 'person1', english: 'Straight for two blocks, then left. Got it. How long will it take to walk there?', arabic: 'مستقيماً لب Quadrant، ثم يساراً. فهمتها. كم سيستغرق للوصول سيراً؟' },
      { id: 4, speaker: 'person2', english: 'About ten minutes. You\'ll see it on your right, next to the park.', arabic: 'حوالي عشر دقائق. ستراه على يمينك، بجانب الحديقة.' },
      { id: 5, speaker: 'person1', english: 'Thank you so much! Is there a metro station nearby?', arabic: 'شكراً جزيلاً! هل هناك محطة مترو قريباً؟' },
      { id: 6, speaker: 'person2', english: 'Yes, the central station is just around the corner from the museum.', arabic: 'نعم، المحطة المركزية هي مجرد في زاوية المتحف.' },
      { id: 7, speaker: 'person1', english: 'Perfect! Thank you for your help.', arabic: 'مثالي! شكراً على مساعدتك.' },
      { id: 8, speaker: 'person2', english: 'You\'re welcome. Enjoy your visit to the museum!', arabic: 'العفو. استمتع بزيارتك للمتحف!' },
    ],
  },
  {
    id: 'work-meeting',
    title: 'Work Meeting',
    titleArabic: 'اجتماع عمل',
    category: 'business-english',
    lines: [
      { id: 1, speaker: 'person2', english: 'Good morning everyone. Let\'s start the meeting. First on the agenda is the quarterly report.', arabic: 'صباح الخير يا جميعاً. لنبدأ الاجتماع. أولاً في جدول الأعمال هو التقرير الربعي.' },
      { id: 2, speaker: 'person1', english: 'Thank you, Sarah. I\'d like to share some positive news. Our sales increased by 15% this quarter.', arabic: 'شكراً يا سارة. أود أن أشارك بعض الأخبار الإيجابية. مبيعاتنا زادت 15% هذا الربع.' },
      { id: 3, speaker: 'person2', english: 'That\'s excellent! What do you attribute this success to?', arabic: 'هذا ممتاز! إلى ماذا تُرجع هذا النجاح؟' },
      { id: 4, speaker: 'person1', english: 'Mainly our new marketing campaign and improved customer service. Also, we expanded into two new markets.', arabic: 'أساساً حملتنا التسويقية الجديدة وتحسين خدمة العملاء. أيضاً،وسعنا إلى سوقين جديدين.' },
      { id: 5, speaker: 'person2', english: 'Great work! What are our challenges for next quarter?', arabic: 'عمل رائع! ما هي تحدياتنا للربع القادم؟' },
      { id: 6, speaker: 'person1', english: 'We need to focus on reducing costs and improving production efficiency. I suggest we discuss this in detail.', arabic: 'نحتاج للتركيز على تقليل التكاليف وتحسين كفاءة الإنتاج. أقترح أن نناقش هذا بالتفصيل.' },
      { id: 7, speaker: 'person2', english: 'Excellent suggestion. Let\'s move to that topic. What resources do you need to achieve these goals?', arabic: 'اقتراح ممتاز. هيا ننتقل إلى ذلك الموضوع. ما هي الموارد التي تحتاجها لتحقيق هذه الأهداف؟' },
      { id: 8, speaker: 'person1', english: 'We need additional budget for equipment and two more staff members. I\'ll send you a detailed proposal by email.', arabic: 'نحتاج ميزانية إضافية للتجهيزات وعضوين إضافيين في الفريق. سأرسل لك اقتراحاً مفصلاً عبر البريد الإلكترونى.' },
      { id: 9, speaker: 'person2', english: 'Sounds good. Let\'s review the proposal before the next meeting. Does anyone else have anything to add?', arabic: 'جيد. هيا نراجع الاقتراح قبل الاجتماع القادم. هل لدى أي شخص شيء آخر يضيفه؟' },
      { id: 10, speaker: 'person1', english: 'I think we covered everything. Thank you all for your contributions.', arabic: 'أعتقد أننا غطينا كل شيء. شكراً لكم جميعاً على مساهماتكم.' },
    ],
  },
];

export const getConversationById = (id: string): Conversation | undefined =>
  conversations.find(c => c.id === id);

// Grammar lessons
export const grammarLessons: GrammarLesson[] = [
  {
    id: 'present-simple',
    title: 'Present Simple Tense',
    titleArabic: 'زمن المضارع البسيط',
    level: 'beginner',
    content: 'We use the Present Simple tense to describe habits, general truths, and regular actions.',
    contentArabic: 'نستخدم زمن المضارع البسيط لوصف العادات والحقائق العامة والإجراءات المنتظمة.',
    examples: [
      { english: 'I play football every weekend.', arabic: 'ألعب كرة القدم كل يوم جمعة.', explanation: 'Subject + base verb for I/You/We/They', explanationArabic: 'فاعل + فعل في حالة المصدر' },
      { english: 'She works at a hospital.', arabic: 'هي تعمل في مستشفى.', explanation: 'Subject + verb + s/es for He/She/It', explanationArabic: 'فاعل + فعل + s/es للمتكلم الغائب' },
      { english: 'They live in Cairo.', arabic: 'هم يعيشون في القاهرة.', explanation: 'No change for plural subjects', explanationArabic: 'لا تغيير للفاعلين الجمع' },
    ],
    exercises: [
      { id: 'ps1', type: 'multiple-choice', question: 'Complete: He ____ English every day.', questionArabic: 'أكمل: هو ____ الإنجليزية كل يوم.', options: ['learn', 'learns', 'learning', 'learned'], correctAnswer: 1 },
      { id: 'ps2', type: 'fill-blank', question: 'I ____ (be) a student.', questionArabic: 'أنا ____ طالب.', correctAnswer: 'am' },
      { id: 'ps3', type: 'multiple-choice', question: 'We ____ to school by bus.', questionArabic: 'نحن نذهب إلى المدرسة بالحافلة.', options: ['go', 'goes', 'going', 'went'], correctAnswer: 0 },
    ],
  },
  {
    id: 'past-simple',
    title: 'Past Simple Tense',
    titleArabic: 'زمن الماضي البسيط',
    level: 'beginner',
    content: 'We use the Past Simple tense to describe completed actions in the past.',
    contentArabic: 'نستخدم زمن الماضي البسيط لوصف إجراءات مكتملة في الماضي.',
    examples: [
      { english: 'I visited Paris last summer.', arabic: 'زرت باريس الصيف الماضي.', explanation: 'Regular verbs: add -ed', explanationArabic: 'الأفعال المنتظمة: أضف -ed' },
      { english: 'She ate breakfast at 8 AM.', arabic: 'هي تناولت الفطور الساعة 8 صباحاً.', explanation: 'Irregular verbs: different form', explanationArabic: 'الأفعال الشاذة: форму مختلفة' },
      { english: 'They played football yesterday.', arabic: 'هم لعبوا كرة القدم أمس.', explanation: 'Regular verbs: add -ed', explanationArabic: 'الأفعال المنتظمة: أضف -ed' },
    ],
    exercises: [
      { id: 'pas1', type: 'multiple-choice', question: 'Yesterday, I ____ to the market.', questionArabic: 'أمس، أنا ____ إلى السوق.', options: ['go', 'went', 'going', 'goes'], correctAnswer: 1 },
      { id: 'pas2', type: 'fill-blank', question: 'She ____ (see) a beautiful rainbow yesterday.', questionArabic: 'هي ____ قوس قزح جميل أمس.', correctAnswer: 'saw' },
      { id: 'pas3', type: 'multiple-choice', question: 'We ____ our homework last night.', questionArabic: 'نحن أنجزنا واجباتنا الليلة الماضية.', options: ['finish', 'finished', 'finishing', 'finishes'], correctAnswer: 1 },
    ],
  },
  {
    id: 'future-will',
    title: 'Future Tense (Will)',
    titleArabic: 'زمن المستقبل (Will)',
    level: 'beginner',
    content: 'We use "will" for spontaneous decisions, predictions, and promises about the future.',
    contentArabic: 'نستخدم "will" للقرارات العفوية والتوقعات والتعهدات حول المستقبل.',
    examples: [
      { english: 'I will help you with your homework.', arabic: 'سأساعدك في واجباتك.', explanation: 'Will + base verb', explanationArabic: 'Will + الفعل في حالة المصدر' },
      { english: 'It will rain tomorrow, I think.', arabic: 'سيمطر غداً، أظن.', explanation: 'Prediction with thinking', explanationArabic: 'توقع مع التفكير' },
      { english: 'She will call you later.', arabic: 'هي ستتصل بي لاحقاً.', explanation: 'Future fact', explanationArabic: 'حقيقة مستقبلية' },
    ],
    exercises: [
      { id: 'fut1', type: 'multiple-choice', question: 'I think it ____ rain tomorrow.', questionArabic: 'أظن أنها ____ مطر غداً.', options: ['will', 'wll', 'walt', 'wil'], correctAnswer: 0 },
      { id: 'fut2', type: 'fill-blank', question: 'We ____ (visit) our grandmother next week.', questionArabic: 'نحن ____ (نزور) جدتنا الأسبوع القادم.', correctAnswer: 'will visit' },
      { id: 'fut3', type: 'multiple-choice', question: 'Don\'t worry, I ____ help you.', questionArabic: 'لا تقلق، أنا ____ أساعدك.', options: ['wil', 'wll', 'will', 'whil'], correctAnswer: 2 },
    ],
  },
  {
    id: 'present-continuous',
    title: 'Present Continuous Tense',
    titleArabic: 'زمن المضارع المستمر',
    level: 'beginner',
    content: 'We use the Present Continuous for actions happening right now or around this time.',
    contentArabic: 'نستخدم المضارع المستمر للإجراءات التي تحدث الآن أو حول هذا الوقت.',
    examples: [
      { english: 'I am studying English right now.', arabic: 'أنا أدرس الإنجليزية الآن.', explanation: 'am/are/is + verb-ing', explanationArabic: 'am/are/is + الفعل + ing' },
      { english: 'They are watching a movie at the cinema.', arabic: 'هم يشاهدون فيلماً في السينما.', explanation: 'Action in progress', explanationArabic: 'إجراء قائم' },
      { english: 'She is cooking dinner for the family.', arabic: 'هي تطبخ العشاء للعائلة.', explanation: 'Temporary situation', explanationArabic: 'موقف مؤقت' },
    ],
    exercises: [
      { id: 'pc1', type: 'multiple-choice', question: 'Look! The baby ____.', questionArabic: 'انظر! الطفل ____!', options: ['cry', 'crying', 'is crying', 'cried'], correctAnswer: 2 },
      { id: 'pc2', type: 'fill-blank', question: 'Right now, I ____ (read) an interesting book.', questionArabic: 'الآن، أنا ____ (أقرأ) كتاباً مثيراً للاهتمام.', correctAnswer: 'am reading' },
      { id: 'pc3', type: 'multiple-choice', question: 'We ____ (play) football at the moment.', questionArabic: 'نحن ____ (نلعب) كرة القدم في الوقت الحالي.', options: ['play', 'played', 'are playing', 'is playing'], correctAnswer: 2 },
    ],
  },
  {
    id: 'present-perfect',
    title: 'Present Perfect Tense',
    titleArabic: 'زمن المضارع التام',
    level: 'intermediate',
    content: 'We use the Present Perfect for actions that happened at an unstated time before now.',
    contentArabic: 'نستخدم المضارع التام للإجراءات التي حدثت في وقت غير محدد قبل الآن.',
    examples: [
      { english: 'I have visited London twice.', arabic: 'زرت لندن مرتين.', explanation: 'Experience with result', explanationArabic: 'خبرة مع نتيجة' },
      { english: 'She has lost her keys.', arabic: 'هي فقدت مفاتيحها.', explanation: 'Result relevant now', explanationArabic: 'نتيجة ذات صلة الآن' },
      { english: 'They have lived here since 2010.', arabic: 'هم عاشوا هنا منذ 2010.', explanation: 'Duration with since/for', explanationArabic: 'مدة مع منذ/لأجل' },
    ],
    exercises: [
      { id: 'pp1', type: 'multiple-choice', question: 'I ____ (never/be) to Japan.', questionArabic: 'أنا ____ (أبداً/لأكن) إلى اليابان.', options: ['have never been', 'has never been', 'never am', 'never was'], correctAnswer: 0 },
      { id: 'pp2', type: 'fill-blank', question: 'She ____ (finish) her homework already.', questionArabic: 'هي ____ (تنعجز) واجباتها بالفعل.', correctAnswer: 'has finished' },
      { id: 'pp3', type: 'multiple-choice', question: 'We ____ (know) each other for ten years.', questionArabic: 'نحن ____ (نعرف) بعضنا منذ عشر سنوات.', options: ['know', 'are knowing', 'have known', 'knew'], correctAnswer: 2 },
    ],
  },
];

export const getGrammarLessonsByLevel = (level: GrammarLesson['level']): GrammarLesson[] =>
  grammarLessons.filter(l => l.level === level);

// Achievements
export const achievements: Achievement[] = [
  { id: 'first-word', name: 'First Word', nameArabic: 'الكلمة الأولى', description: 'Learn your first word', descriptionArabic: 'تعلم كلمتك الأولى', icon: 'Star', requirement: 1, xpReward: 50 },
  { id: 'ten-words', name: 'Word Collector', nameArabic: 'جامع الكلمات', description: 'Learn 10 words', descriptionArabic: 'تعلم 10 كلمات', icon: 'BookOpen', requirement: 10, xpReward: 100 },
  { id: 'fifty-words', name: 'Vocabulary Builder', nameArabic: 'بناء المفردات', description: 'Learn 50 words', descriptionArabic: 'تعلم 50 كلمة', icon: 'Library', requirement: 50, xpReward: 250 },
  { id: 'hundred-words', name: 'Word Master', nameArabic: 'أستاذ الكلمات', description: 'Learn 100 words', descriptionArabic: 'تعلم 100 كلمة', icon: 'Crown', requirement: 100, xpReward: 500 },
  { id: 'first-conversation', name: 'Social Butterfly', nameArabic: 'فراشة اجتماعية', description: 'Complete your first conversation', descriptionArabic: 'أتمم محادثتك الأولى', icon: 'MessageCircle', requirement: 1, xpReward: 100 },
  { id: 'five-conversations', name: 'Conversation Star', nameArabic: 'نجم المحادثات', description: 'Complete 5 conversations', descriptionArabic: 'أتمم 5 محادثات', icon: 'Mic', requirement: 5, xpReward: 300 },
  { id: 'streak-7', name: 'Week Warrior', nameArabic: 'محارب الأسبوع', description: 'Maintain a 7-day streak', descriptionArabic: 'حافظ على سلسلة 7 أيام', icon: 'Flame', requirement: 7, xpReward: 200 },
  { id: 'streak-30', name: 'Month Master', nameArabic: 'أستاذ الشهر', description: 'Maintain a 30-day streak', descriptionArabic: 'حافظ على سلسلة 30 يوماً', icon: 'Trophy', requirement: 30, xpReward: 1000 },
  { id: 'perfect-score', name: 'Perfectionist', nameArabic: 'المثالي', description: 'Get a perfect score on any quiz', descriptionArabic: 'احصل على درجة مثالية في أي اختبار', icon: 'Zap', requirement: 1, xpReward: 150 },
  { id: 'xp-hundred', name: 'Rising Star', nameArabic: 'نجم صاعد', description: 'Earn 100 XP in one day', descriptionArabic: 'اكسب 100 نقطة خبرة في يوم واحد', icon: 'TrendingUp', requirement: 100, xpReward: 100 },
];

// Daily Challenges Template
export const dailyChallengeTemplates: DailyChallenge[] = [
  {
    id: 'vocab-10',
    type: 'vocabulary',
    title: 'Vocabulary Challenge',
    titleArabic: 'تحدي المفردات',
    description: 'Learn 10 new words today',
    descriptionArabic: 'تعلم 10 كلمات جديدة اليوم',
    xpReward: 50,
    completed: false,
    date: new Date().toISOString().split('T')[0],
  },
  {
    id: 'speaking-5',
    type: 'speaking',
    title: 'Speaking Practice',
    titleArabic: 'تدريب التحدث',
    description: 'Practice speaking for 5 minutes',
    descriptionArabic: 'تدرب على التحدث لمدة 5 دقائق',
    xpReward: 75,
    completed: false,
    date: new Date().toISOString().split('T')[0],
  },
  {
    id: 'listen-story',
    type: 'listening',
    title: 'Listening Adventure',
    titleArabic: 'مغامرة الاستماع',
    description: 'Listen to one story in English',
    descriptionArabic: 'استمع إلى قصة واحدة بالإنجليزية',
    xpReward: 60,
    completed: false,
    date: new Date().toISOString().split('T')[0],
  },
  {
    id: 'grammar-quiz',
    type: 'grammar',
    title: 'Grammar Champion',
    titleArabic: 'بطل القواعد',
    description: 'Complete a grammar lesson',
    descriptionArabic: 'أتمم درساً في القواعد',
    xpReward: 40,
    completed: false,
    date: new Date().toISOString().split('T')[0],
  },
];

// Speaking Practice Prompts
export const speakingPractice: SpeakingPractice[] = [
  { id: 'sp1', prompt: 'Say this greeting:', promptArabic: 'قل هذا التحية:', targetPhrase: 'Hello, how are you today?', helpfulWords: ['hello', 'how', 'are', 'you', 'today'] },
  { id: 'sp2', prompt: 'Introduce yourself:', promptArabic: 'عرّف عن نفسك:', targetPhrase: 'My name is Ahmed and I am a student.', helpfulWords: ['name', 'am', 'student'] },
  { id: 'sp3', prompt: 'Ask for directions:', promptArabic: 'اسأل عن الطريق:', targetPhrase: 'Excuse me, where is the nearest metro station?', helpfulWords: ['excuse', 'where', 'nearest', 'metro', 'station'] },
  { id: 'sp4', prompt: 'Order at a restaurant:', promptArabic: 'اطلب في المطعم:', targetPhrase: 'I would like to order the grilled fish, please.', helpfulWords: ['would', 'like', 'order', 'grilled', 'fish'] },
  { id: 'sp5', prompt: 'Make an appointment:', promptArabic: 'حدد موعداً:', targetPhrase: 'Hello, I would like to make an appointment for tomorrow.', helpfulWords: ['hello', 'would', 'like', 'make', 'appointment'] },
  { id: 'sp6', prompt: 'Express your feelings:', promptArabic: 'عبّر عن مشاعرك:', targetPhrase: 'I am very happy because today is my birthday!', helpfulWords: ['happy', 'because', 'today', 'birthday'] },
  { id: 'sp7', prompt: 'Describe your family:', promptArabic: 'صف عائلتك:', targetPhrase: 'I have four people in my family: my parents, my sister, and me.', helpfulWords: ['family', 'parents', 'sister'] },
  { id: 'sp8', prompt: 'Talk about your job:', promptArabic: 'تحدث عن عملك:', targetPhrase: 'I work as a software engineer at a tech company.', helpfulWords: ['work', 'software', 'engineer', 'tech', 'company'] },
  { id: 'sp9', prompt: 'Describe the weather:', promptArabic: 'صف الطقس:', targetPhrase: 'Today the weather is sunny and warm, perfect for a picnic!', helpfulWords: ['weather', 'sunny', 'warm', 'perfect', 'picnic'] },
  { id: 'sp10', prompt: 'Ask for help:', promptArabic: 'اطلب المساعدة:', targetPhrase: 'Can you please help me? I do not understand this question.', helpfulWords: ['can', 'help', 'please', 'understand'] },
];

// Numbers data
export const numberItems: NumberItem[] = [];
for (let i = 1; i <= 100; i++) {
  numberItems.push({
    id: `num-${i}`,
    number: i,
    english: i.toString(),
    arabic: ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة',
             'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر',
             'عشرون', 'واحد وعشرون', 'اثنان وعشرون', 'ثلاثة وعشرون', 'أربعة وعشرون', 'خمسة وعشرون', 'ستة وعشرون', 'سبعة وعشرون', 'ثمانية وعشرون', 'تسعة وعشرون',
             'ثلاثون', 'واحد وثلاثون', 'اثنان وثلاثون', 'ثلاثة وثلاثون', 'أربعة وثلاثون', 'خمسة وثلاثون', 'ستة وثلاثون', 'سبعة وثلاثون', 'ثمانية وثلاثون', 'تسعة وثلاثون',
             'أربعون', 'واحد وأربعون', 'اثنان وأربعون', 'ثلاثة وأربعون', 'أربعة وأربعون', 'خمسة وأربعون', 'ستة وأربعون', 'سبعة وأربعون', 'ثمانية وأربعون', 'تسعة وأربعون',
             'خمسون', 'واحد وخمسون', 'اثنان وخمسون', 'ثلاثة وخمسون', 'أربعة وخمسون', 'خمسة وخمسون', 'ستة وخمسون', 'سبعة وخمسون', 'ثمانية وخمسون', 'تسعة وخمسون',
             'ستون', 'واحد وستون', 'اثنان وستون', 'ثلاثة وستون', 'أربعة وستون', 'خمسة وستون', 'ستة وستون', 'سبعة وستون', 'ثمانية وستون', 'تسعة وستون',
             'سبعون', 'واحد وسبعون', 'اثنان وسبعون', 'ثلاثة وسبعون', 'أربعة وسبعون', 'خمسة وسبعون', 'ستة وسبعون', 'سبعة وسبعون', 'ثمانية وسبعون', 'تسعة وسبعون',
             'ثمانون', 'واحد وثمانون', 'اثنان وثمانون', 'ثلاثة وثمانون', 'أربعة وثمانون', 'خمسة وثمانون', 'ستة وثمانون', 'سبعة وثمانون', 'ثمانية وثمانون', 'تسعة وثمانون',
             'تسعون', 'واحد وتسعون', 'اثنان وتسعون', 'ثلاثة وتسعون', 'أربعة وتسعون', 'خمسة وتسعون', 'ستة وتسعون', 'سبعة وتسعون', 'ثمانية وتسعون', 'تسعة وتسعون', 'مئة'][i] || i.toString(),
  });
}
