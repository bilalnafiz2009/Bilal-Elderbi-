import { motion } from 'framer-motion';
import { Speaker, Heart, Check } from 'lucide-react';
import type { Word } from '../../types';

interface WordCardProps {
  word: Word;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onSpeak: () => void;
  isSpeaking: boolean;
  isFlipped?: boolean;
  onFlip?: () => void;
}

export function WordCard({
  word,
  isFavorite,
  onToggleFavorite,
  onSpeak,
  isSpeaking,
  isFlipped,
  onFlip,
}: WordCardProps) {
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onFlip}
      className={`relative w-full cursor-pointer perspective-1000 ${
        isFlipped ? 'animate-card-flip' : ''
      }`}
    >
      <motion.div
        className={`relative w-full min-h-[200px] rounded-2xl p-6 shadow-xl transition-all duration-300 ${
          isFlipped
            ? 'bg-gradient-to-br from-purple-600 to-blue-600'
            : 'bg-gradient-to-br from-blue-500 to-purple-600'
        }`}
      >
        {/* Card Content */}
        <div className="flex flex-col items-center justify-center h-full space-y-4">
          <div className="text-3xl font-bold text-white text-center">
            {word.english}
          </div>
          <div className="text-xl text-white/80 text-center font-medium">
            {word.arabic}
          </div>
          <div className="text-sm text-white/60 italic">
            {word.pronunciation}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 mt-4">
            {/* Speak Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                onSpeak();
              }}
              className={`p-3 rounded-full transition-all duration-200 ${
                isSpeaking
                  ? 'bg-white text-purple-600 animate-pulse'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Speaker className="w-6 h-6" />
            </motion.button>

            {/* Favorite Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite();
              }}
              className={`p-3 rounded-full transition-all duration-200 ${
                isFavorite
                  ? 'bg-pink-500 text-white'
                  : 'bg-white/20 text-white/80 hover:bg-white/30'
              }`}
            >
              <Heart className={`w-6 h-6 ${isFavorite ? 'fill-current' : ''}`} />
            </motion.button>

            {/* Complete Badge */}
            {word.wordType === 'verb' && (
              <div className="px-3 py-1 bg-white/20 rounded-full text-white text-xs font-medium">
                Verb
              </div>
            )}
            {word.wordType === 'adjective' && (
              <div className="px-3 py-1 bg-white/20 rounded-full text-white text-xs font-medium">
                Adjective
              </div>
            )}
            {word.wordType === 'idiom' && (
              <div className="px-3 py-1 bg-yellow-400/80 text-yellow-900 rounded-full text-xs font-medium">
                Idiom
              </div>
            )}
          </div>

          {/* Difficulty Indicator */}
          <div className="absolute top-4 right-4 flex gap-1">
            {[1, 2, 3].slice(0, word.difficulty).map((i) => (
              <div key={i} className="w-2 h-2 rounded-full bg-white/80" />
            ))}
          </div>
        </div>

        {/* Flip Indicator */}
        {!isFlipped && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/50 text-xs">
            Tap to flip
          </div>
        )}
      </motion.div>

      {/* Example Section (shown when flipped) */}
      {isFlipped && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-4 bg-white dark:bg-slate-800 rounded-xl shadow-lg"
        >
          <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">Example:</div>
          <div className="text-gray-900 dark:text-white font-medium">
            "{word.example}"
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-300 mt-1">
            {word.exampleArabic}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}

interface FlashcardProps {
  word: Word;
  onSwipe: (direction: 'left' | 'right') => void;
  onSpeak: () => void;
  isSpeaking: boolean;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export function Flashcard({
  word,
  onSwipe,
  onSpeak,
  isSpeaking,
  isFavorite,
  onToggleFavorite,
}: FlashcardProps) {
  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.7}
      onDragEnd={(_, info) => {
        if (info.offset.x > 100) {
          onSwipe('right');
        } else if (info.offset.x < -100) {
          onSwipe('left');
        }
      }}
      className="relative w-full touch-none"
    >
      <motion.div
        className="relative w-full min-h-[300px] rounded-3xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 p-1 shadow-2xl"
      >
        <div className={`h-full rounded-3xl p-6 ${
          'dark' in window ? 'bg-slate-800' : 'bg-white'
        }`}>
          <div className="flex flex-col h-full">
            {/* Top Section */}
            <div className="flex justify-between items-start">
              <div className="flex gap-1">
                {[1, 2, 3].slice(0, word.difficulty).map((i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-green-500" />
                ))}
              </div>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={onToggleFavorite}
                className={`p-2 rounded-full transition-colors ${
                  isFavorite ? 'text-pink-500' : 'text-gray-400'
                }`}
              >
                <Heart className={`w-6 h-6 ${isFavorite ? 'fill-current' : ''}`} />
              </motion.button>
            </div>

            {/* Center Content */}
            <div className="flex-1 flex flex-col items-center justify-center -mt-20">
              <div className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                {word.english}
              </div>
              <div className="text-2xl text-gray-600 dark:text-gray-300 mb-4">
                {word.arabic}
              </div>
              <div className="text-lg text-gray-400 italic mb-6">
                /{word.pronunciation}/
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onSpeak}
                className={`p-4 rounded-full transition-all duration-300 ${
                  isSpeaking
                    ? 'bg-purple-500 text-white animate-pulse'
                    : 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                }`}
              >
                <Speaker className="w-8 h-8" />
              </motion.button>
            </div>

            {/* Bottom Example */}
            <div className="mt-auto p-4 bg-gray-50 dark:bg-slate-700 rounded-xl">
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Example:</div>
              <div className="text-gray-900 dark:text-white font-medium mb-1">
                {word.example}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                {word.exampleArabic}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Swipe Hints */}
      <div className="flex justify-between mt-4 px-4">
        <div className="flex items-center gap-2 text-red-500">
          <span className="text-2xl font-bold">✗</span>
          <span className="text-sm">Skip</span>
        </div>
        <div className="flex items-center gap-2 text-green-500">
          <span className="text-sm">Know it!</span>
          <span className="text-2xl font-bold">✓</span>
        </div>
      </div>
    </motion.div>
  );
}

interface CategoryCardProps {
  name: string;
  nameArabic: string;
  icon: React.ReactNode;
  color: string;
  wordCount: number;
  progress: number;
  onClick: () => void;
}

export function CategoryCard({
  name,
  nameArabic,
  icon,
  color,
  wordCount,
  progress,
  onClick,
}: CategoryCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`relative overflow-hidden rounded-2xl p-5 cursor-pointer transition-all duration-300 ${
        'dark' in window ? 'dark' : ''
      }`}
      style={{
        background: `linear-gradient(135deg, ${color}20 0%, ${color}05 100%)`,
      }}
    >
      <div className="relative z-10">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
          style={{ backgroundColor: `${color}30` }}
        >
          <div style={{ color }}>
            {icon}
          </div>
        </div>
        <div className="font-bold text-gray-900 dark:text-white mb-1">{name}</div>
        <div className="text-sm text-gray-500 dark:text-gray-400 mb-3">{nameArabic}</div>
        <div className="text-xs text-gray-400 mb-3">{wordCount} words</div>

        {/* Progress Bar */}
        <div className="w-full h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full rounded-full"
            style={{ backgroundColor: color }}
          />
        </div>
      </div>

      {/* Background Decoration */}
      <div
        className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-10"
        style={{ backgroundColor: color }}
      />
    </motion.div>
  );
}

interface ProgressRingProps {
  progress: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
}

export function ProgressRing({
  progress,
  size = 100,
  strokeWidth = 8,
  color = '#3B82F6',
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={strokeWidth}
        stroke="currentColor"
        fill="none"
        className="text-gray-200 dark:text-gray-700"
      />
      <motion.circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={strokeWidth}
        stroke={color}
        fill="none"
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset }}
        transition={{ duration: 1 }}
        strokeLinecap="round"
      />
      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dy=".3em"
        className="text-xl font-bold fill-current text-gray-900 dark:text-white"
      >
        {Math.round(progress)}%
      </text>
    </svg>
  );
}

interface StatCardProps {
  label: string;
  route: string | number;
  icon: React.ReactNode;
  color: string;
}

export function StatCard({ label, route, icon, color }: StatCardProps) {
  return (
    <div className={`flex flex-col items-center p-4 rounded-2xl ${
      'dark' in window ? 'bg-slate-800' : 'bg-white'
    } shadow-lg`}>
      <div className="mb-2" style={{ color }}>
        {icon}
      </div>
      <div className="text-2xl font-bold text-gray-900 dark:text-white">{route}</div>
      <div className="text-sm text-gray-500 dark:text-gray-400">{label}</div>
    </div>
  );
}
