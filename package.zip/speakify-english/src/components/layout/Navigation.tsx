import { useState, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home, BookOpen, Mic, Headphones, MessageCircle, Hash, User,
  Search, Sun, Moon, Menu, X, Settings, Trophy, Flame, Zap
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useProgress } from '../../context/ProgressContext';

const navItems = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/vocabulary', icon: BookOpen, label: 'Vocabulary' },
  { path: '/speaking', icon: Mic, label: 'Speaking' },
  { path: '/listening', icon: Headphones, label: 'Listening' },
  { path: '/conversations', icon: MessageCircle, label: 'Talk' },
  { path: '/numbers', icon: Hash, label: 'Numbers' },
  { path: '/profile', icon: User, label: 'Profile' },
];

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const { theme, toggleTheme, isDark } = useTheme();
  const { progress } = useProgress();
  const location = useLocation();

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-300 ${
      isDark ? 'bg-slate-900/95 backdrop-blur-md border-b border-slate-700' : 'bg-white/95 backdrop-blur-md border-b border-gray-200'
    }`}>
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg"
          >
            <Zap className="w-6 h-6 text-white" />
          </motion.div>
          <span className="font-bold text-xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Speakify
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30'
                    : isDark
                      ? 'text-slate-300 hover:bg-slate-800 hover:text-white'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            );
          })}
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center gap-2">
          {/* Streak & XP */}
          <div className={`hidden sm:flex items-center gap-3 px-3 py-1.5 rounded-full ${
            isDark ? 'bg-slate-800' : 'bg-gray-100'
          }`}>
            <div className="flex items-center gap-1">
              <Flame className={`w-4 h-4 ${progress.streak > 0 ? 'text-orange-500' : 'text-gray-400'}`} />
              <span className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                {progress.streak}
              </span>
            </div>
            <div className="w-px h-4 bg-gray-300 dark:bg-slate-600" />
            <div className="flex items-center gap-1">
              <Zap className="w-4 h-4 text-yellow-500" />
              <span className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                {progress.xp.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Search Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowSearch(!showSearch)}
            className={`p-2 rounded-lg transition-colors ${
              showSearch
                ? 'bg-blue-500 text-white'
                : isDark
                  ? 'text-slate-300 hover:bg-slate-800'
                  : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Search className="w-5 h-5" />
          </motion.button>

          {/* Theme Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleTheme}
            className={`p-2 rounded-lg transition-colors ${
              isDark
                ? 'text-slate-300 hover:bg-slate-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </motion.button>

          {/* Mobile Menu Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className={`md:hidden p-2 rounded-lg transition-colors ${
              isDark
                ? 'text-slate-300 hover:bg-slate-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </motion.button>
        </div>
      </div>

      {/* Search Bar */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4">
              <div className={`max-w-xl mx-auto flex items-center gap-2 px-4 py-3 rounded-xl ${
                isDark ? 'bg-slate-800' : 'bg-gray-100'
              }`}>
                <Search className={`w-5 h-5 ${isDark ? 'text-slate-400' : 'text-gray-400'}`} />
                <input
                  type="text"
                  placeholder="Search 6000+ words..."
                  className="flex-1 bg-transparent outline-none text-gray-900 dark:text-white placeholder-gray-400"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden"
          >
            <div className="px-4 pb-4">
              <div className={`rounded-xl p-2 ${isDark ? 'bg-slate-800' : 'bg-gray-100'}`}>
                {navItems.map((item) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsMenuOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                        isActive
                          ? 'bg-blue-500 text-white'
                          : isDark
                            ? 'text-slate-300 hover:bg-slate-700'
                            : 'text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export function BottomNav() {
  const location = useLocation();
  const { isDark } = useTheme();

  return (
    <nav className={`fixed bottom-0 left-0 right-0 z-50 md:hidden transition-colors duration-300 ${
      isDark ? 'bg-slate-900/95 backdrop-blur-md border-t border-slate-700' : 'bg-white/95 backdrop-blur-md border-t border-gray-200'
    }`}>
      <div className="flex items-center justify-around px-2 py-2 safe-area-bottom">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30'
                  : isDark
                    ? 'text-slate-400'
                    : 'text-gray-500'
              }`}
            >
              <motion.div
                whileTap={{ scale: 0.9 }}
              >
                <item.icon className={`w-6 h-6 ${isActive ? '' : ''}`} />
              </motion.div>
              <span className={`text-xs ${isActive ? 'font-semibold' : 'font-medium'}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
