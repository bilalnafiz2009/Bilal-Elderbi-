export interface Word {
  id: string;
  english: string;
  arabic: string;
  pronunciation: string;
  example: string;
  exampleArabic: string;
  category: CategoryId;
  difficulty: 1 | 2 | 3;
  wordType: 'vocabulary' | 'verb' | 'adjective' | 'phrase' | 'idiom';
  frequency: number;
}

export type CategoryId =
  | 'daily-conversations'
  | 'restaurant'
  | 'travel-airports'
  | 'hotels-booking'
  | 'shopping-supermarket'
  | 'cars-transportation'
  | 'school-education'
  | 'business-english'
  | 'technology'
  | 'food-drinks'
  | 'family-friends'
  | 'jobs-work'
  | 'numbers-counting'
  | 'time-dates'
  | 'weather'
  | 'emergency-phrases'
  | 'common-verbs'
  | 'common-adjectives'
  | 'idioms-expressions';

export interface Category {
  id: CategoryId;
  name: string;
  nameArabic: string;
  icon: string;
  color: string;
  difficulty: 1 | 2 | 3;
  description: string;
  descriptionArabic: string;
}

export interface UserProgress {
  xp: number;
  level: number;
  streak: number;
  lastActiveDate: string;
  completedWords: string[];
  favoriteWords: string[];
  categoryProgress: Record<string, number>;
  totalWordsLearned: number;
  totalMinutesSpent: number;
  achievements: string[];
}

export interface Conversation {
  id: string;
  title: string;
  titleArabic: string;
  category: CategoryId;
  lines: ConversationLine[];
}

export interface ConversationLine {
  id: number;
  speaker: 'person1' | 'person2';
  english: string;
  arabic: string;
  audioCue?: string;
}

export interface GrammarLesson {
  id: string;
  title: string;
  titleArabic: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  content: string;
  contentArabic: string;
  examples: GrammarExample[];
  exercises: GrammarExercise[];
}

export interface GrammarExample {
  english: string;
  arabic: string;
  explanation: string;
  explanationArabic: string;
}

export interface GrammarExercise {
  id: string;
  type: 'multiple-choice' | 'fill-blank' | 'sentence-order';
  question: string;
  questionArabic: string;
  options?: string[];
  correctAnswer: string | number[];
}

export interface ListeningExercise {
  id: string;
  title: string;
  titleArabic: string;
  transcript: string;
  transcriptArabic: string;
  audioText: string;
  duration: number;
  speed: number;
  difficulty: 1 | 2 | 3;
  quiz: ListeningQuiz[];
}

export interface ListeningQuiz {
  question: string;
  questionArabic: string;
  options: string[];
  correctAnswer: number;
}

export interface Achievement {
  id: string;
  name: string;
  nameArabic: string;
  description: string;
  descriptionArabic: string;
  icon: string;
  requirement: number;
  xpReward: number;
}

export interface DailyChallenge {
  id: string;
  type: 'vocabulary' | 'speaking' | 'listening' | 'grammar' | 'quiz';
  title: string;
  titleArabic: string;
  description: string;
  descriptionArabic: string;
  xpReward: number;
  completed: boolean;
  date: string;
}

export interface SpeakingPractice {
  id: string;
  prompt: string;
  promptArabic: string;
  targetPhrase: string;
  helpfulWords: string[];
}

export interface NumberItem {
  id: string;
  number: number;
  english: string;
  arabic: string;
  audioUrl?: string;
}

export interface NumberCategory {
  id: string;
  name: string;
  nameArabic: string;
  items: NumberItem[];
}
